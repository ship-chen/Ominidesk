"""
OmniDesk AI - 后端主入口
基于 FastAPI + WebSocket 的异步服务架构
"""

import asyncio
import logging
import json
import uuid
from typing import Dict, Any, Set
from datetime import datetime, timedelta
import os
import sys

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import jwt

# 导入核心模块
from modules.vbox_integration import VBoxIntegration
from modules.ai_brain import AIBrain
from modules.perception_engine import PerceptionEngine
from modules.agent_engine import AgentEngine
from modules.security_audit import SecurityAuditSystem

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 配置
JWT_SECRET = os.getenv('JWT_SECRET', 'omnidesk-secret-key-change-in-production')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_HOURS = 24

# FastAPI 应用
app = FastAPI(
    title="OmniDesk AI Backend",
    description="AI-powered Windows desktop application",
    version="1.0.0"
)

# CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局状态
class AppState:
    """应用全局状态"""
    
    def __init__(self):
        self.vbox_integration = VBoxIntegration()
        self.ai_brain = AIBrain()
        self.perception_engine = PerceptionEngine()
        self.agent_engine = AgentEngine()
        self.security_audit = SecurityAuditSystem()
        
        # WebSocket 连接管理
        self.active_connections: Set[WebSocket] = set()
        self.session_tokens: Dict[str, Dict[str, Any]] = {}
        
        logger.info("应用状态已初始化")

# 应用状态实例
app_state = AppState()

# ============================================================================
# 认证相关
# ============================================================================

def generate_session_token() -> str:
    """生成会话 token"""
    payload = {
        'session_id': str(uuid.uuid4()),
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS),
        'iat': datetime.utcnow()
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token

def verify_token(token: str) -> Dict[str, Any]:
    """验证 token"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token 已过期")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="无效的 token")

# ============================================================================
# REST API 路由
# ============================================================================

@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "ok",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0"
    }

@app.get("/session-token")
async def get_session_token():
    """获取会话 token"""
    token = generate_session_token()
    app_state.session_tokens[token] = {
        'created_at': datetime.utcnow().isoformat(),
        'ip': '127.0.0.1'
    }
    logger.info(f"会话 token 已生成: {token[:20]}...")
    return {
        "status": "success",
        "token": token
    }

@app.get("/models")
async def get_available_models():
    """获取可用模型列表"""
    models = app_state.ai_brain.get_available_models()
    return {
        "status": "success",
        "models": models
    }

@app.get("/vms")
async def list_vms():
    """列出所有虚拟机"""
    result = await app_state.vbox_integration.list_vms()
    return result

@app.get("/audit-log")
async def get_audit_log(limit: int = 100):
    """获取审计日志"""
    result = await app_state.security_audit.get_audit_log(limit)
    return result

# ============================================================================
# WebSocket 连接管理
# ============================================================================

class ConnectionManager:
    """WebSocket 连接管理器"""
    
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.authenticated_sessions: Dict[str, str] = {}
    
    async def connect(self, websocket: WebSocket, session_id: str):
        """建立连接"""
        await websocket.accept()
        self.active_connections[session_id] = websocket
        logger.info(f"客户端已连接: {session_id}")
    
    def disconnect(self, session_id: str):
        """断开连接"""
        if session_id in self.active_connections:
            del self.active_connections[session_id]
        if session_id in self.authenticated_sessions:
            del self.authenticated_sessions[session_id]
        logger.info(f"客户端已断开: {session_id}")
    
    async def broadcast(self, message: Dict[str, Any]):
        """广播消息"""
        for connection in self.active_connections.values():
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"广播消息失败: {e}")
    
    async def send_to_client(self, session_id: str, message: Dict[str, Any]):
        """发送消息给特定客户端"""
        if session_id in self.active_connections:
            try:
                await self.active_connections[session_id].send_json(message)
            except Exception as e:
                logger.error(f"发送消息失败: {e}")

manager = ConnectionManager()

# ============================================================================
# WebSocket 处理
# ============================================================================

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket 端点"""
    session_id = str(uuid.uuid4())
    
    try:
        await manager.connect(websocket, session_id)
        
        while True:
            # 接收消息
            data = await websocket.receive_text()
            message = json.loads(data)
            
            logger.info(f"收到消息: {message.get('type')}")
            
            # 处理消息
            response = await handle_message(message, session_id)
            
            # 发送响应
            if response:
                await manager.send_to_client(session_id, response)
    
    except WebSocketDisconnect:
        manager.disconnect(session_id)
        logger.info(f"客户端断开连接: {session_id}")
    
    except Exception as e:
        logger.error(f"WebSocket 错误: {e}")
        manager.disconnect(session_id)

# ============================================================================
# 消息处理
# ============================================================================

async def handle_message(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理客户端消息"""
    
    msg_type = message.get('type')
    
    try:
        # 认证
        if msg_type == 'auth':
            return await handle_auth(message, session_id)
        
        # 检查是否已认证
        if session_id not in manager.authenticated_sessions:
            return {
                'type': 'error',
                'message': '未认证，请先发送 auth 消息'
            }
        
        # 聊天
        if msg_type == 'chat':
            return await handle_chat(message, session_id)
        
        # 虚拟机控制
        elif msg_type == 'vm_control':
            return await handle_vm_control(message, session_id)
        
        # 权限请求
        elif msg_type == 'approve_permission':
            return await handle_approve_permission(message, session_id)
        
        elif msg_type == 'deny_permission':
            return await handle_deny_permission(message, session_id)
        
        # 任务管理
        elif msg_type == 'create_task':
            return await handle_create_task(message, session_id)
        
        elif msg_type == 'execute_task':
            return await handle_execute_task(message, session_id)
        
        elif msg_type == 'pause_task':
            return await handle_pause_task(message, session_id)
        
        elif msg_type == 'resume_task':
            return await handle_resume_task(message, session_id)
        
        elif msg_type == 'cancel_task':
            return await handle_cancel_task(message, session_id)
        
        # 获取状态
        elif msg_type == 'get_status':
            return await handle_get_status(message, session_id)
        
        else:
            return {
                'type': 'error',
                'message': f'未知的消息类型: {msg_type}'
            }
    
    except Exception as e:
        logger.error(f"处理消息失败: {e}")
        return {
            'type': 'error',
            'message': str(e)
        }

# ============================================================================
# 消息处理函数
# ============================================================================

async def handle_auth(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理认证"""
    token = message.get('token')
    
    if not token:
        return {
            'type': 'error',
            'message': '缺少 token'
        }
    
    try:
        payload = verify_token(token)
        manager.authenticated_sessions[session_id] = token
        
        logger.info(f"客户端已认证: {session_id}")
        
        return {
            'type': 'auth_success',
            'response': '认证成功，已连接到 OmniDesk AI 后端',
            'session_id': session_id
        }
    
    except Exception as e:
        return {
            'type': 'error',
            'message': f'认证失败: {e}'
        }

async def handle_chat(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理聊天"""
    user_message = message.get('message')
    model = message.get('model', 'gpt-4')
    
    if not user_message:
        return {
            'type': 'error',
            'message': '缺少消息内容'
        }
    
    try:
        # 调用 AI 模型
        result = await app_state.ai_brain.chat(user_message, model)
        
        return {
            'type': 'chat_response',
            'response': result.get('response', ''),
            'model': result.get('model', ''),
            'tokens_used': result.get('tokens_used', 0)
        }
    
    except Exception as e:
        logger.error(f"聊天失败: {e}")
        return {
            'type': 'error',
            'message': f'聊天失败: {e}'
        }

async def handle_vm_control(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理虚拟机控制"""
    action = message.get('action')
    params = message.get('params', {})
    
    try:
        if action == 'start':
            result = await app_state.vbox_integration.start_vm(params.get('vm_id'))
        elif action == 'stop':
            result = await app_state.vbox_integration.stop_vm(params.get('vm_id'))
        elif action == 'screenshot':
            result = await app_state.vbox_integration.take_screenshot(params.get('vm_id'))
        elif action == 'click':
            result = await app_state.vbox_integration.inject_mouse(
                params.get('vm_id'),
                params.get('x', 0),
                params.get('y', 0)
            )
        elif action == 'type':
            result = await app_state.vbox_integration.inject_keyboard(
                params.get('vm_id'),
                params.get('text', '')
            )
        else:
            return {
                'type': 'error',
                'message': f'未知的虚拟机操作: {action}'
            }
        
        return {
            'type': 'vm_control_response',
            'result': result
        }
    
    except Exception as e:
        logger.error(f"虚拟机控制失败: {e}")
        return {
            'type': 'error',
            'message': f'虚拟机控制失败: {e}'
        }

async def handle_approve_permission(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理权限批准"""
    request_id = message.get('request_id')
    remember = message.get('remember', False)
    
    try:
        result = await app_state.security_audit.approve_host_permission(request_id, remember)
        return {
            'type': 'permission_response',
            'result': result
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

async def handle_deny_permission(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理权限拒绝"""
    request_id = message.get('request_id')
    remember = message.get('remember', False)
    
    try:
        result = await app_state.security_audit.deny_host_permission(request_id, remember)
        return {
            'type': 'permission_response',
            'result': result
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

async def handle_create_task(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理任务创建"""
    user_input = message.get('user_input')
    
    if not user_input:
        return {
            'type': 'error',
            'message': '缺少用户输入'
        }
    
    try:
        result = await app_state.agent_engine.create_task(user_input)
        return {
            'type': 'task_created',
            'task': result.get('task')
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

async def handle_execute_task(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理任务执行"""
    task_id = message.get('task_id')
    
    if not task_id:
        return {
            'type': 'error',
            'message': '缺少任务 ID'
        }
    
    try:
        result = await app_state.agent_engine.execute_task(task_id)
        return {
            'type': 'task_updated',
            'task': result.get('task')
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

async def handle_pause_task(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理任务暂停"""
    task_id = message.get('task_id')
    
    try:
        result = await app_state.agent_engine.pause_task(task_id)
        return {
            'type': 'task_updated',
            'result': result
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

async def handle_resume_task(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理任务恢复"""
    task_id = message.get('task_id')
    
    try:
        result = await app_state.agent_engine.resume_task(task_id)
        return {
            'type': 'task_updated',
            'result': result
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

async def handle_cancel_task(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理任务取消"""
    task_id = message.get('task_id')
    
    try:
        result = await app_state.agent_engine.cancel_task(task_id)
        return {
            'type': 'task_updated',
            'result': result
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

async def handle_get_status(message: Dict[str, Any], session_id: str) -> Dict[str, Any]:
    """处理状态查询"""
    try:
        vms = await app_state.vbox_integration.list_vms()
        tasks = await app_state.agent_engine.list_tasks()
        audit_log = await app_state.security_audit.get_audit_log(10)
        
        return {
            'type': 'status',
            'vms': vms.get('vms', []),
            'tasks': tasks.get('tasks', []),
            'audit_log': audit_log.get('events', [])
        }
    except Exception as e:
        return {
            'type': 'error',
            'message': str(e)
        }

# ============================================================================
# 启动和关闭事件
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """应用启动事件"""
    logger.info("=" * 50)
    logger.info("OmniDesk AI 后端启动中...")
    logger.info("=" * 50)
    
    # 初始化模块
    logger.info("初始化 VirtualBox 控制器...")
    logger.info("初始化 AI 大脑...")
    logger.info("初始化感知引擎...")
    logger.info("初始化任务代理...")
    logger.info("初始化安全审计系统...")
    
    logger.info("=" * 50)
    logger.info("OmniDesk AI 后端已启动")
    logger.info("WebSocket: ws://127.0.0.1:8000/ws")
    logger.info("API 文档: http://127.0.0.1:8000/docs")
    logger.info("=" * 50)

@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭事件"""
    logger.info("OmniDesk AI 后端正在关闭...")
    
    # 关闭所有 WebSocket 连接
    for connection in manager.active_connections.values():
        await connection.close()
    
    logger.info("OmniDesk AI 后端已关闭")

# ============================================================================
# 主程序
# ============================================================================

if __name__ == "__main__":
    logger.info("启动 Uvicorn 服务器...")
    
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8000,
        log_level="info"
    )
