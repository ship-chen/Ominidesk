#!/usr/bin/env python3
"""
数据库管理模块
提供数据库连接、会话管理、迁移等功能
"""

import logging
from typing import Optional, Generator
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool

from .database_models import Base

logger = logging.getLogger(__name__)


class DatabaseManager:
    """数据库管理器"""
    
    def __init__(self, database_url: str = "sqlite:///./data/omnidesk.db"):
        """
        初始化数据库管理器
        
        Args:
            database_url: 数据库连接字符串
        """
        self.database_url = database_url
        self.engine = None
        self.SessionLocal = None
        self._initialize()
    
    def _initialize(self) -> None:
        """初始化数据库"""
        try:
            # 创建引擎
            if "sqlite" in self.database_url:
                # SQLite 特殊配置
                self.engine = create_engine(
                    self.database_url,
                    connect_args={"check_same_thread": False},
                    poolclass=StaticPool,
                )
            else:
                # 其他数据库
                self.engine = create_engine(
                    self.database_url,
                    pool_pre_ping=True,
                    pool_recycle=3600,
                )
            
            # 创建会话工厂
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            
            # 创建表
            self.create_tables()
            
            logger.info(f"数据库已初始化: {self.database_url}")
        
        except Exception as e:
            logger.error(f"数据库初始化失败: {e}")
            raise
    
    def create_tables(self) -> None:
        """创建所有表"""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("数据库表已创建")
        except Exception as e:
            logger.error(f"创建表失败: {e}")
            raise
    
    def drop_tables(self) -> None:
        """删除所有表（仅用于开发）"""
        try:
            Base.metadata.drop_all(bind=self.engine)
            logger.warning("所有数据库表已删除")
        except Exception as e:
            logger.error(f"删除表失败: {e}")
            raise
    
    def get_session(self) -> Session:
        """获取数据库会话"""
        if self.SessionLocal is None:
            raise RuntimeError("数据库未初始化")
        return self.SessionLocal()
    
    def close(self) -> None:
        """关闭数据库连接"""
        if self.engine:
            self.engine.dispose()
            logger.info("数据库连接已关闭")
    
    def health_check(self) -> bool:
        """检查数据库健康状态"""
        try:
            session = self.get_session()
            session.execute("SELECT 1")
            session.close()
            return True
        except Exception as e:
            logger.error(f"数据库健康检查失败: {e}")
            return False


# 全局数据库管理器实例
_db_manager: Optional[DatabaseManager] = None


def get_db_manager(database_url: str = "sqlite:///./data/omnidesk.db") -> DatabaseManager:
    """获取数据库管理器"""
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseManager(database_url)
    return _db_manager


def get_db() -> Generator[Session, None, None]:
    """获取数据库会话（用于 FastAPI 依赖注入）"""
    db = get_db_manager().get_session()
    try:
        yield db
    finally:
        db.close()


# 导出
__all__ = [
    'DatabaseManager',
    'get_db_manager',
    'get_db'
]
