#!/usr/bin/env python3
"""
数据库模型定义
使用 SQLAlchemy ORM 定义数据库表结构
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()


class User(Base):
    """用户表"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True)
    email = Column(String(100), unique=True, index=True)
    password_hash = Column(String(255))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    tasks = relationship("Task", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")


class VirtualMachine(Base):
    """虚拟机表"""
    __tablename__ = "virtual_machines"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True)
    uuid = Column(String(36), unique=True)
    state = Column(String(20))  # running, stopped, paused, etc.
    memory_mb = Column(Integer)
    cpus = Column(Integer)
    disk_gb = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    snapshots = relationship("Snapshot", back_populates="vm")
    tasks = relationship("Task", back_populates="vm")


class Snapshot(Base):
    """快照表"""
    __tablename__ = "snapshots"
    
    id = Column(Integer, primary_key=True, index=True)
    vm_id = Column(Integer, ForeignKey("virtual_machines.id"))
    name = Column(String(100))
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # 关系
    vm = relationship("VirtualMachine", back_populates="snapshots")


class Task(Base):
    """任务表"""
    __tablename__ = "tasks"
    
    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(String(50), unique=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    vm_id = Column(Integer, ForeignKey("virtual_machines.id"), nullable=True)
    title = Column(String(200))
    description = Column(Text)
    status = Column(String(20))  # pending, running, completed, failed, cancelled
    priority = Column(Integer, default=0)
    progress = Column(Float, default=0.0)
    result = Column(Text, nullable=True)
    error = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    user = relationship("User", back_populates="tasks")
    vm = relationship("VirtualMachine", back_populates="tasks")


class AuditLog(Base):
    """审计日志表"""
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100))
    resource_type = Column(String(50))
    resource_id = Column(String(100))
    details = Column(Text)
    status = Column(String(20))  # success, failure
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # 关系
    user = relationship("User", back_populates="audit_logs")


class AIModel(Base):
    """AI 模型表"""
    __tablename__ = "ai_models"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, index=True)
    type = Column(String(20))  # cloud, local
    version = Column(String(20))
    enabled = Column(Boolean, default=True)
    config = Column(Text)  # JSON 格式的配置
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class CacheEntry(Base):
    """缓存表"""
    __tablename__ = "cache_entries"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(255), unique=True, index=True)
    value = Column(Text)
    ttl = Column(Integer)  # 生存时间（秒）
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)


class PermissionRequest(Base):
    """权限请求表"""
    __tablename__ = "permission_requests"
    
    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(String(50), unique=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100))
    resource = Column(String(200))
    status = Column(String(20))  # pending, approved, denied
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    responded_at = Column(DateTime, nullable=True)


class SystemMetrics(Base):
    """系统指标表"""
    __tablename__ = "system_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    metric_name = Column(String(100))
    metric_value = Column(Float)
    unit = Column(String(20))
    timestamp = Column(DateTime, default=datetime.utcnow)


# 导出
__all__ = [
    'Base',
    'User',
    'VirtualMachine',
    'Snapshot',
    'Task',
    'AuditLog',
    'AIModel',
    'CacheEntry',
    'PermissionRequest',
    'SystemMetrics'
]
