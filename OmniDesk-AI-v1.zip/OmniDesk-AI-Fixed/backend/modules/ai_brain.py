"""
AI 大脑 - 多模型统一调用接口
功能：
1. 云端模型支持（OpenAI 兼容接口）
2. 本地模型支持（Ollama, llama.cpp）
3. 模型路由和负载均衡
4. 上下文管理
5. Token 计数
"""

import logging
from typing import Dict, Any, List, Optional
from enum import Enum
import json

logger = logging.getLogger(__name__)


class ModelType(Enum):
    """模型类型"""
    CLOUD = "cloud"  # 云端模型
    LOCAL = "local"  # 本地模型


class ModelProvider(Enum):
    """模型提供商"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    ZHIPU = "zhipu"  # 智谱
    ALIYUN = "aliyun"  # 通义千问
    BAIDU = "baidu"  # 文心
    MINIMAX = "minimax"
    OLLAMA = "ollama"
    LLAMA_CPP = "llama_cpp"


class Model:
    """模型配置"""
    
    def __init__(
        self,
        name: str,
        provider: ModelProvider,
        model_type: ModelType,
        endpoint: Optional[str] = None,
        api_key: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ):
        self.name = name
        self.provider = provider
        self.model_type = model_type
        self.endpoint = endpoint
        self.api_key = api_key
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.is_available = False
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "name": self.name,
            "provider": self.provider.value,
            "type": self.model_type.value,
            "endpoint": self.endpoint,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "is_available": self.is_available
        }


class AIBrain:
    """AI 大脑 - 多模型管理"""
    
    def __init__(self):
        self.models: Dict[str, Model] = {}
        self.default_model: Optional[str] = None
        self.conversation_history: List[Dict[str, str]] = []
        self.max_history_length = 20
        
        # 初始化默认模型配置
        self._init_default_models()
    
    def add_model(self, name: str, provider: str, model_type: str, **kwargs) -> bool:
        """添加模型"""
        try:
            model = Model(
                name=name,
                provider=ModelProvider[provider.upper()],
                model_type=ModelType[model_type.upper()],
                **kwargs
            )
            self.models[name] = model
            logger.info(f"✅ 模型已添加: {name}")
            return True
        except Exception as e:
            logger.error(f"❌ 添加模型失败: {e}")
            return False
    
    def list_models(self) -> list:
        """列出所有模型"""
        return list(self.models.keys())
    
    def select_model(self, name: str) -> bool:
        """选择模型"""
        if name in self.models:
            self.default_model = name
            logger.info(f"✅ 已选择模型: {name}")
            return True
        logger.error(f"❌ 模型不存在: {name}")
        return False
    
    def get_current_model(self) -> str:
        """获取当前模型"""
        return self.default_model
    
    def _init_default_models(self):
        """初始化默认模型配置"""
        
        # 云端模型
        cloud_models = [
            Model(
                name="gpt-4",
                provider=ModelProvider.OPENAI,
                model_type=ModelType.CLOUD,
                endpoint="https://api.openai.com/v1",
                api_key="sk-xxx",  # 从环境变量读取
                max_tokens=8192
            ),
            Model(
                name="gpt-3.5-turbo",
                provider=ModelProvider.OPENAI,
                model_type=ModelType.CLOUD,
                endpoint="https://api.openai.com/v1",
                api_key="sk-xxx",
                max_tokens=4096
            ),
            Model(
                name="qwen-max",
                provider=ModelProvider.ALIYUN,
                model_type=ModelType.CLOUD,
                endpoint="https://dashscope.aliyuncs.com/api/v1",
                api_key="sk-xxx",
                max_tokens=8192
            ),
            Model(
                name="glm-4",
                provider=ModelProvider.ZHIPU,
                model_type=ModelType.CLOUD,
                endpoint="https://open.bigmodel.cn/api/paas/v4",
                api_key="sk-xxx",
                max_tokens=8192
            ),
        ]
        
        # 本地模型
        local_models = [
            Model(
                name="qwen2.5-7b-q4",
                provider=ModelProvider.OLLAMA,
                model_type=ModelType.LOCAL,
                endpoint="http://127.0.0.1:11434",
                max_tokens=4096
            ),
            Model(
                name="mistral-7b-q4",
                provider=ModelProvider.OLLAMA,
                model_type=ModelType.LOCAL,
                endpoint="http://127.0.0.1:11434",
                max_tokens=4096
            ),
        ]
        
        # 注册所有模型
        for model in cloud_models + local_models:
            self.models[model.name] = model
        
        # 设置默认模型
        self.default_model = "gpt-4"
        
        logger.info(f"已加载 {len(self.models)} 个模型")
    
    async def check_model_availability(self, model_name: Optional[str] = None) -> bool:
        """检查模型可用性"""
        model_name = model_name or self.default_model
        
        if model_name not in self.models:
            logger.warning(f"模型不存在: {model_name}")
            return False
        
        model = self.models[model_name]
        
        try:
            if model.model_type == ModelType.CLOUD:
                # TODO: 检查云端 API 连接
                model.is_available = True
            else:
                # TODO: 检查本地模型服务
                model.is_available = True
            
            return model.is_available
        except Exception as e:
            logger.error(f"检查模型可用性失败: {e}")
            model.is_available = False
            return False
    
    async def chat(
        self,
        message: str,
        model_name: Optional[str] = None,
        system_prompt: Optional[str] = None
    ) -> Dict[str, Any]:
        """进行聊天"""
        model_name = model_name or self.default_model
        
        if model_name not in self.models:
            return {
                "status": "error",
                "message": f"模型不存在: {model_name}"
            }
        
        model = self.models[model_name]
        
        # 检查模型可用性
        if not await self.check_model_availability(model_name):
            return {
                "status": "error",
                "message": f"模型不可用: {model_name}"
            }
        
        try:
            # 构建消息列表
            messages = []
            
            # 添加系统提示
            if system_prompt:
                messages.append({
                    "role": "system",
                    "content": system_prompt
                })
            
            # 添加对话历史
            messages.extend(self.conversation_history)
            
            # 添加当前消息
            messages.append({
                "role": "user",
                "content": message
            })
            
            # 调用模型
            response = await self._call_model(model, messages)
            
            # 保存对话历史
            self.conversation_history.append({
                "role": "user",
                "content": message
            })
            self.conversation_history.append({
                "role": "assistant",
                "content": response.get("content", "")
            })
            
            # 限制历史长度
            if len(self.conversation_history) > self.max_history_length:
                self.conversation_history = self.conversation_history[-self.max_history_length:]
            
            return {
                "status": "success",
                "model": model_name,
                "response": response.get("content", ""),
                "tokens_used": response.get("tokens_used", 0)
            }
        
        except Exception as e:
            logger.error(f"聊天失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _call_model(self, model: Model, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        """调用模型"""
        
        if model.model_type == ModelType.CLOUD:
            return await self._call_cloud_model(model, messages)
        else:
            return await self._call_local_model(model, messages)
    
    async def _call_cloud_model(self, model: Model, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        """调用云端模型 - 真实实现"""
        try:
            import requests
            
            logger.info(f"调用云端模型: {model.name}")
            
            # OpenAI 兼容接口
            if model.provider == ModelProvider.OPENAI:
                headers = {"Authorization": f"Bearer {model.api_key}"}
                data = {
                    "model": model.name,
                    "messages": messages,
                    "max_tokens": model.max_tokens,
                    "temperature": model.temperature
                }
                response = requests.post(f"{model.endpoint}/chat/completions", json=data, headers=headers, timeout=30)
                response.raise_for_status()
                result = response.json()
                return {
                    "content": result["choices"][0]["message"]["content"],
                    "tokens_used": result.get("usage", {}).get("total_tokens", 0)
                }
            
            # 阿里通义千问
            elif model.provider == ModelProvider.ALIYUN:
                headers = {"Authorization": f"Bearer {model.api_key}", "Content-Type": "application/json"}
                data = {
                    "model": model.name,
                    "messages": messages,
                    "max_tokens": model.max_tokens,
                    "temperature": model.temperature
                }
                response = requests.post(f"{model.endpoint}/chat/completions", json=data, headers=headers, timeout=30)
                response.raise_for_status()
                result = response.json()
                return {
                    "content": result["choices"][0]["message"]["content"],
                    "tokens_used": result.get("usage", {}).get("total_tokens", 0)
                }
            
            # 智谱 GLM
            elif model.provider == ModelProvider.ZHIPU:
                headers = {"Authorization": f"Bearer {model.api_key}", "Content-Type": "application/json"}
                data = {
                    "model": model.name,
                    "messages": messages,
                    "max_tokens": model.max_tokens,
                    "temperature": model.temperature
                }
                response = requests.post(f"{model.endpoint}/chat/completions", json=data, headers=headers, timeout=30)
                response.raise_for_status()
                result = response.json()
                return {
                    "content": result["choices"][0]["message"]["content"],
                    "tokens_used": result.get("usage", {}).get("total_tokens", 0)
                }
            
            else:
                logger.error(f"不支持的云端模型提供商: {model.provider}")
                return {"content": "不支持的模型提供商", "tokens_used": 0}
        
        except Exception as e:
            logger.error(f"调用云端模型失败: {e}")
            raise
    
    async def _call_local_model(self, model: Model, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        """调用本地模型 - 真实实现"""
        try:
            import requests
            
            logger.info(f"调用本地模型: {model.name}")
            
            # Ollama
            if model.provider == ModelProvider.OLLAMA:
                data = {
                    "model": model.name,
                    "messages": messages,
                    "stream": False
                }
                response = requests.post(f"{model.endpoint}/api/chat", json=data, timeout=60)
                response.raise_for_status()
                result = response.json()
                return {
                    "content": result.get("message", {}).get("content", ""),
                    "tokens_used": 0
                }
            
            # llama.cpp
            elif model.provider == ModelProvider.LLAMA_CPP:
                data = {
                    "prompt": messages[-1]["content"] if messages else "",
                    "n_predict": model.max_tokens,
                    "temperature": model.temperature
                }
                response = requests.post(f"{model.endpoint}/completion", json=data, timeout=60)
                response.raise_for_status()
                result = response.json()
                return {
                    "content": result.get("content", ""),
                    "tokens_used": 0
                }
            
            else:
                logger.error(f"不支持的本地模型提供商: {model.provider}")
                return {"content": "不支持的模型提供商", "tokens_used": 0}
        
        except Exception as e:
            logger.error(f"调用本地模型失败: {e}")
            raise
    
    def clear_history(self):
        """清除对话历史"""
        self.conversation_history = []
        logger.info("对话历史已清除")
    
    def get_available_models(self) -> Dict[str, Any]:
        """获取可用模型列表"""
        available = {}
        for name, model in self.models.items():
            available[name] = model.to_dict()
        return available
    
    def set_default_model(self, model_name: str) -> bool:
        """设置默认模型"""
        if model_name not in self.models:
            logger.warning(f"模型不存在: {model_name}")
            return False
        
        self.default_model = model_name
        logger.info(f"默认模型已设置为: {model_name}")
        return True
    
    async def get_model_info(self, model_name: Optional[str] = None) -> Dict[str, Any]:
        """获取模型信息"""
        model_name = model_name or self.default_model
        
        if model_name not in self.models:
            return {
                "status": "error",
                "message": f"模型不存在: {model_name}"
            }
        
        model = self.models[model_name]
        await self.check_model_availability(model_name)
        
        return {
            "status": "success",
            "model": model.to_dict()
        }
