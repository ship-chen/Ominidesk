"""
OmniDesk AI - 模型动态热重载系统
支持在运行时动态加载、卸载、切换 AI 模型
"""

import os
import sys
import importlib
import asyncio
import logging
from typing import Dict, Any, Optional, Callable, List
from dataclasses import dataclass, field
from datetime import datetime
import json

logger = logging.getLogger(__name__)


@dataclass
class ModelInfo:
    """模型信息"""
    name: str
    type: str  # "cloud" 或 "local"
    status: str  # "loaded", "loading", "unloaded", "error"
    loaded_at: Optional[float] = None
    error: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)


class ModelHotReloadManager:
    """AI 模型动态热重载管理器"""
    
    def __init__(self):
        self.models: Dict[str, ModelInfo] = {}
        self.loaded_models: Dict[str, Any] = {}
        self.current_model: Optional[str] = None
        self.model_callbacks: List[Callable] = []
        self.reload_lock = asyncio.Lock()
        
        logger.info("模型热重载管理器已初始化")
    
    async def register_model(self, name: str, model_type: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """注册模型"""
        try:
            model_info = ModelInfo(
                name=name,
                type=model_type,
                status="unloaded",
                config=config
            )
            
            self.models[name] = model_info
            
            logger.info(f"模型已注册: {name}")
            
            return {
                "status": "success",
                "message": f"模型 {name} 已注册",
                "model": name
            }
        
        except Exception as e:
            logger.error(f"注册模型失败: {e}")
            return {"status": "error", "message": str(e)}
    
    async def load_model(self, name: str) -> Dict[str, Any]:
        """加载模型"""
        async with self.reload_lock:
            try:
                if name not in self.models:
                    return {"status": "error", "message": f"模型 {name} 不存在"}
                
                model_info = self.models[name]
                
                # 如果已加载，直接返回
                if model_info.status == "loaded" and name in self.loaded_models:
                    logger.info(f"模型已加载: {name}")
                    return {
                        "status": "success",
                        "message": f"模型 {name} 已加载",
                        "model": name
                    }
                
                # 标记为加载中
                model_info.status = "loading"
                
                # 模拟加载模型
                logger.info(f"正在加载模型: {name}")
                await asyncio.sleep(0.5)  # 模拟加载时间
                
                # 创建模型实例
                model_instance = {
                    "name": name,
                    "type": model_info.type,
                    "config": model_info.config,
                    "loaded_at": datetime.now().isoformat()
                }
                
                self.loaded_models[name] = model_instance
                model_info.status = "loaded"
                model_info.loaded_at = datetime.now().timestamp()
                model_info.error = None
                
                logger.info(f"模型已加载: {name}")
                
                # 触发回调
                await self._trigger_callbacks("model_loaded", name)
                
                return {
                    "status": "success",
                    "message": f"模型 {name} 已加载",
                    "model": name,
                    "loaded_at": model_instance["loaded_at"]
                }
            
            except Exception as e:
                logger.error(f"加载模型失败: {e}")
                model_info = self.models[name]
                model_info.status = "error"
                model_info.error = str(e)
                
                return {"status": "error", "message": str(e)}
    
    async def unload_model(self, name: str) -> Dict[str, Any]:
        """卸载模型"""
        async with self.reload_lock:
            try:
                if name not in self.models:
                    return {"status": "error", "message": f"模型 {name} 不存在"}
                
                if name not in self.loaded_models:
                    return {"status": "error", "message": f"模型 {name} 未加载"}
                
                # 如果是当前模型，先切换到其他模型
                if self.current_model == name:
                    other_models = [m for m in self.loaded_models if m != name]
                    if other_models:
                        await self.switch_model(other_models[0])
                    else:
                        self.current_model = None
                
                # 卸载模型
                del self.loaded_models[name]
                self.models[name].status = "unloaded"
                
                logger.info(f"模型已卸载: {name}")
                
                # 触发回调
                await self._trigger_callbacks("model_unloaded", name)
                
                return {
                    "status": "success",
                    "message": f"模型 {name} 已卸载"
                }
            
            except Exception as e:
                logger.error(f"卸载模型失败: {e}")
                return {"status": "error", "message": str(e)}
    
    async def reload_model(self, name: str) -> Dict[str, Any]:
        """重新加载模型"""
        async with self.reload_lock:
            try:
                # 先卸载
                if name in self.loaded_models:
                    del self.loaded_models[name]
                
                # 再加载
                return await self.load_model(name)
            
            except Exception as e:
                logger.error(f"重新加载模型失败: {e}")
                return {"status": "error", "message": str(e)}
    
    async def switch_model(self, name: str) -> Dict[str, Any]:
        """切换当前模型"""
        try:
            if name not in self.models:
                return {"status": "error", "message": f"模型 {name} 不存在"}
            
            # 如果模型未加载，先加载
            if name not in self.loaded_models:
                result = await self.load_model(name)
                if result["status"] != "success":
                    return result
            
            old_model = self.current_model
            self.current_model = name
            
            logger.info(f"已切换模型: {old_model} -> {name}")
            
            # 触发回调
            await self._trigger_callbacks("model_switched", {
                "old_model": old_model,
                "new_model": name
            })
            
            return {
                "status": "success",
                "message": f"已切换到模型 {name}",
                "current_model": name,
                "previous_model": old_model
            }
        
        except Exception as e:
            logger.error(f"切换模型失败: {e}")
            return {"status": "error", "message": str(e)}
    
    async def get_model_status(self, name: Optional[str] = None) -> Dict[str, Any]:
        """获取模型状态"""
        try:
            if name:
                if name not in self.models:
                    return {"status": "error", "message": f"模型 {name} 不存在"}
                
                model_info = self.models[name]
                return {
                    "status": "success",
                    "model": {
                        "name": model_info.name,
                        "type": model_info.type,
                        "status": model_info.status,
                        "loaded": name in self.loaded_models,
                        "loaded_at": model_info.loaded_at,
                        "error": model_info.error,
                        "config": model_info.config
                    }
                }
            else:
                # 返回所有模型状态
                models_status = {}
                for name, model_info in self.models.items():
                    models_status[name] = {
                        "type": model_info.type,
                        "status": model_info.status,
                        "loaded": name in self.loaded_models,
                        "is_current": name == self.current_model,
                        "loaded_at": model_info.loaded_at,
                        "error": model_info.error
                    }
                
                return {
                    "status": "success",
                    "current_model": self.current_model,
                    "models": models_status
                }
        
        except Exception as e:
            logger.error(f"获取模型状态失败: {e}")
            return {"status": "error", "message": str(e)}
    
    async def list_models(self) -> Dict[str, Any]:
        """列出所有模型"""
        try:
            models_list = []
            for name, model_info in self.models.items():
                models_list.append({
                    "name": name,
                    "type": model_info.type,
                    "status": model_info.status,
                    "loaded": name in self.loaded_models,
                    "is_current": name == self.current_model
                })
            
            return {
                "status": "success",
                "total": len(models_list),
                "current_model": self.current_model,
                "models": models_list
            }
        
        except Exception as e:
            logger.error(f"列出模型失败: {e}")
            return {"status": "error", "message": str(e)}
    
    def register_callback(self, callback: Callable):
        """注册回调函数"""
        self.model_callbacks.append(callback)
    
    async def _trigger_callbacks(self, event: str, data: Any):
        """触发回调"""
        for callback in self.model_callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(event, data)
                else:
                    callback(event, data)
            except Exception as e:
                logger.error(f"回调执行失败: {e}")
