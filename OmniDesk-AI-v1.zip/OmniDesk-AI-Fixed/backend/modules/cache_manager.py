"""
缓存管理模块 - 新增功能
提供高效的缓存管理和过期策略
"""

import logging
import time
import hashlib
from typing import Dict, Any, Optional, Callable
from collections import OrderedDict

logger = logging.getLogger(__name__)


class CacheEntry:
    """缓存条目"""
    
    def __init__(self, key: str, value: Any, ttl: Optional[int] = None):
        self.key = key
        self.value = value
        self.ttl = ttl
        self.created_at = time.time()
        self.last_accessed = time.time()
        self.access_count = 0
    
    def is_expired(self) -> bool:
        """检查是否过期"""
        if self.ttl is None:
            return False
        return time.time() - self.created_at > self.ttl
    
    def access(self) -> Any:
        """访问缓存"""
        self.last_accessed = time.time()
        self.access_count += 1
        return self.value


class CacheManager:
    """缓存管理器"""
    
    def __init__(self, max_size: int = 1000, default_ttl: Optional[int] = 3600):
        """
        初始化缓存管理器
        
        Args:
            max_size: 最大缓存条目数
            default_ttl: 默认 TTL（秒）
        """
        self.max_size = max_size
        self.default_ttl = default_ttl
        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.stats = {
            "hits": 0,
            "misses": 0,
            "evictions": 0
        }
        
        logger.info(f"缓存管理器已初始化: 最大大小={max_size}, 默认TTL={default_ttl}秒")
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """设置缓存"""
        try:
            if ttl is None:
                ttl = self.default_ttl
            
            # 如果缓存已满，移除最旧的条目
            if len(self.cache) >= self.max_size and key not in self.cache:
                self._evict_lru()
            
            self.cache[key] = CacheEntry(key, value, ttl)
            # 将新条目移到末尾（最新）
            self.cache.move_to_end(key)
            
            logger.debug(f"缓存已设置: {key}")
        
        except Exception as e:
            logger.error(f"设置缓存失败: {e}")
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存"""
        try:
            if key not in self.cache:
                self.stats["misses"] += 1
                return None
            
            entry = self.cache[key]
            
            # 检查是否过期
            if entry.is_expired():
                del self.cache[key]
                self.stats["misses"] += 1
                return None
            
            # 更新访问信息
            value = entry.access()
            self.cache.move_to_end(key)  # 移到末尾（最新）
            self.stats["hits"] += 1
            
            logger.debug(f"缓存命中: {key}")
            return value
        
        except Exception as e:
            logger.error(f"获取缓存失败: {e}")
            return None
    
    def delete(self, key: str) -> bool:
        """删除缓存"""
        try:
            if key in self.cache:
                del self.cache[key]
                logger.debug(f"缓存已删除: {key}")
                return True
            return False
        
        except Exception as e:
            logger.error(f"删除缓存失败: {e}")
            return False
    
    def clear(self):
        """清空所有缓存"""
        self.cache.clear()
        logger.info("所有缓存已清空")
    
    def _evict_lru(self):
        """驱逐最近最少使用的条目"""
        try:
            # 移除第一个条目（最旧的）
            key, entry = self.cache.popitem(last=False)
            self.stats["evictions"] += 1
            logger.debug(f"已驱逐缓存: {key}")
        
        except Exception as e:
            logger.error(f"驱逐缓存失败: {e}")
    
    def cleanup_expired(self):
        """清理过期的缓存"""
        try:
            expired_keys = []
            for key, entry in self.cache.items():
                if entry.is_expired():
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.cache[key]
            
            logger.info(f"已清理 {len(expired_keys)} 个过期缓存")
            return len(expired_keys)
        
        except Exception as e:
            logger.error(f"清理过期缓存失败: {e}")
            return 0
    
    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计"""
        total = self.stats["hits"] + self.stats["misses"]
        hit_rate = (self.stats["hits"] / total * 100) if total > 0 else 0
        
        return {
            "size": len(self.cache),
            "max_size": self.max_size,
            "hits": self.stats["hits"],
            "misses": self.stats["misses"],
            "hit_rate": hit_rate,
            "evictions": self.stats["evictions"]
        }
    
    def get_cache_info(self, key: str) -> Optional[Dict[str, Any]]:
        """获取缓存条目信息"""
        try:
            if key not in self.cache:
                return None
            
            entry = self.cache[key]
            
            return {
                "key": key,
                "created_at": entry.created_at,
                "last_accessed": entry.last_accessed,
                "access_count": entry.access_count,
                "ttl": entry.ttl,
                "is_expired": entry.is_expired()
            }
        
        except Exception as e:
            logger.error(f"获取缓存信息失败: {e}")
            return None
