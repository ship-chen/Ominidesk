"""
OmniDesk AI - 实时协作和共享模块
支持多用户协作、任务共享、权限管理
"""

import asyncio
import json
from typing import Dict, List, Optional, Set
from datetime import datetime
from dataclasses import dataclass, asdict
from enum import Enum
import logging
import uuid

logger = logging.getLogger(__name__)

# ============================================================================
# 枚举定义
# ============================================================================

class CollaborationRole(Enum):
    """协作角色"""
    OWNER = "owner"          # 所有者
    ADMIN = "admin"          # 管理员
    EDITOR = "editor"        # 编辑者
    VIEWER = "viewer"        # 查看者
    COMMENTER = "commenter"  # 评论者

class ShareType(Enum):
    """共享类型"""
    PRIVATE = "private"      # 私有
    LINK = "link"            # 链接共享
    PUBLIC = "public"        # 公开
    TEAM = "team"            # 团队共享

# ============================================================================
# 数据模型
# ============================================================================

@dataclass
class Collaborator:
    """协作者"""
    user_id: str
    username: str
    role: CollaborationRole
    joined_at: str
    last_active: str

@dataclass
class Comment:
    """评论"""
    id: str
    user_id: str
    username: str
    content: str
    created_at: str
    updated_at: str
    replies: List['Comment'] = None

@dataclass
class SharedResource:
    """共享资源"""
    id: str
    resource_type: str  # task, vm, project
    resource_id: str
    owner_id: str
    share_type: ShareType
    collaborators: List[Collaborator]
    created_at: str
    updated_at: str
    access_link: Optional[str] = None
    expiry_date: Optional[str] = None

# ============================================================================
# 协作管理系统
# ============================================================================

class CollaborationManager:
    """协作管理系统"""
    
    def __init__(self):
        self.shared_resources: Dict[str, SharedResource] = {}
        self.comments: Dict[str, List[Comment]] = {}
        self.active_sessions: Dict[str, Set[str]] = {}  # resource_id -> {user_ids}
        self.notifications: Dict[str, List[Dict]] = {}  # user_id -> [notifications]
        
        logger.info("协作管理系统已初始化")
    
    # ========================================================================
    # 共享管理
    # ========================================================================
    
    async def share_resource(
        self,
        resource_type: str,
        resource_id: str,
        owner_id: str,
        share_type: ShareType,
        collaborators: List[Dict] = None
    ) -> SharedResource:
        """共享资源"""
        try:
            shared_id = str(uuid.uuid4())
            
            collab_list = []
            if collaborators:
                for collab in collaborators:
                    collab_list.append(Collaborator(
                        user_id=collab.get('user_id'),
                        username=collab.get('username'),
                        role=CollaborationRole[collab.get('role', 'VIEWER')],
                        joined_at=datetime.now().isoformat(),
                        last_active=datetime.now().isoformat()
                    ))
            
            # 添加所有者
            collab_list.insert(0, Collaborator(
                user_id=owner_id,
                username="owner",
                role=CollaborationRole.OWNER,
                joined_at=datetime.now().isoformat(),
                last_active=datetime.now().isoformat()
            ))
            
            access_link = None
            if share_type == ShareType.LINK:
                access_link = f"omnidesk://share/{shared_id}"
            
            shared_resource = SharedResource(
                id=shared_id,
                resource_type=resource_type,
                resource_id=resource_id,
                owner_id=owner_id,
                share_type=share_type,
                collaborators=collab_list,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                access_link=access_link
            )
            
            self.shared_resources[shared_id] = shared_resource
            
            # 发送通知
            for collab in collab_list:
                if collab.user_id != owner_id:
                    await self.send_notification(
                        collab.user_id,
                        f"您被邀请协作 {resource_type}",
                        "collaboration_invite",
                        {"shared_id": shared_id}
                    )
            
            logger.info(f"✅ 资源已共享: {shared_id}")
            return shared_resource
        
        except Exception as e:
            logger.error(f"❌ 共享资源失败: {e}")
            raise
    
    async def add_collaborator(
        self,
        shared_id: str,
        user_id: str,
        username: str,
        role: str
    ) -> bool:
        """添加协作者"""
        try:
            if shared_id not in self.shared_resources:
                return False
            
            shared = self.shared_resources[shared_id]
            
            # 检查是否已存在
            for collab in shared.collaborators:
                if collab.user_id == user_id:
                    return False
            
            # 添加新协作者
            new_collab = Collaborator(
                user_id=user_id,
                username=username,
                role=CollaborationRole[role],
                joined_at=datetime.now().isoformat(),
                last_active=datetime.now().isoformat()
            )
            
            shared.collaborators.append(new_collab)
            shared.updated_at = datetime.now().isoformat()
            
            # 发送通知
            await self.send_notification(
                user_id,
                f"您被添加为 {shared.resource_type} 的协作者",
                "collaborator_added",
                {"shared_id": shared_id}
            )
            
            logger.info(f"✅ 协作者已添加: {user_id}")
            return True
        
        except Exception as e:
            logger.error(f"❌ 添加协作者失败: {e}")
            return False
    
    async def remove_collaborator(self, shared_id: str, user_id: str) -> bool:
        """移除协作者"""
        try:
            if shared_id not in self.shared_resources:
                return False
            
            shared = self.shared_resources[shared_id]
            
            # 不能移除所有者
            for collab in shared.collaborators:
                if collab.user_id == user_id and collab.role == CollaborationRole.OWNER:
                    return False
            
            # 移除协作者
            shared.collaborators = [
                c for c in shared.collaborators
                if c.user_id != user_id
            ]
            
            shared.updated_at = datetime.now().isoformat()
            
            logger.info(f"✅ 协作者已移除: {user_id}")
            return True
        
        except Exception as e:
            logger.error(f"❌ 移除协作者失败: {e}")
            return False
    
    async def update_collaborator_role(
        self,
        shared_id: str,
        user_id: str,
        new_role: str
    ) -> bool:
        """更新协作者角色"""
        try:
            if shared_id not in self.shared_resources:
                return False
            
            shared = self.shared_resources[shared_id]
            
            for collab in shared.collaborators:
                if collab.user_id == user_id:
                    collab.role = CollaborationRole[new_role]
                    shared.updated_at = datetime.now().isoformat()
                    
                    logger.info(f"✅ 协作者角色已更新: {user_id} -> {new_role}")
                    return True
            
            return False
        
        except Exception as e:
            logger.error(f"❌ 更新协作者角色失败: {e}")
            return False
    
    # ========================================================================
    # 评论系统
    # ========================================================================
    
    async def add_comment(
        self,
        resource_id: str,
        user_id: str,
        username: str,
        content: str
    ) -> Comment:
        """添加评论"""
        try:
            comment_id = str(uuid.uuid4())
            
            comment = Comment(
                id=comment_id,
                user_id=user_id,
                username=username,
                content=content,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                replies=[]
            )
            
            if resource_id not in self.comments:
                self.comments[resource_id] = []
            
            self.comments[resource_id].append(comment)
            
            # 发送通知
            await self.send_notification(
                resource_id,
                f"{username} 添加了评论",
                "comment_added",
                {"comment_id": comment_id}
            )
            
            logger.info(f"✅ 评论已添加: {comment_id}")
            return comment
        
        except Exception as e:
            logger.error(f"❌ 添加评论失败: {e}")
            raise
    
    async def add_reply(
        self,
        resource_id: str,
        comment_id: str,
        user_id: str,
        username: str,
        content: str
    ) -> Optional[Comment]:
        """添加回复"""
        try:
            if resource_id not in self.comments:
                return None
            
            reply_id = str(uuid.uuid4())
            
            reply = Comment(
                id=reply_id,
                user_id=user_id,
                username=username,
                content=content,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat()
            )
            
            for comment in self.comments[resource_id]:
                if comment.id == comment_id:
                    if comment.replies is None:
                        comment.replies = []
                    comment.replies.append(reply)
                    
                    logger.info(f"✅ 回复已添加: {reply_id}")
                    return reply
            
            return None
        
        except Exception as e:
            logger.error(f"❌ 添加回复失败: {e}")
            return None
    
    async def get_comments(self, resource_id: str) -> List[Comment]:
        """获取评论"""
        return self.comments.get(resource_id, [])
    
    # ========================================================================
    # 活跃会话
    # ========================================================================
    
    async def join_session(self, resource_id: str, user_id: str) -> bool:
        """加入会话"""
        try:
            if resource_id not in self.active_sessions:
                self.active_sessions[resource_id] = set()
            
            self.active_sessions[resource_id].add(user_id)
            
            logger.info(f"✅ 用户已加入会话: {user_id} -> {resource_id}")
            return True
        
        except Exception as e:
            logger.error(f"❌ 加入会话失败: {e}")
            return False
    
    async def leave_session(self, resource_id: str, user_id: str) -> bool:
        """离开会话"""
        try:
            if resource_id in self.active_sessions:
                self.active_sessions[resource_id].discard(user_id)
                
                if not self.active_sessions[resource_id]:
                    del self.active_sessions[resource_id]
            
            logger.info(f"✅ 用户已离开会话: {user_id} -> {resource_id}")
            return True
        
        except Exception as e:
            logger.error(f"❌ 离开会话失败: {e}")
            return False
    
    async def get_active_users(self, resource_id: str) -> List[str]:
        """获取活跃用户"""
        return list(self.active_sessions.get(resource_id, set()))
    
    # ========================================================================
    # 通知系统
    # ========================================================================
    
    async def send_notification(
        self,
        user_id: str,
        message: str,
        notification_type: str,
        data: Dict = None
    ) -> bool:
        """发送通知"""
        try:
            if user_id not in self.notifications:
                self.notifications[user_id] = []
            
            notification = {
                "id": str(uuid.uuid4()),
                "message": message,
                "type": notification_type,
                "data": data or {},
                "timestamp": datetime.now().isoformat(),
                "read": False
            }
            
            self.notifications[user_id].append(notification)
            
            # 保持最近 100 条通知
            if len(self.notifications[user_id]) > 100:
                self.notifications[user_id] = self.notifications[user_id][-100:]
            
            logger.info(f"✅ 通知已发送: {user_id}")
            return True
        
        except Exception as e:
            logger.error(f"❌ 发送通知失败: {e}")
            return False
    
    async def get_notifications(self, user_id: str) -> List[Dict]:
        """获取通知"""
        return self.notifications.get(user_id, [])
    
    async def mark_notification_read(self, user_id: str, notification_id: str) -> bool:
        """标记通知为已读"""
        try:
            if user_id in self.notifications:
                for notif in self.notifications[user_id]:
                    if notif["id"] == notification_id:
                        notif["read"] = True
                        return True
            
            return False
        
        except Exception as e:
            logger.error(f"❌ 标记通知失败: {e}")
            return False
    
    # ========================================================================
    # 权限检查
    # ========================================================================
    
    async def check_permission(
        self,
        shared_id: str,
        user_id: str,
        action: str
    ) -> bool:
        """检查权限"""
        try:
            if shared_id not in self.shared_resources:
                return False
            
            shared = self.shared_resources[shared_id]
            
            # 查找用户角色
            user_role = None
            for collab in shared.collaborators:
                if collab.user_id == user_id:
                    user_role = collab.role
                    break
            
            if user_role is None:
                return False
            
            # 权限检查
            permissions = {
                CollaborationRole.OWNER: ["read", "write", "delete", "share", "manage"],
                CollaborationRole.ADMIN: ["read", "write", "delete", "share"],
                CollaborationRole.EDITOR: ["read", "write"],
                CollaborationRole.COMMENTER: ["read", "comment"],
                CollaborationRole.VIEWER: ["read"]
            }
            
            return action in permissions.get(user_role, [])
        
        except Exception as e:
            logger.error(f"❌ 权限检查失败: {e}")
            return False
