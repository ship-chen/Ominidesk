"""
双层权限隔离模块 - L1 基础功能
虚拟机内自由操作，宿主机操作需要用户审批
"""

import logging
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import time

logger = logging.getLogger(__name__)


class OperationScope(Enum):
    """操作范围"""
    VM_ONLY = "vm_only"  # 仅虚拟机内
    HOST_ONLY = "host_only"  # 仅宿主机
    BOTH = "both"  # 两者都可以


class PermissionLevel(Enum):
    """权限级别"""
    UNRESTRICTED = "unrestricted"  # 无限制（虚拟机内）
    RESTRICTED = "restricted"  # 受限（宿主机）
    DANGEROUS = "dangerous"  # 危险操作（需要审批）
    FORBIDDEN = "forbidden"  # 禁止


@dataclass
class OperationRequest:
    """操作请求"""
    request_id: str
    operation_type: str
    target: str
    scope: OperationScope
    permission_level: PermissionLevel
    description: str
    timestamp: float = field(default_factory=time.time)
    approved: Optional[bool] = None
    approval_timestamp: Optional[float] = None
    approval_reason: Optional[str] = None


@dataclass
class PermissionPolicy:
    """权限策略"""
    operation_type: str
    vm_permission: PermissionLevel
    host_permission: PermissionLevel
    requires_approval: bool = False
    approval_timeout: float = 30.0  # 30 秒内必须审批


class DualLayerPermissionManager:
    """双层权限管理器"""
    
    def __init__(self):
        self.policies: Dict[str, PermissionPolicy] = {}
        self.pending_requests: Dict[str, OperationRequest] = {}
        self.approval_callbacks: List[Callable] = []
        self.operation_history: List[OperationRequest] = []
        
        self._init_default_policies()
        
        logger.info("双层权限管理器已初始化")
    
    def _init_default_policies(self):
        """初始化默认权限策略"""
        self.policies = {
            # 文件操作
            "file_read": PermissionPolicy(
                operation_type="file_read",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.RESTRICTED,
                requires_approval=False
            ),
            "file_write": PermissionPolicy(
                operation_type="file_write",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.RESTRICTED,
                requires_approval=True
            ),
            "file_delete": PermissionPolicy(
                operation_type="file_delete",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.DANGEROUS,
                requires_approval=True
            ),
            
            # 网络操作
            "network_access": PermissionPolicy(
                operation_type="network_access",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.RESTRICTED,
                requires_approval=False
            ),
            "network_upload": PermissionPolicy(
                operation_type="network_upload",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.DANGEROUS,
                requires_approval=True
            ),
            
            # 系统操作
            "process_create": PermissionPolicy(
                operation_type="process_create",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.DANGEROUS,
                requires_approval=True
            ),
            "process_kill": PermissionPolicy(
                operation_type="process_kill",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.DANGEROUS,
                requires_approval=True
            ),
            
            # 虚拟机操作
            "vm_control": PermissionPolicy(
                operation_type="vm_control",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.RESTRICTED,
                requires_approval=False
            ),
            "vm_snapshot": PermissionPolicy(
                operation_type="vm_snapshot",
                vm_permission=PermissionLevel.UNRESTRICTED,
                host_permission=PermissionLevel.RESTRICTED,
                requires_approval=False
            ),
        }
        
        logger.info(f"已加载 {len(self.policies)} 个默认权限策略")
    
    async def check_permission(self, operation_type: str, target: str, scope: OperationScope) -> bool:
        """
        检查权限
        
        Args:
            operation_type: 操作类型
            target: 操作目标
            scope: 操作范围
        
        Returns:
            是否有权限
        """
        policy = self.policies.get(operation_type)
        
        if not policy:
            logger.warning(f"未知的操作类型: {operation_type}")
            return False
        
        # 虚拟机内操作
        if scope == OperationScope.VM_ONLY:
            permission = policy.vm_permission
            if permission == PermissionLevel.UNRESTRICTED:
                return True
            elif permission == PermissionLevel.RESTRICTED:
                return True  # 虚拟机内受限操作也允许
            else:
                return False
        
        # 宿主机操作
        elif scope == OperationScope.HOST_ONLY:
            permission = policy.host_permission
            if permission == PermissionLevel.UNRESTRICTED:
                return True
            elif permission == PermissionLevel.RESTRICTED:
                return True  # 受限操作允许
            elif permission == PermissionLevel.DANGEROUS:
                return False  # 危险操作需要审批
            else:
                return False
        
        return False
    
    async def request_operation(self, operation_type: str, target: str, scope: OperationScope, description: str = "") -> OperationRequest:
        """
        请求操作
        
        Args:
            operation_type: 操作类型
            target: 操作目标
            scope: 操作范围
            description: 操作描述
        
        Returns:
            操作请求
        """
        request_id = f"op_{int(time.time() * 1000)}"
        
        policy = self.policies.get(operation_type)
        if not policy:
            logger.error(f"未知的操作类型: {operation_type}")
            permission_level = PermissionLevel.FORBIDDEN
        else:
            if scope == OperationScope.VM_ONLY:
                permission_level = policy.vm_permission
            else:
                permission_level = policy.host_permission
        
        request = OperationRequest(
            request_id=request_id,
            operation_type=operation_type,
            target=target,
            scope=scope,
            permission_level=permission_level,
            description=description
        )
        
        # 虚拟机内的无限制操作直接允许
        if scope == OperationScope.VM_ONLY and permission_level == PermissionLevel.UNRESTRICTED:
            request.approved = True
            request.approval_timestamp = time.time()
            logger.info(f"虚拟机内操作自动批准: {request_id}")
        
        # 危险操作需要用户审批
        elif permission_level == PermissionLevel.DANGEROUS:
            self.pending_requests[request_id] = request
            logger.warning(f"危险操作需要审批: {request_id} - {operation_type} {target}")
            
            # 触发审批回调
            for callback in self.approval_callbacks:
                try:
                    await callback(request)
                except Exception as e:
                    logger.error(f"审批回调错误: {e}")
        
        else:
            request.approved = True
            request.approval_timestamp = time.time()
            logger.info(f"操作自动批准: {request_id}")
        
        self.operation_history.append(request)
        return request
    
    async def approve_operation(self, request_id: str, reason: str = "") -> bool:
        """
        批准操作
        
        Args:
            request_id: 请求 ID
            reason: 批准原因
        
        Returns:
            是否成功批准
        """
        if request_id not in self.pending_requests:
            logger.warning(f"请求不存在: {request_id}")
            return False
        
        request = self.pending_requests[request_id]
        request.approved = True
        request.approval_timestamp = time.time()
        request.approval_reason = reason
        
        del self.pending_requests[request_id]
        
        logger.info(f"操作已批准: {request_id}")
        return True
    
    async def reject_operation(self, request_id: str, reason: str = "") -> bool:
        """
        拒绝操作
        
        Args:
            request_id: 请求 ID
            reason: 拒绝原因
        
        Returns:
            是否成功拒绝
        """
        if request_id not in self.pending_requests:
            logger.warning(f"请求不存在: {request_id}")
            return False
        
        request = self.pending_requests[request_id]
        request.approved = False
        request.approval_timestamp = time.time()
        request.approval_reason = reason
        
        del self.pending_requests[request_id]
        
        logger.info(f"操作已拒绝: {request_id}")
        return True
    
    async def get_pending_requests(self) -> List[OperationRequest]:
        """获取待审批的请求"""
        return list(self.pending_requests.values())
    
    async def get_operation_history(self, limit: int = 100) -> List[OperationRequest]:
        """获取操作历史"""
        return self.operation_history[-limit:]
    
    def register_approval_callback(self, callback: Callable):
        """注册审批回调"""
        self.approval_callbacks.append(callback)
    
    async def add_policy(self, policy: PermissionPolicy):
        """添加权限策略"""
        self.policies[policy.operation_type] = policy
        logger.info(f"已添加权限策略: {policy.operation_type}")
    
    async def update_policy(self, operation_type: str, vm_permission: PermissionLevel = None, host_permission: PermissionLevel = None):
        """更新权限策略"""
        if operation_type not in self.policies:
            logger.warning(f"策略不存在: {operation_type}")
            return False
        
        policy = self.policies[operation_type]
        if vm_permission:
            policy.vm_permission = vm_permission
        if host_permission:
            policy.host_permission = host_permission
        
        logger.info(f"已更新权限策略: {operation_type}")
        return True
