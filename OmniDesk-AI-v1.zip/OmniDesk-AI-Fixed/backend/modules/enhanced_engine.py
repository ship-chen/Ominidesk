#!/usr/bin/env python3
"""
增强的引擎模块 - 多功能、高稳定性、完整错误处理
支持多模型、缓存、重试、日志记录
"""

import logging
import asyncio
import json
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import hashlib
import time

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ModelType(Enum):
    """模型类型"""
    GPT4 = "gpt-4"
    GPT35 = "gpt-3.5-turbo"
    CLAUDE3 = "claude-3"
    LLAMA2 = "llama-2"
    LOCAL = "local"


@dataclass
class TaskResult:
    """任务结果"""
    task_id: str
    status: TaskStatus
    result: Any = None
    error: Optional[str] = None
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    duration: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'status': self.status.value,
            'result': self.result,
            'error': self.error,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration': self.duration
        }


class ResponseCache:
    """响应缓存 - 提高性能"""
    
    def __init__(self, ttl: int = 3600):
        """
        初始化缓存
        
        Args:
            ttl: 缓存过期时间（秒）
        """
        self.cache: Dict[str, Tuple[Any, datetime]] = {}
        self.ttl = ttl
    
    def _get_key(self, model: str, prompt: str) -> str:
        """生成缓存键"""
        content = f"{model}:{prompt}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def get(self, model: str, prompt: str) -> Optional[Any]:
        """获取缓存"""
        key = self._get_key(model, prompt)
        
        if key in self.cache:
            result, timestamp = self.cache[key]
            if datetime.now() - timestamp < timedelta(seconds=self.ttl):
                logger.debug(f"缓存命中: {key}")
                return result
            else:
                del self.cache[key]
        
        return None
    
    def set(self, model: str, prompt: str, result: Any):
        """设置缓存"""
        key = self._get_key(model, prompt)
        self.cache[key] = (result, datetime.now())
        logger.debug(f"缓存设置: {key}")
    
    def clear(self):
        """清空缓存"""
        self.cache.clear()
        logger.info("缓存已清空")


class EnhancedEngine:
    """增强的引擎 - 多功能、高稳定性"""
    
    def __init__(self, max_retries: int = 3, cache_ttl: int = 3600):
        """
        初始化引擎
        
        Args:
            max_retries: 最大重试次数
            cache_ttl: 缓存过期时间（秒）
        """
        self.max_retries = max_retries
        self.cache = ResponseCache(ttl=cache_ttl)
        self.tasks: Dict[str, TaskResult] = {}
        self.model_configs = self._init_model_configs()
        logger.info("增强引擎已初始化")
    
    def _init_model_configs(self) -> Dict[str, Dict[str, Any]]:
        """初始化模型配置"""
        return {
            ModelType.GPT4.value: {
                'name': 'GPT-4',
                'max_tokens': 8192,
                'temperature': 0.7,
                'timeout': 60
            },
            ModelType.GPT35.value: {
                'name': 'GPT-3.5-Turbo',
                'max_tokens': 4096,
                'temperature': 0.7,
                'timeout': 30
            },
            ModelType.CLAUDE3.value: {
                'name': 'Claude-3',
                'max_tokens': 4096,
                'temperature': 0.7,
                'timeout': 45
            },
            ModelType.LLAMA2.value: {
                'name': 'Llama-2-70B',
                'max_tokens': 2048,
                'temperature': 0.7,
                'timeout': 30
            },
            ModelType.LOCAL.value: {
                'name': 'Local Model',
                'max_tokens': 2048,
                'temperature': 0.7,
                'timeout': 15
            }
        }
    
    # ========================================================================
    # 核心功能
    # ========================================================================
    
    async def process_task(self, task_id: str, model: str, prompt: str, 
                          context: Optional[Dict[str, Any]] = None) -> TaskResult:
        """
        处理任务 - 带重试和缓存
        
        Args:
            task_id: 任务 ID
            model: 模型类型
            prompt: 提示词
            context: 上下文信息
        
        Returns:
            任务结果
        """
        result = TaskResult(task_id=task_id, status=TaskStatus.PENDING)
        self.tasks[task_id] = result
        
        try:
            # 检查缓存
            cached = self.cache.get(model, prompt)
            if cached:
                result.status = TaskStatus.COMPLETED
                result.result = cached
                result.end_time = datetime.now()
                result.duration = (result.end_time - result.start_time).total_seconds()
                logger.info(f"任务完成（缓存）: {task_id}")
                return result
            
            # 更新状态为运行中
            result.status = TaskStatus.RUNNING
            
            # 执行任务（带重试）
            response = await self._execute_with_retry(model, prompt, context)
            
            # 缓存结果
            self.cache.set(model, prompt, response)
            
            # 更新结果
            result.status = TaskStatus.COMPLETED
            result.result = response
            result.end_time = datetime.now()
            result.duration = (result.end_time - result.start_time).total_seconds()
            
            logger.info(f"任务完成: {task_id} (耗时: {result.duration:.2f}s)")
        
        except asyncio.TimeoutError:
            result.status = TaskStatus.FAILED
            result.error = "任务执行超时"
            result.end_time = datetime.now()
            result.duration = (result.end_time - result.start_time).total_seconds()
            logger.error(f"任务超时: {task_id}")
        
        except Exception as e:
            result.status = TaskStatus.FAILED
            result.error = str(e)
            result.end_time = datetime.now()
            result.duration = (result.end_time - result.start_time).total_seconds()
            logger.error(f"任务失败: {task_id} - {e}")
        
        return result
    
    async def _execute_with_retry(self, model: str, prompt: str, 
                                  context: Optional[Dict[str, Any]] = None) -> str:
        """
        执行任务（带重试）
        
        Args:
            model: 模型类型
            prompt: 提示词
            context: 上下文信息
        
        Returns:
            响应文本
        """
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                logger.debug(f"执行任务 - 尝试 {attempt + 1}/{self.max_retries}")
                
                # 模拟 AI 调用
                response = await self._call_model(model, prompt, context)
                return response
            
            except Exception as e:
                last_error = e
                logger.warning(f"尝试 {attempt + 1} 失败: {e}")
                
                if attempt < self.max_retries - 1:
                    # 指数退避
                    wait_time = 2 ** attempt
                    logger.info(f"等待 {wait_time} 秒后重试...")
                    await asyncio.sleep(wait_time)
        
        raise last_error or Exception("所有重试均失败")
    
    async def _call_model(self, model: str, prompt: str, 
                         context: Optional[Dict[str, Any]] = None) -> str:
        """
        调用模型
        
        Args:
            model: 模型类型
            prompt: 提示词
            context: 上下文信息
        
        Returns:
            响应文本
        """
        config = self.model_configs.get(model, self.model_configs[ModelType.LOCAL.value])
        
        try:
            # 这里应该调用实际的 API
            # 现在是模拟实现
            await asyncio.sleep(0.5)  # 模拟处理时间
            
            # 生成模拟响应
            response = f"[{config['name']}] 处理了您的请求: {prompt[:50]}..."
            
            logger.debug(f"模型响应: {model}")
            return response
        
        except Exception as e:
            logger.error(f"模型调用失败: {model} - {e}")
            raise
    
    # ========================================================================
    # 任务管理
    # ========================================================================
    
    def get_task(self, task_id: str) -> Optional[TaskResult]:
        """获取任务结果"""
        return self.tasks.get(task_id)
    
    def get_all_tasks(self) -> List[TaskResult]:
        """获取所有任务"""
        return list(self.tasks.values())
    
    def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        if task_id in self.tasks:
            self.tasks[task_id].status = TaskStatus.CANCELLED
            logger.info(f"任务已取消: {task_id}")
            return True
        return False
    
    def clear_tasks(self, status: Optional[TaskStatus] = None):
        """清空任务"""
        if status:
            self.tasks = {
                k: v for k, v in self.tasks.items()
                if v.status != status
            }
            logger.info(f"已清空状态为 {status.value} 的任务")
        else:
            self.tasks.clear()
            logger.info("所有任务已清空")
    
    # ========================================================================
    # 模型管理
    # ========================================================================
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """获取可用模型"""
        return [
            {
                'name': config['name'],
                'type': model_type,
                'max_tokens': config['max_tokens'],
                'temperature': config['temperature']
            }
            for model_type, config in self.model_configs.items()
        ]
    
    def set_model_config(self, model: str, config: Dict[str, Any]) -> bool:
        """设置模型配置"""
        if model in self.model_configs:
            self.model_configs[model].update(config)
            logger.info(f"模型配置已更新: {model}")
            return True
        return False
    
    def get_model_config(self, model: str) -> Optional[Dict[str, Any]]:
        """获取模型配置"""
        return self.model_configs.get(model)
    
    # ========================================================================
    # 统计信息
    # ========================================================================
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        total_tasks = len(self.tasks)
        completed = sum(1 for t in self.tasks.values() if t.status == TaskStatus.COMPLETED)
        failed = sum(1 for t in self.tasks.values() if t.status == TaskStatus.FAILED)
        running = sum(1 for t in self.tasks.values() if t.status == TaskStatus.RUNNING)
        
        total_duration = sum(t.duration for t in self.tasks.values() if t.duration > 0)
        avg_duration = total_duration / completed if completed > 0 else 0
        
        return {
            'total_tasks': total_tasks,
            'completed': completed,
            'failed': failed,
            'running': running,
            'pending': total_tasks - completed - failed - running,
            'total_duration': total_duration,
            'average_duration': avg_duration,
            'cache_size': len(self.cache.cache),
            'success_rate': (completed / total_tasks * 100) if total_tasks > 0 else 0
        }
    
    # ========================================================================
    # 批量处理
    # ========================================================================
    
    async def process_batch(self, tasks: List[Dict[str, Any]]) -> List[TaskResult]:
        """
        批量处理任务
        
        Args:
            tasks: 任务列表
        
        Returns:
            结果列表
        """
        results = []
        
        for task in tasks:
            result = await self.process_task(
                task_id=task.get('task_id', f"batch_{int(time.time())}"),
                model=task.get('model', ModelType.GPT4.value),
                prompt=task.get('prompt', ''),
                context=task.get('context')
            )
            results.append(result)
        
        logger.info(f"批量处理完成: {len(tasks)} 个任务")
        return results
    
    # ========================================================================
    # 健康检查
    # ========================================================================
    
    async def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        try:
            # 测试模型调用
            test_result = await self._call_model(
                ModelType.LOCAL.value,
                "test"
            )
            
            return {
                'status': 'healthy',
                'timestamp': datetime.now().isoformat(),
                'test_response': test_result[:50] + "...",
                'cache_size': len(self.cache.cache),
                'tasks_count': len(self.tasks)
            }
        
        except Exception as e:
            return {
                'status': 'unhealthy',
                'timestamp': datetime.now().isoformat(),
                'error': str(e)
            }


# 导出
__all__ = [
    'EnhancedEngine',
    'TaskResult',
    'TaskStatus',
    'ModelType',
    'ResponseCache'
]
