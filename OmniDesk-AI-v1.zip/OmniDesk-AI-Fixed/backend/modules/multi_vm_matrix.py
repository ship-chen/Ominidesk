"""
多虚拟机矩阵模块 - L3 高级功能
支持同时控制多台虚拟机，自动安装软件，知识迁移
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import time

logger = logging.getLogger(__name__)


class VMRole(Enum):
    """虚拟机角色"""
    MASTER = "master"  # 主节点
    WORKER = "worker"  # 工作节点
    BACKUP = "backup"  # 备份节点


class TaskDistributionStrategy(Enum):
    """任务分发策略"""
    ROUND_ROBIN = "round_robin"  # 轮询
    LOAD_BALANCED = "load_balanced"  # 负载均衡
    AFFINITY = "affinity"  # 亲和性（相同任务到同一 VM）


@dataclass
class VMNode:
    """虚拟机节点"""
    vm_id: str
    role: VMRole
    status: str = "idle"  # idle, busy, error
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    task_count: int = 0
    skills: Set[str] = field(default_factory=set)
    knowledge_base: Dict[str, Any] = field(default_factory=dict)
    last_heartbeat: float = field(default_factory=time.time)


@dataclass
class DistributedTask:
    """分布式任务"""
    task_id: str
    description: str
    assigned_vm: Optional[str] = None
    status: str = "pending"  # pending, assigned, executing, completed, failed
    result: Optional[Any] = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None


@dataclass
class SoftwarePackage:
    """软件包"""
    package_id: str
    name: str
    version: str
    url: str
    install_script: str
    dependencies: List[str] = field(default_factory=list)
    installed_on: List[str] = field(default_factory=list)  # 已安装的 VM ID


class MultiVMMatrixManager:
    """多虚拟机矩阵管理器"""
    
    def __init__(self):
        self.vm_nodes: Dict[str, VMNode] = {}
        self.distributed_tasks: Dict[str, DistributedTask] = {}
        self.software_packages: Dict[str, SoftwarePackage] = {}
        self.task_distribution_strategy = TaskDistributionStrategy.LOAD_BALANCED
        self.knowledge_transfer_enabled = True
        self.task_counter = 0
        
        logger.info("多虚拟机矩阵管理器已初始化")
    
    async def register_vm(self, vm_id: str, role: VMRole = VMRole.WORKER) -> bool:
        """注册虚拟机"""
        if vm_id not in self.vm_nodes:
            self.vm_nodes[vm_id] = VMNode(vm_id=vm_id, role=role)
            logger.info(f"虚拟机已注册: {vm_id} (角色: {role.value})")
            return True
        return False
    
    async def unregister_vm(self, vm_id: str) -> bool:
        """注销虚拟机"""
        if vm_id in self.vm_nodes:
            del self.vm_nodes[vm_id]
            logger.info(f"虚拟机已注销: {vm_id}")
            return True
        return False
    
    async def distribute_task(self, description: str) -> DistributedTask:
        """
        分发任务到虚拟机矩阵
        
        Args:
            description: 任务描述
        
        Returns:
            分布式任务
        """
        self.task_counter += 1
        task_id = f"dtask_{self.task_counter}"
        
        task = DistributedTask(
            task_id=task_id,
            description=description
        )
        
        # 选择目标虚拟机
        target_vm = await self._select_target_vm()
        
        if target_vm:
            task.assigned_vm = target_vm
            task.status = "assigned"
            self.vm_nodes[target_vm].task_count += 1
            
            logger.info(f"任务已分发: {task_id} -> {target_vm}")
        else:
            task.status = "failed"
            task.error = "没有可用的虚拟机"
            logger.warning(f"任务分发失败: {task_id} - 没有可用的虚拟机")
        
        self.distributed_tasks[task_id] = task
        return task
    
    async def _select_target_vm(self) -> Optional[str]:
        """根据策略选择目标虚拟机"""
        available_vms = [vm for vm in self.vm_nodes.values() if vm.status == "idle"]
        
        if not available_vms:
            return None
        
        if self.task_distribution_strategy == TaskDistributionStrategy.ROUND_ROBIN:
            return available_vms[0].vm_id
        
        elif self.task_distribution_strategy == TaskDistributionStrategy.LOAD_BALANCED:
            # 选择 CPU 使用率最低的虚拟机
            return min(available_vms, key=lambda vm: vm.cpu_usage).vm_id
        
        elif self.task_distribution_strategy == TaskDistributionStrategy.AFFINITY:
            # 选择具有相关技能的虚拟机
            return available_vms[0].vm_id
        
        return available_vms[0].vm_id
    
    async def transfer_knowledge(self, source_vm: str, target_vms: List[str]) -> bool:
        """
        知识迁移 - 将源 VM 的知识转移到目标 VM
        
        Args:
            source_vm: 源虚拟机 ID
            target_vms: 目标虚拟机 ID 列表
        
        Returns:
            是否成功
        """
        try:
            if source_vm not in self.vm_nodes:
                logger.error(f"源虚拟机不存在: {source_vm}")
                return False
            
            source_node = self.vm_nodes[source_vm]
            knowledge = source_node.knowledge_base.copy()
            
            logger.info(f"开始知识迁移: {source_vm} -> {target_vms}")
            
            for target_vm in target_vms:
                if target_vm not in self.vm_nodes:
                    logger.warning(f"目标虚拟机不存在: {target_vm}")
                    continue
                
                target_node = self.vm_nodes[target_vm]
                
                # 合并知识库
                target_node.knowledge_base.update(knowledge)
                
                # 转移技能
                target_node.skills.update(source_node.skills)
                
                logger.info(f"知识已迁移到: {target_vm}")
            
            return True
        
        except Exception as e:
            logger.error(f"知识迁移失败: {e}")
            return False
    
    async def auto_install_software(self, package_id: str, target_vms: List[str] = None) -> bool:
        """
        自动安装软件
        
        Args:
            package_id: 软件包 ID
            target_vms: 目标虚拟机列表（如果为 None，则安装到所有虚拟机）
        
        Returns:
            是否成功
        """
        try:
            if package_id not in self.software_packages:
                logger.error(f"软件包不存在: {package_id}")
                return False
            
            package = self.software_packages[package_id]
            
            # 确定目标虚拟机
            if target_vms is None:
                target_vms = list(self.vm_nodes.keys())
            
            logger.info(f"开始安装软件: {package.name} v{package.version} 到 {len(target_vms)} 个虚拟机")
            
            for vm_id in target_vms:
                if vm_id not in self.vm_nodes:
                    logger.warning(f"虚拟机不存在: {vm_id}")
                    continue
                
                try:
                    # 检查依赖
                    for dep in package.dependencies:
                        if dep not in self.software_packages:
                            logger.warning(f"依赖不存在: {dep}")
                    
                    # 执行安装脚本
                    logger.info(f"在 {vm_id} 上安装 {package.name}")
                    
                    # 这里应该实际执行安装脚本
                    # 现在是模拟
                    await asyncio.sleep(0.5)
                    
                    package.installed_on.append(vm_id)
                    self.vm_nodes[vm_id].skills.add(package.name)
                    
                    logger.info(f"{package.name} 已安装到 {vm_id}")
                
                except Exception as e:
                    logger.error(f"在 {vm_id} 上安装 {package.name} 失败: {e}")
            
            return True
        
        except Exception as e:
            logger.error(f"自动安装软件失败: {e}")
            return False
    
    async def register_software_package(self, name: str, version: str, url: str, 
                                       install_script: str, dependencies: List[str] = None) -> SoftwarePackage:
        """注册软件包"""
        package_id = f"pkg_{int(time.time() * 1000)}"
        
        package = SoftwarePackage(
            package_id=package_id,
            name=name,
            version=version,
            url=url,
            install_script=install_script,
            dependencies=dependencies or []
        )
        
        self.software_packages[package_id] = package
        logger.info(f"软件包已注册: {name} v{version}")
        
        return package
    
    async def get_vm_status(self) -> Dict[str, Any]:
        """获取虚拟机矩阵状态"""
        return {
            "total_vms": len(self.vm_nodes),
            "idle_vms": sum(1 for vm in self.vm_nodes.values() if vm.status == "idle"),
            "busy_vms": sum(1 for vm in self.vm_nodes.values() if vm.status == "busy"),
            "error_vms": sum(1 for vm in self.vm_nodes.values() if vm.status == "error"),
            "total_tasks": len(self.distributed_tasks),
            "completed_tasks": sum(1 for t in self.distributed_tasks.values() if t.status == "completed"),
            "vms": [{"vm_id": vm.vm_id, "role": vm.role.value, "status": vm.status, 
                     "cpu_usage": vm.cpu_usage, "memory_usage": vm.memory_usage, 
                     "task_count": vm.task_count} for vm in self.vm_nodes.values()]
        }
    
    async def get_task_status(self, task_id: str) -> Optional[DistributedTask]:
        """获取任务状态"""
        return self.distributed_tasks.get(task_id)
    
    async def list_installed_software(self, vm_id: str) -> List[str]:
        """列出虚拟机上已安装的软件"""
        if vm_id in self.vm_nodes:
            return list(self.vm_nodes[vm_id].skills)
        return []
