"""
多模态感知模块 - L1 基础功能
支持 OCR、目标检测、视觉语言模型理解
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import asyncio

logger = logging.getLogger(__name__)


class PerceptionType(Enum):
    """感知类型"""
    OCR = "ocr"  # 文字识别
    OBJECT_DETECTION = "object_detection"  # 目标检测
    VISUAL_LANGUAGE = "visual_language"  # 视觉语言理解
    SCENE_UNDERSTANDING = "scene_understanding"  # 场景理解
    GESTURE_RECOGNITION = "gesture_recognition"  # 手势识别


@dataclass
class TextRegion:
    """文字区域"""
    text: str
    confidence: float
    bbox: Tuple[int, int, int, int]  # x1, y1, x2, y2
    language: str = "zh"


@dataclass
class DetectedObject:
    """检测到的对象"""
    class_name: str
    confidence: float
    bbox: Tuple[int, int, int, int]  # x1, y1, x2, y2
    attributes: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PerceptionResult:
    """感知结果"""
    perception_type: PerceptionType
    data: Any
    confidence: float
    timestamp: float = field(default_factory=lambda: __import__('time').time())
    metadata: Dict[str, Any] = field(default_factory=dict)


class MultimodalPerceptionEngine:
    """多模态感知引擎"""
    
    def __init__(self):
        self.ocr_results_cache: Dict[str, List[TextRegion]] = {}
        self.object_detection_cache: Dict[str, List[DetectedObject]] = {}
        self.perception_history: List[PerceptionResult] = []
        
        logger.info("多模态感知引擎已初始化")
    
    async def ocr_recognize(self, image_data: bytes, language: str = "zh") -> List[TextRegion]:
        """
        OCR 文字识别 - 使用免费的 EasyOCR/Tesseract/PaddleOCR
        
        Args:
            image_data: 图像数据
            language: 识别语言 (zh, en, etc.)
        
        Returns:
            文字区域列表
        """
        try:
            logger.info(f"执行 OCR 识别 (语言: {language})")
            
            import io
            from PIL import Image
            import numpy as np
            
            # 将字节数据转换为图像
            image = Image.open(io.BytesIO(image_data))
            image_array = np.array(image)
            text_regions = []
            
            # 尝试 1: EasyOCR（推荐，完全免费）
            try:
                import easyocr
                lang_map = {'zh': 'ch_sim', 'en': 'en'}
                reader_lang = lang_map.get(language, 'ch_sim')
                reader = easyocr.Reader([reader_lang])
                results = reader.readtext(image_array)
                
                for (bbox, text, confidence) in results:
                    x_coords = [point[0] for point in bbox]
                    y_coords = [point[1] for point in bbox]
                    x1, y1 = int(min(x_coords)), int(min(y_coords))
                    x2, y2 = int(max(x_coords)), int(max(y_coords))
                    text_regions.append(TextRegion(text=text, confidence=confidence, bbox=(x1, y1, x2, y2), language=language))
                
                logger.info(f"✅ EasyOCR 识别完成，找到 {len(text_regions)} 个文本区域")
                
            except ImportError:
                # 尝试 2: Tesseract（完全免费）
                try:
                    import pytesseract
                    text = pytesseract.image_to_string(image, lang=language)
                    text_regions = [TextRegion(text=text, confidence=0.85, bbox=(0, 0, image.width, image.height), language=language)]
                    logger.info(f"✅ Tesseract OCR 识别完成")
                    
                except ImportError:
                    # 尝试 3: PaddleOCR（完全免费）
                    try:
                        from paddleocr import PaddleOCR
                        ocr = PaddleOCR(use_angle_cls=True, lang='ch')
                        results = ocr.ocr(image, cls=True)
                        
                        for line in results:
                            for word_info in line:
                                bbox, (text, confidence) = word_info
                                x1 = int(min(point[0] for point in bbox))
                                y1 = int(min(point[1] for point in bbox))
                                x2 = int(max(point[0] for point in bbox))
                                y2 = int(max(point[1] for point in bbox))
                                text_regions.append(TextRegion(text=text, confidence=confidence, bbox=(x1, y1, x2, y2), language=language))
                        
                        logger.info(f"✅ PaddleOCR 识别完成，找到 {len(text_regions)} 个文本区域")
                        
                    except ImportError:
                        logger.error("❌ 没有可用的 OCR 库 (需要 easyocr、pytesseract 或 paddleocr)")
                        text_regions = []
            
            result = PerceptionResult(
                perception_type=PerceptionType.OCR,
                data=text_regions,
                confidence=sum(t.confidence for t in text_regions) / len(text_regions) if text_regions else 0
            )
            self.perception_history.append(result)
            
            return text_regions
        
        except Exception as e:
            logger.error(f"OCR 识别失败: {e}")
            return []
    
    async def detect_objects(self, image_data: bytes, confidence_threshold: float = 0.5) -> List[DetectedObject]:
        """
        目标检测 - 识别按钮、文本框等 UI 元素
        
        Args:
            image_data: 图像数据
            confidence_threshold: 置信度阈值
        
        Returns:
            检测到的对象列表
        """
        try:
            logger.info(f"执行目标检测 (阈值: {confidence_threshold})")
            
            # 实际应该使用 YOLO、Faster R-CNN 等
            # 这里是模拟结果
            objects = [
                DetectedObject(
                    class_name="button",
                    confidence=0.92,
                    bbox=(150, 200, 250, 240),
                    attributes={"text": "确定", "color": "blue"}
                ),
                DetectedObject(
                    class_name="text_input",
                    confidence=0.88,
                    bbox=(100, 100, 400, 130),
                    attributes={"placeholder": "请输入用户名"}
                )
            ]
            
            # 过滤低置信度
            objects = [obj for obj in objects if obj.confidence >= confidence_threshold]
            
            result = PerceptionResult(
                perception_type=PerceptionType.OBJECT_DETECTION,
                data=objects,
                confidence=sum(obj.confidence for obj in objects) / len(objects) if objects else 0
            )
            self.perception_history.append(result)
            
            return objects
        
        except Exception as e:
            logger.error(f"目标检测失败: {e}")
            return []
    
    async def visual_language_understanding(self, image_data: bytes, question: str = None) -> Dict[str, Any]:
        """
        视觉语言理解 - 使用 VL 模型理解画面
        
        Args:
            image_data: 图像数据
            question: 关于图像的问题（可选）
        
        Returns:
            理解结果
        """
        try:
            logger.info(f"执行视觉语言理解 (问题: {question})")
            
            # 实际应该使用 CLIP、LLaVA 等模型
            understanding = {
                "scene_description": "这是一个登录界面，包含用户名和密码输入框",
                "elements": [
                    {"type": "text", "content": "登录"},
                    {"type": "input", "placeholder": "用户名"},
                    {"type": "input", "placeholder": "密码"},
                    {"type": "button", "text": "登录"}
                ],
                "layout": "vertical",
                "color_scheme": "light"
            }
            
            if question:
                understanding["answer"] = f"关于 '{question}' 的回答: 这个界面用于用户登录"
            
            result = PerceptionResult(
                perception_type=PerceptionType.VISUAL_LANGUAGE,
                data=understanding,
                confidence=0.85
            )
            self.perception_history.append(result)
            
            return understanding
        
        except Exception as e:
            logger.error(f"视觉语言理解失败: {e}")
            return {}
    
    async def scene_understanding(self, image_data: bytes) -> Dict[str, Any]:
        """
        场景理解 - 理解整个画面的上下文
        
        Args:
            image_data: 图像数据
        
        Returns:
            场景理解结果
        """
        try:
            logger.info("执行场景理解")
            
            # 先进行 OCR 和目标检测
            texts = await self.ocr_recognize(image_data)
            objects = await self.detect_objects(image_data)
            vl_understanding = await self.visual_language_understanding(image_data)
            
            # 综合理解
            scene_info = {
                "scene_type": "login_form",
                "texts": [t.text for t in texts],
                "objects": [o.class_name for o in objects],
                "visual_understanding": vl_understanding,
                "recommended_actions": [
                    "输入用户名",
                    "输入密码",
                    "点击登录按钮"
                ]
            }
            
            result = PerceptionResult(
                perception_type=PerceptionType.SCENE_UNDERSTANDING,
                data=scene_info,
                confidence=0.80
            )
            self.perception_history.append(result)
            
            return scene_info
        
        except Exception as e:
            logger.error(f"场景理解失败: {e}")
            return {}
    
    async def find_element_by_text(self, image_data: bytes, text: str) -> Optional[Tuple[int, int, int, int]]:
        """
        根据文本查找元素位置
        
        Args:
            image_data: 图像数据
            text: 要查找的文本
        
        Returns:
            元素的边界框 (x1, y1, x2, y2)
        """
        try:
            texts = await self.ocr_recognize(image_data)
            
            for text_region in texts:
                if text.lower() in text_region.text.lower():
                    return text_region.bbox
            
            logger.warning(f"未找到文本: {text}")
            return None
        
        except Exception as e:
            logger.error(f"查找元素失败: {e}")
            return None
    
    async def find_element_by_type(self, image_data: bytes, element_type: str) -> Optional[Tuple[int, int, int, int]]:
        """
        根据类型查找元素位置
        
        Args:
            image_data: 图像数据
            element_type: 元素类型 (button, input, etc.)
        
        Returns:
            元素的边界框 (x1, y1, x2, y2)
        """
        try:
            objects = await self.detect_objects(image_data)
            
            for obj in objects:
                if obj.class_name.lower() == element_type.lower():
                    return obj.bbox
            
            logger.warning(f"未找到类型为 {element_type} 的元素")
            return None
        
        except Exception as e:
            logger.error(f"查找元素失败: {e}")
            return None
    
    async def get_perception_history(self, limit: int = 100) -> List[PerceptionResult]:
        """获取感知历史"""
        return self.perception_history[-limit:]
    
    async def clear_cache(self):
        """清除缓存"""
        self.ocr_results_cache.clear()
        self.object_detection_cache.clear()
        logger.info("感知缓存已清除")
