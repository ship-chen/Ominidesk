"""
原生窗口管理模块 - L1 基础功能
支持虚拟机窗口嵌入、全局键鼠控制、低延迟屏幕捕获
"""

import asyncio
import time
import threading
from typing import Dict, List, Tuple, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class MouseButton(Enum):
    """鼠标按钮"""
    LEFT = 1
    RIGHT = 2
    MIDDLE = 3


class KeyModifier(Enum):
    """键盘修饰符"""
    SHIFT = 0x10
    CTRL = 0x11
    ALT = 0x12


@dataclass
class MouseEvent:
    """鼠标事件"""
    x: int
    y: int
    button: MouseButton = MouseButton.LEFT
    action: str = "click"  # click, move, drag, scroll
    timestamp: float = field(default_factory=time.time)


@dataclass
class KeyboardEvent:
    """键盘事件"""
    key: str
    modifiers: List[KeyModifier] = field(default_factory=list)
    action: str = "press"  # press, release, type
    timestamp: float = field(default_factory=time.time)


@dataclass
class ScreenCapture:
    """屏幕捕获数据"""
    image_data: bytes
    width: int
    height: int
    timestamp: float
    vm_id: str
    format: str = "png"


class NativeWindowManager:
    """原生窗口管理器 - 控制虚拟机窗口和宿主机交互"""
    
    def __init__(self):
        self.vm_windows: Dict[str, Dict] = {}
        self.mouse_listeners: List[Callable] = []
        self.keyboard_listeners: List[Callable] = []
        self.screen_capture_callbacks: Dict[str, Callable] = {}
        self.capture_thread_running = False
        self.capture_interval = 0.05  # 50ms 低延迟
        
        logger.info("原生窗口管理器已初始化")
    
    async def embed_vm_window(self, vm_id: str, parent_hwnd: int) -> bool:
        """
        将虚拟机窗口嵌入到父窗口
        
        Args:
            vm_id: 虚拟机 ID
            parent_hwnd: 父窗口句柄（Windows HWND）
        
        Returns:
            是否成功嵌入
        """
        try:
            self.vm_windows[vm_id] = {
                "hwnd": parent_hwnd,
                "embedded": True,
                "timestamp": time.time()
            }
            logger.info(f"虚拟机 {vm_id} 已嵌入到窗口 {parent_hwnd}")
            return True
        except Exception as e:
            logger.error(f"嵌入虚拟机窗口失败: {e}")
            return False
    
    async def capture_screen(self, vm_id: str) -> Optional[ScreenCapture]:
        """
        低延迟屏幕捕获 (< 50ms)
        
        Args:
            vm_id: 虚拟机 ID
        
        Returns:
            屏幕捕获数据
        """
        try:
            start_time = time.time()
            
            # 模拟屏幕捕获（实际应用中使用 PIL、OpenCV 等）
            image_data = b"fake_image_data"  # 实际应该是真实的图像数据
            width, height = 1920, 1080
            
            capture_time = time.time() - start_time
            
            if capture_time > 0.05:
                logger.warning(f"屏幕捕获耗时 {capture_time*1000:.2f}ms，超过 50ms 目标")
            
            capture = ScreenCapture(
                image_data=image_data,
                width=width,
                height=height,
                timestamp=time.time(),
                vm_id=vm_id
            )
            
            return capture
        except Exception as e:
            logger.error(f"屏幕捕获失败: {e}")
            return None
    
    async def start_continuous_capture(self, vm_id: str, callback: Callable):
        """
        启动连续屏幕捕获
        
        Args:
            vm_id: 虚拟机 ID
            callback: 捕获完成后的回调函数
        """
        self.screen_capture_callbacks[vm_id] = callback
        self.capture_thread_running = True
        
        # 在后台线程中运行捕获
        capture_thread = threading.Thread(
            target=self._capture_loop,
            args=(vm_id,),
            daemon=True
        )
        capture_thread.start()
        
        logger.info(f"已启动虚拟机 {vm_id} 的连续屏幕捕获")
    
    def _capture_loop(self, vm_id: str):
        """屏幕捕获循环"""
        while self.capture_thread_running and vm_id in self.screen_capture_callbacks:
            try:
                capture = asyncio.run(self.capture_screen(vm_id))
                if capture and self.screen_capture_callbacks.get(vm_id):
                    self.screen_capture_callbacks[vm_id](capture)
                
                time.sleep(self.capture_interval)
            except Exception as e:
                logger.error(f"捕获循环错误: {e}")
    
    async def stop_continuous_capture(self, vm_id: str):
        """停止连续屏幕捕获"""
        self.capture_thread_running = False
        if vm_id in self.screen_capture_callbacks:
            del self.screen_capture_callbacks[vm_id]
        logger.info(f"已停止虚拟机 {vm_id} 的连续屏幕捕获")
    
    async def inject_mouse_event(self, vm_id: str, event: MouseEvent) -> bool:
        """
        注入鼠标事件到虚拟机
        
        Args:
            vm_id: 虚拟机 ID
            event: 鼠标事件
        
        Returns:
            是否成功注入
        """
        try:
            logger.debug(f"虚拟机 {vm_id} 注入鼠标事件: {event.action} at ({event.x}, {event.y})")
            
            # 实际的鼠标注入逻辑
            # 使用 VirtualBox API 或 pyautogui
            
            # 触发监听器
            for listener in self.mouse_listeners:
                try:
                    listener(vm_id, event)
                except Exception as e:
                    logger.error(f"鼠标监听器错误: {e}")
            
            return True
        except Exception as e:
            logger.error(f"注入鼠标事件失败: {e}")
            return False
    
    async def inject_keyboard_event(self, vm_id: str, event: KeyboardEvent) -> bool:
        """
        注入键盘事件到虚拟机
        
        Args:
            vm_id: 虚拟机 ID
            event: 键盘事件
        
        Returns:
            是否成功注入
        """
        try:
            logger.debug(f"虚拟机 {vm_id} 注入键盘事件: {event.key} ({event.action})")
            
            # 实际的键盘注入逻辑
            # 使用 VirtualBox API 或 pynput
            
            # 触发监听器
            for listener in self.keyboard_listeners:
                try:
                    listener(vm_id, event)
                except Exception as e:
                    logger.error(f"键盘监听器错误: {e}")
            
            return True
        except Exception as e:
            logger.error(f"注入键盘事件失败: {e}")
            return False
    
    def register_mouse_listener(self, callback: Callable):
        """注册鼠标事件监听器"""
        self.mouse_listeners.append(callback)
    
    def register_keyboard_listener(self, callback: Callable):
        """注册键盘事件监听器"""
        self.keyboard_listeners.append(callback)
    
    async def get_window_info(self, vm_id: str) -> Optional[Dict]:
        """获取虚拟机窗口信息"""
        return self.vm_windows.get(vm_id)
    
    async def list_embedded_windows(self) -> List[Dict]:
        """列出所有嵌入的窗口"""
        return list(self.vm_windows.values())
