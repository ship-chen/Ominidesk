"""
自然语言自动化模块 - L1 基础功能
支持自然语言理解和自动化执行
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import re

logger = logging.getLogger(__name__)


class ActionType(Enum):
    """自动化动作类型"""
    CLICK = "click"
    TYPE = "type"
    SCROLL = "scroll"
    WAIT = "wait"
    SCREENSHOT = "screenshot"
    EXTRACT_TEXT = "extract_text"
    FILL_FORM = "fill_form"
    SUBMIT = "submit"
    NAVIGATE = "navigate"
    EXECUTE_SCRIPT = "execute_script"


@dataclass
class AutomationAction:
    """自动化动作"""
    action_type: ActionType
    target: Optional[str] = None  # 目标元素选择器或位置
    value: Optional[str] = None   # 输入值或参数
    wait_time: float = 0.5        # 等待时间
    retry_count: int = 3          # 重试次数
    timestamp: float = field(default_factory=lambda: __import__('time').time())


@dataclass
class AutomationTask:
    """自动化任务"""
    task_id: str
    description: str  # 自然语言描述
    actions: List[AutomationAction] = field(default_factory=list)
    status: str = "pending"  # pending, running, completed, failed
    result: Optional[Dict] = None
    error: Optional[str] = None


class NLPAutomationEngine:
    """自然语言自动化引擎"""
    
    def __init__(self):
        self.tasks: Dict[str, AutomationTask] = {}
        self.action_templates = self._init_action_templates()
        self.form_patterns = self._init_form_patterns()
        
        logger.info("自然语言自动化引擎已初始化")
    
    def _init_action_templates(self) -> Dict[str, Tuple[str, ActionType]]:
        """初始化动作模板"""
        return {
            # 点击相关
            r"点击|click|按|tap": (r"(?:点击|click|按|tap)\s*(?:\")?([^\"]+)(?:\")?", ActionType.CLICK),
            # 输入相关
            r"输入|type|填写|输入框": (r"(?:输入|type|填写)\s*(?:\")?([^\"]+)(?:\")?", ActionType.TYPE),
            # 滚动相关
            r"滚动|scroll": (r"(?:滚动|scroll)\s*(?:up|down|left|right)?", ActionType.SCROLL),
            # 等待相关
            r"等待|wait": (r"(?:等待|wait)\s*(\d+)?", ActionType.WAIT),
            # 截图相关
            r"截图|screenshot": (r"(?:截图|screenshot)", ActionType.SCREENSHOT),
            # 表单相关
            r"填表|表单|form": (r"(?:填表|表单|form)", ActionType.FILL_FORM),
            # 提交相关
            r"提交|submit": (r"(?:提交|submit)", ActionType.SUBMIT),
            # 导航相关
            r"打开|navigate|go": (r"(?:打开|navigate|go)\s*(?:\")?([^\"]+)(?:\")?", ActionType.NAVIGATE),
        }
    
    def _init_form_patterns(self) -> Dict[str, str]:
        """初始化表单模式"""
        return {
            "email": r"[\w\.-]+@[\w\.-]+\.\w+",
            "phone": r"\d{3,4}[-\s]?\d{3,4}[-\s]?\d{4}",
            "username": r"[a-zA-Z0-9_]{3,20}",
            "password": r".{6,}",
            "url": r"https?://[^\s]+",
        }
    
    async def parse_natural_language(self, description: str) -> List[AutomationAction]:
        """
        解析自然语言描述为自动化动作序列
        
        Args:
            description: 自然语言描述，如 "打开百度，搜索 Python，点击第一个结果"
        
        Returns:
            自动化动作列表
        """
        actions: List[AutomationAction] = []
        
        # 分割句子
        sentences = re.split(r'[，。；、]', description)
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            # 尝试匹配动作
            action = self._match_action(sentence)
            if action:
                actions.append(action)
            else:
                logger.warning(f"无法识别的动作: {sentence}")
        
        return actions
    
    def _match_action(self, sentence: str) -> Optional[AutomationAction]:
        """匹配单个动作"""
        for pattern, (regex, action_type) in self.action_templates.items():
            if re.search(pattern, sentence, re.IGNORECASE):
                match = re.search(regex, sentence, re.IGNORECASE)
                if match:
                    target = match.group(1) if match.lastindex and match.lastindex >= 1 else None
                    return AutomationAction(
                        action_type=action_type,
                        target=target
                    )
        
        return None
    
    async def execute_automation_task(self, task_id: str, description: str, vm_id: str) -> AutomationTask:
        """
        执行自动化任务
        
        Args:
            task_id: 任务 ID
            description: 自然语言描述
            vm_id: 虚拟机 ID
        
        Returns:
            自动化任务结果
        """
        task = AutomationTask(
            task_id=task_id,
            description=description
        )
        
        self.tasks[task_id] = task
        
        try:
            task.status = "running"
            
            # 解析自然语言
            actions = await self.parse_natural_language(description)
            task.actions = actions
            
            logger.info(f"任务 {task_id} 解析完成，共 {len(actions)} 个动作")
            
            # 执行动作序列
            for i, action in enumerate(actions):
                try:
                    logger.info(f"执行动作 {i+1}/{len(actions)}: {action.action_type.value}")
                    
                    # 这里应该调用实际的执行函数
                    result = await self._execute_action(action, vm_id)
                    
                    if not result:
                        if action.retry_count > 0:
                            action.retry_count -= 1
                            logger.warning(f"动作失败，重试 {action.retry_count} 次")
                            # 重试逻辑
                        else:
                            raise Exception(f"动作执行失败: {action.action_type.value}")
                    
                    # 等待
                    await asyncio.sleep(action.wait_time)
                
                except Exception as e:
                    task.status = "failed"
                    task.error = str(e)
                    logger.error(f"动作执行失败: {e}")
                    return task
            
            task.status = "completed"
            task.result = {"actions_executed": len(actions)}
            logger.info(f"任务 {task_id} 完成")
            
        except Exception as e:
            task.status = "failed"
            task.error = str(e)
            logger.error(f"任务执行失败: {e}")
        
        return task
    
    async def _execute_action(self, action: AutomationAction, vm_id: str) -> bool:
        """执行单个动作"""
        try:
            if action.action_type == ActionType.CLICK:
                logger.debug(f"执行点击: {action.target}")
                # 实际的点击逻辑
                return True
            
            elif action.action_type == ActionType.TYPE:
                logger.debug(f"执行输入: {action.value}")
                # 实际的输入逻辑
                return True
            
            elif action.action_type == ActionType.WAIT:
                wait_time = float(action.target or 1)
                logger.debug(f"等待 {wait_time} 秒")
                await asyncio.sleep(wait_time)
                return True
            
            elif action.action_type == ActionType.SCREENSHOT:
                logger.debug("执行截图")
                # 实际的截图逻辑
                return True
            
            elif action.action_type == ActionType.SUBMIT:
                logger.debug("执行提交")
                # 实际的提交逻辑
                return True
            
            else:
                logger.warning(f"未实现的动作类型: {action.action_type}")
                return False
        
        except Exception as e:
            logger.error(f"执行动作失败: {e}")
            return False
    
    async def get_task_status(self, task_id: str) -> Optional[AutomationTask]:
        """获取任务状态"""
        return self.tasks.get(task_id)
    
    async def list_tasks(self) -> List[AutomationTask]:
        """列出所有任务"""
        return list(self.tasks.values())
    
    async def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        if task_id in self.tasks:
            task = self.tasks[task_id]
            if task.status == "running":
                task.status = "cancelled"
                logger.info(f"任务 {task_id} 已取消")
                return True
        return False
