"""
OmniDesk AI - 性能优化模块
包含缓存、压缩、异步处理、内存管理
"""

import asyncio
import time
import gzip
import json
from typing import Dict, Any, Optional, Callable
from functools import wraps
from datetime import datetime, timedelta
from collections import OrderedDict
import logging

logger = logging.getLogger(__name__)

# ============================================================================
# 缓存系统
# ============================================================================

class Cache:
    """简单的内存缓存"""
    
    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        self.max_size = max_size
        self.ttl = ttl  # 秒
        self.cache: OrderedDict = OrderedDict()
        self.timestamps: Dict[str, float] = {}
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存"""
        if key not in self.cache:
            return None
        
        # 检查过期
        if key in self.timestamps:
            if time.time() - self.timestamps[key] > self.ttl:
                self.delete(key)
                return None
        
        # 移到最后（LRU）
        self.cache.move_to_end(key)
        return self.cache[key]
    
    def set(self, key: str, value: Any) -> None:
        """设置缓存"""
        if key in self.cache:
            self.cache.move_to_end(key)
        
        self.cache[key] = value
        self.timestamps[key] = time.time()
        
        # 如果超过大小限制，删除最旧的
        if len(self.cache) > self.max_size:
            oldest_key = next(iter(self.cache))
            self.delete(oldest_key)
    
    def delete(self, key: str) -> None:
        """删除缓存"""
        if key in self.cache:
            del self.cache[key]
        if key in self.timestamps:
            del self.timestamps[key]
    
    def clear(self) -> None:
        """清空缓存"""
        self.cache.clear()
        self.timestamps.clear()
    
    def size(self) -> int:
        """获取缓存大小"""
        return len(self.cache)

# ============================================================================
# 缓存装饰器
# ============================================================================

def cached(ttl: int = 300):
    """缓存装饰器"""
    cache = Cache(ttl=ttl)
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # 生成缓存键
            cache_key = f"{func.__name__}:{str(args)}:{str(kwargs)}"
            
            # 检查缓存
            cached_value = cache.get(cache_key)
            if cached_value is not None:
                logger.debug(f"缓存命中: {cache_key}")
                return cached_value
            
            # 执行函数
            result = await func(*args, **kwargs)
            
            # 存储缓存
            cache.set(cache_key, result)
            
            return result
        
        return wrapper
    
    return decorator

# ============================================================================
# 压缩工具
# ============================================================================

class Compression:
    """数据压缩工具"""
    
    @staticmethod
    def compress_json(data: Dict) -> bytes:
        """压缩 JSON 数据"""
        try:
            json_str = json.dumps(data, separators=(',', ':'))
            compressed = gzip.compress(json_str.encode('utf-8'))
            
            original_size = len(json_str.encode('utf-8'))
            compressed_size = len(compressed)
            ratio = (1 - compressed_size / original_size) * 100
            
            logger.debug(f"压缩率: {ratio:.1f}% ({original_size} -> {compressed_size} bytes)")
            
            return compressed
        
        except Exception as e:
            logger.error(f"压缩失败: {e}")
            return json.dumps(data).encode('utf-8')
    
    @staticmethod
    def decompress_json(data: bytes) -> Dict:
        """解压 JSON 数据"""
        try:
            decompressed = gzip.decompress(data)
            return json.loads(decompressed.decode('utf-8'))
        
        except Exception as e:
            logger.error(f"解压失败: {e}")
            return json.loads(data.decode('utf-8'))

# ============================================================================
# 异步任务队列
# ============================================================================

class AsyncTaskQueue:
    """异步任务队列"""
    
    def __init__(self, max_workers: int = 10):
        self.queue: asyncio.Queue = asyncio.Queue()
        self.max_workers = max_workers
        self.workers = []
        self.running = False
        self.completed_tasks = 0
        self.failed_tasks = 0
    
    async def start(self) -> None:
        """启动队列"""
        if self.running:
            return
        
        self.running = True
        
        # 启动工作线程
        for i in range(self.max_workers):
            worker = asyncio.create_task(self._worker(i))
            self.workers.append(worker)
        
        logger.info(f"✅ 任务队列已启动 ({self.max_workers} 个工作线程)")
    
    async def stop(self) -> None:
        """停止队列"""
        self.running = False
        
        # 等待所有工作线程完成
        await asyncio.gather(*self.workers, return_exceptions=True)
        
        logger.info(f"✅ 任务队列已停止 (完成: {self.completed_tasks}, 失败: {self.failed_tasks})")
    
    async def add_task(self, func: Callable, *args, **kwargs) -> None:
        """添加任务"""
        await self.queue.put((func, args, kwargs))
    
    async def _worker(self, worker_id: int) -> None:
        """工作线程"""
        while self.running:
            try:
                func, args, kwargs = await asyncio.wait_for(
                    self.queue.get(),
                    timeout=1.0
                )
                
                try:
                    if asyncio.iscoroutinefunction(func):
                        await func(*args, **kwargs)
                    else:
                        func(*args, **kwargs)
                    
                    self.completed_tasks += 1
                
                except Exception as e:
                    logger.error(f"任务执行失败: {e}")
                    self.failed_tasks += 1
                
                finally:
                    self.queue.task_done()
            
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"工作线程错误: {e}")

# ============================================================================
# 性能监控
# ============================================================================

class PerformanceMonitor:
    """性能监控"""
    
    def __init__(self):
        self.metrics: Dict[str, list] = {}
        self.start_times: Dict[str, float] = {}
    
    def start_timer(self, name: str) -> None:
        """启动计时器"""
        self.start_times[name] = time.time()
    
    def end_timer(self, name: str) -> float:
        """结束计时器"""
        if name not in self.start_times:
            return 0
        
        elapsed = time.time() - self.start_times[name]
        
        if name not in self.metrics:
            self.metrics[name] = []
        
        self.metrics[name].append(elapsed)
        
        # 保持最近 1000 条记录
        if len(self.metrics[name]) > 1000:
            self.metrics[name] = self.metrics[name][-1000:]
        
        return elapsed
    
    def get_stats(self, name: str) -> Dict[str, float]:
        """获取统计信息"""
        if name not in self.metrics or not self.metrics[name]:
            return {}
        
        times = self.metrics[name]
        
        return {
            "count": len(times),
            "min": min(times),
            "max": max(times),
            "avg": sum(times) / len(times),
            "total": sum(times)
        }
    
    def get_all_stats(self) -> Dict[str, Dict]:
        """获取所有统计信息"""
        return {
            name: self.get_stats(name)
            for name in self.metrics.keys()
        }

# ============================================================================
# 内存管理
# ============================================================================

class PerformanceOptimizer:
    """性能优化器（统一接口）"""
    def __init__(self):
        self.cache = Cache()
        self.compression = Compression()
        self.task_queue = AsyncTaskQueue()
        self.monitor = PerformanceMonitor()
        self.memory_manager = MemoryManager()
    
    async def optimize(self):
        """执行性能优化"""
        await self.monitor.collect_metrics()
        self.memory_manager.cleanup()
        return {"status": "optimized"}

class MemoryManager:
    """内存管理"""
    
    def __init__(self, max_memory_mb: int = 1024):
        self.max_memory = max_memory_mb * 1024 * 1024  # 转换为字节
        self.current_usage = 0
    
    def estimate_size(self, obj: Any) -> int:
        """估计对象大小"""
        import sys
        return sys.getsizeof(obj)
    
    def allocate(self, size: int) -> bool:
        """分配内存"""
        if self.current_usage + size > self.max_memory:
            logger.warning(f"内存不足: {self.current_usage + size} > {self.max_memory}")
            return False
        
        self.current_usage += size
        return True
    
    def deallocate(self, size: int) -> None:
        """释放内存"""
        self.current_usage = max(0, self.current_usage - size)
    
    def get_usage_percent(self) -> float:
        """获取内存使用百分比"""
        return (self.current_usage / self.max_memory) * 100

# ============================================================================
# 全局性能对象
# ============================================================================

cache = Cache()
compression = Compression()
task_queue = AsyncTaskQueue()
monitor = PerformanceMonitor()
memory_manager = MemoryManager()

# ============================================================================
# 性能装饰器
# ============================================================================

def measure_performance(func: Callable) -> Callable:
    """性能测量装饰器"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        timer_name = f"{func.__module__}.{func.__name__}"
        monitor.start_timer(timer_name)
        
        try:
            result = await func(*args, **kwargs)
            elapsed = monitor.end_timer(timer_name)
            
            if elapsed > 1.0:  # 超过 1 秒的操作记录警告
                logger.warning(f"慢操作: {timer_name} 耗时 {elapsed:.2f}s")
            
            return result
        
        except Exception as e:
            monitor.end_timer(timer_name)
            raise
    
    return wrapper
