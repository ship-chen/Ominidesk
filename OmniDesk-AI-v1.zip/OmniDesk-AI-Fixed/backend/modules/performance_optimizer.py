"""
性能优化模块 - 新增功能
监控系统性能，自动优化资源使用
"""

import logging
import time
import psutil
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from collections import deque

logger = logging.getLogger(__name__)


@dataclass
class PerformanceMetric:
    """性能指标"""
    timestamp: float
    cpu_percent: float
    memory_percent: float
    memory_mb: float
    disk_percent: float
    process_count: int


class PerformanceOptimizer:
    """性能优化器"""
    
    def __init__(self, max_history: int = 1000):
        self.metrics: deque = deque(maxlen=max_history)
        self.alerts: List[Dict[str, Any]] = []
        self.optimization_rules: Dict[str, Any] = {}
        self._init_rules()
        
        logger.info("性能优化器已初始化")
    
    def _init_rules(self):
        """初始化优化规则"""
        self.optimization_rules = {
            "cpu_high": {"threshold": 80, "action": "reduce_background_tasks"},
            "memory_high": {"threshold": 85, "action": "clear_cache"},
            "disk_high": {"threshold": 90, "action": "cleanup_logs"},
        }
    
    async def collect_metrics(self) -> PerformanceMetric:
        """收集性能指标"""
        try:
            metric = PerformanceMetric(
                timestamp=time.time(),
                cpu_percent=psutil.cpu_percent(interval=1),
                memory_percent=psutil.virtual_memory().percent,
                memory_mb=psutil.virtual_memory().used / 1024 / 1024,
                disk_percent=psutil.disk_usage('/').percent,
                process_count=len(psutil.pids())
            )
            
            self.metrics.append(metric)
            
            # 检查告警
            await self._check_alerts(metric)
            
            logger.debug(f"性能指标已收集: CPU={metric.cpu_percent}%, 内存={metric.memory_percent}%")
            return metric
        
        except Exception as e:
            logger.error(f"收集性能指标失败: {e}")
            return None
    
    async def _check_alerts(self, metric: PerformanceMetric):
        """检查告警"""
        if metric.cpu_percent > self.optimization_rules["cpu_high"]["threshold"]:
            self.alerts.append({
                "type": "cpu_high",
                "timestamp": metric.timestamp,
                "value": metric.cpu_percent
            })
            logger.warning(f"CPU 使用率过高: {metric.cpu_percent}%")
        
        if metric.memory_percent > self.optimization_rules["memory_high"]["threshold"]:
            self.alerts.append({
                "type": "memory_high",
                "timestamp": metric.timestamp,
                "value": metric.memory_percent
            })
            logger.warning(f"内存使用率过高: {metric.memory_percent}%")
        
        if metric.disk_percent > self.optimization_rules["disk_high"]["threshold"]:
            self.alerts.append({
                "type": "disk_high",
                "timestamp": metric.timestamp,
                "value": metric.disk_percent
            })
            logger.warning(f"磁盘使用率过高: {metric.disk_percent}%")
    
    async def get_average_metrics(self, seconds: int = 60) -> Optional[Dict[str, float]]:
        """获取平均性能指标"""
        try:
            if not self.metrics:
                return None
            
            current_time = time.time()
            recent_metrics = [m for m in self.metrics if current_time - m.timestamp <= seconds]
            
            if not recent_metrics:
                return None
            
            avg_cpu = sum(m.cpu_percent for m in recent_metrics) / len(recent_metrics)
            avg_memory = sum(m.memory_percent for m in recent_metrics) / len(recent_metrics)
            avg_disk = sum(m.disk_percent for m in recent_metrics) / len(recent_metrics)
            
            return {
                "avg_cpu": avg_cpu,
                "avg_memory": avg_memory,
                "avg_disk": avg_disk,
                "sample_count": len(recent_metrics)
            }
        
        except Exception as e:
            logger.error(f"获取平均性能指标失败: {e}")
            return None
    
    async def get_alerts(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取告警"""
        return self.alerts[-limit:]
    
    async def clear_alerts(self):
        """清除告警"""
        self.alerts.clear()
        logger.info("告警已清除")
    
    async def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        try:
            if not self.metrics:
                return {}
            
            latest = self.metrics[-1]
            avg = await self.get_average_metrics(60)
            
            return {
                "latest": {
                    "cpu_percent": latest.cpu_percent,
                    "memory_percent": latest.memory_percent,
                    "memory_mb": latest.memory_mb,
                    "disk_percent": latest.disk_percent,
                    "process_count": latest.process_count,
                    "timestamp": latest.timestamp
                },
                "average_60s": avg,
                "alert_count": len(self.alerts),
                "metrics_count": len(self.metrics)
            }
        
        except Exception as e:
            logger.error(f"获取系统状态失败: {e}")
            return {}
