"""
OmniDesk AI - 插件系统
支持动态加载和管理插件
"""

import os
import sys
import json
import importlib
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# ============================================================================
# 数据结构
# ============================================================================

@dataclass
class PluginMetadata:
    """插件元数据"""
    name: str
    version: str
    author: str
    description: str
    enabled: bool = True
    hooks: Dict[str, List[str]] = None

@dataclass
class PluginInfo:
    """插件信息"""
    id: str
    metadata: PluginMetadata
    path: str
    loaded: bool = False
    error: Optional[str] = None
    hooks: Dict[str, Callable] = None

# ============================================================================
# 插件系统
# ============================================================================

class PluginManager:
    """插件管理系统"""

class PluginSystem(PluginManager):
    """插件管理系统（向后兼容）"""
    
    def __init__(self, plugins_dir: str = "plugins"):
        self.plugins_dir = Path(plugins_dir)
        self.plugins_dir.mkdir(exist_ok=True)
        
        self.plugins: Dict[str, PluginInfo] = {}
        self.hooks: Dict[str, List[Callable]] = {}
        
        logger.info(f"插件系统初始化: {self.plugins_dir}")
    
    async def discover_plugins(self) -> List[str]:
        """发现所有可用的插件"""
        plugin_ids = []
        
        for plugin_dir in self.plugins_dir.iterdir():
            if not plugin_dir.is_dir():
                continue
            
            # 查找 plugin.json 配置文件
            config_file = plugin_dir / "plugin.json"
            if not config_file.exists():
                continue
            
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                
                plugin_id = plugin_dir.name
                metadata = PluginMetadata(**config)
                
                plugin_info = PluginInfo(
                    id=plugin_id,
                    metadata=metadata,
                    path=str(plugin_dir)
                )
                
                self.plugins[plugin_id] = plugin_info
                plugin_ids.append(plugin_id)
                
                logger.info(f"发现插件: {plugin_id} ({metadata.name})")
            
            except Exception as e:
                logger.error(f"加载插件配置失败 {plugin_dir}: {e}")
        
        return plugin_ids
    
    async def load_plugin(self, plugin_id: str) -> bool:
        """加载插件"""
        if plugin_id not in self.plugins:
            logger.error(f"插件不存在: {plugin_id}")
            return False
        
        plugin_info = self.plugins[plugin_id]
        
        if plugin_info.loaded:
            logger.warning(f"插件已加载: {plugin_id}")
            return True
        
        try:
            # 添加插件目录到 Python 路径
            plugin_path = plugin_info.path
            if plugin_path not in sys.path:
                sys.path.insert(0, plugin_path)
            
            # 动态导入插件模块
            module_name = f"plugin_{plugin_id}"
            spec = importlib.util.spec_from_file_location(
                module_name,
                Path(plugin_path) / "main.py"
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # 获取插件类
            if not hasattr(module, 'Plugin'):
                raise ValueError("插件必须定义 Plugin 类")
            
            plugin_class = module.Plugin
            plugin_instance = plugin_class()
            
            # 注册钩子
            if hasattr(plugin_instance, 'register_hooks'):
                hooks = await plugin_instance.register_hooks()
                plugin_info.hooks = hooks
                
                for hook_name, hook_func in hooks.items():
                    if hook_name not in self.hooks:
                        self.hooks[hook_name] = []
                    self.hooks[hook_name].append(hook_func)
            
            plugin_info.loaded = True
            logger.info(f"✅ 插件已加载: {plugin_id}")
            
            return True
        
        except Exception as e:
            plugin_info.error = str(e)
            logger.error(f"❌ 加载插件失败 {plugin_id}: {e}")
            return False
    
    async def unload_plugin(self, plugin_id: str) -> bool:
        """卸载插件"""
        if plugin_id not in self.plugins:
            logger.error(f"插件不存在: {plugin_id}")
            return False
        
        plugin_info = self.plugins[plugin_id]
        
        if not plugin_info.loaded:
            logger.warning(f"插件未加载: {plugin_id}")
            return True
        
        try:
            # 移除钩子
            if plugin_info.hooks:
                for hook_name, hook_func in plugin_info.hooks.items():
                    if hook_name in self.hooks:
                        self.hooks[hook_name] = [
                            h for h in self.hooks[hook_name]
                            if h != hook_func
                        ]
            
            plugin_info.loaded = False
            logger.info(f"✅ 插件已卸载: {plugin_id}")
            
            return True
        
        except Exception as e:
            logger.error(f"❌ 卸载插件失败 {plugin_id}: {e}")
            return False
    
    async def execute_hook(self, hook_name: str, *args, **kwargs) -> List[Any]:
        """执行钩子"""
        if hook_name not in self.hooks:
            return []
        
        results = []
        for hook_func in self.hooks[hook_name]:
            try:
                if asyncio.iscoroutinefunction(hook_func):
                    result = await hook_func(*args, **kwargs)
                else:
                    result = hook_func(*args, **kwargs)
                results.append(result)
            except Exception as e:
                logger.error(f"执行钩子失败 {hook_name}: {e}")
        
        return results
    
    def get_plugin_info(self, plugin_id: str) -> Optional[Dict]:
        """获取插件信息"""
        if plugin_id not in self.plugins:
            return None
        
        plugin_info = self.plugins[plugin_id]
        return {
            "id": plugin_info.id,
            "metadata": asdict(plugin_info.metadata),
            "loaded": plugin_info.loaded,
            "error": plugin_info.error,
            "path": plugin_info.path
        }
    
    def list_plugins(self) -> List[Dict]:
        """列出所有插件"""
        return [
            self.get_plugin_info(plugin_id)
            for plugin_id in self.plugins.keys()
        ]
    
    async def load_all_plugins(self) -> Dict[str, bool]:
        """加载所有启用的插件"""
        results = {}
        
        for plugin_id, plugin_info in self.plugins.items():
            if plugin_info.metadata.enabled:
                results[plugin_id] = await self.load_plugin(plugin_id)
        
        return results

# ============================================================================
# 基础插件类
# ============================================================================

class BasePlugin:
    """基础插件类"""
    
    def __init__(self):
        self.name = "Base Plugin"
        self.version = "1.0.0"
        self.author = "OmniDesk"
    
    async def register_hooks(self) -> Dict[str, Callable]:
        """注册钩子"""
        return {}
    
    async def on_load(self):
        """插件加载时调用"""
        pass
    
    async def on_unload(self):
        """插件卸载时调用"""
        pass
    
    async def on_task_create(self, task: Dict) -> Dict:
        """任务创建时调用"""
        return task
    
    async def on_task_execute(self, task: Dict) -> Dict:
        """任务执行时调用"""
        return task
    
    async def on_vm_start(self, vm: Dict) -> Dict:
        """虚拟机启动时调用"""
        return vm
    
    async def on_vm_stop(self, vm: Dict) -> Dict:
        """虚拟机停止时调用"""
        return vm

# ============================================================================
# 示例插件
# ============================================================================

class ExamplePlugin(BasePlugin):
    """示例插件"""
    
    def __init__(self):
        super().__init__()
        self.name = "Example Plugin"
        self.version = "1.0.0"
    
    async def register_hooks(self) -> Dict[str, Callable]:
        """注册钩子"""
        return {
            "task_create": self.on_task_create,
            "task_execute": self.on_task_execute,
            "vm_start": self.on_vm_start,
            "vm_stop": self.on_vm_stop
        }
    
    async def on_task_create(self, task: Dict) -> Dict:
        """任务创建时添加标签"""
        task['tags'] = task.get('tags', []) + ['example-plugin']
        return task
    
    async def on_task_execute(self, task: Dict) -> Dict:
        """任务执行时记录日志"""
        logger.info(f"示例插件: 执行任务 {task.get('id')}")
        return task
    
    async def on_vm_start(self, vm: Dict) -> Dict:
        """虚拟机启动时记录"""
        logger.info(f"示例插件: 启动虚拟机 {vm.get('name')}")
        return vm
    
    async def on_vm_stop(self, vm: Dict) -> Dict:
        """虚拟机停止时记录"""
        logger.info(f"示例插件: 停止虚拟机 {vm.get('name')}")
        return vm

# ============================================================================
# 插件示例配置
# ============================================================================

EXAMPLE_PLUGIN_CONFIG = {
    "name": "Example Plugin",
    "version": "1.0.0",
    "author": "OmniDesk",
    "description": "示例插件，演示插件系统的功能",
    "enabled": True,
    "hooks": [
        "task_create",
        "task_execute",
        "vm_start",
        "vm_stop"
    ]
}

EXAMPLE_PLUGIN_MAIN = '''
"""示例插件主程序"""

from plugin_system import BasePlugin

class Plugin(BasePlugin):
    """示例插件"""
    
    def __init__(self):
        super().__init__()
        self.name = "Example Plugin"
    
    async def register_hooks(self):
        return {
            "task_create": self.on_task_create,
            "task_execute": self.on_task_execute,
        }
    
    async def on_task_create(self, task):
        task['tags'] = task.get('tags', []) + ['example']
        return task
    
    async def on_task_execute(self, task):
        print(f"执行任务: {task.get('title')}")
        return task
'''
