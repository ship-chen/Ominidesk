"""
速率限制模块 - 新增功能
防止 API 滥用，保护系统稳定性
"""

import logging
import time
from typing import Dict, Optional
from collections import defaultdict, deque

logger = logging.getLogger(__name__)


class RateLimiter:
    """速率限制器"""
    
    def __init__(self, default_rate: int = 100, window_size: int = 60):
        """
        初始化速率限制器
        
        Args:
            default_rate: 默认速率（请求数/秒）
            window_size: 时间窗口大小（秒）
        """
        self.default_rate = default_rate
        self.window_size = window_size
        self.requests: Dict[str, deque] = defaultdict(deque)
        self.limits: Dict[str, int] = {}
        
        logger.info(f"速率限制器已初始化: {default_rate} 请求/{window_size}秒")
    
    def set_limit(self, client_id: str, rate: int):
        """设置客户端限制"""
        self.limits[client_id] = rate
        logger.info(f"已设置客户端 {client_id} 的限制: {rate} 请求/秒")
    
    def is_allowed(self, client_id: str) -> bool:
        """检查是否允许请求"""
        current_time = time.time()
        
        # 获取客户端的请求队列
        request_queue = self.requests[client_id]
        
        # 移除过期的请求
        while request_queue and current_time - request_queue[0] > self.window_size:
            request_queue.popleft()
        
        # 获取客户端的限制
        limit = self.limits.get(client_id, self.default_rate)
        
        # 检查是否超过限制
        if len(request_queue) >= limit:
            logger.warning(f"客户端 {client_id} 超过速率限制")
            return False
        
        # 记录请求
        request_queue.append(current_time)
        return True
    
    def get_remaining(self, client_id: str) -> int:
        """获取剩余请求数"""
        current_time = time.time()
        request_queue = self.requests[client_id]
        
        # 移除过期的请求
        while request_queue and current_time - request_queue[0] > self.window_size:
            request_queue.popleft()
        
        limit = self.limits.get(client_id, self.default_rate)
        return max(0, limit - len(request_queue))
    
    def get_reset_time(self, client_id: str) -> float:
        """获取限制重置时间"""
        request_queue = self.requests[client_id]
        
        if not request_queue:
            return 0
        
        oldest_request = request_queue[0]
        reset_time = oldest_request + self.window_size
        return max(0, reset_time - time.time())
    
    def get_stats(self, client_id: str) -> Dict[str, any]:
        """获取客户端统计"""
        current_time = time.time()
        request_queue = self.requests[client_id]
        
        # 移除过期的请求
        while request_queue and current_time - request_queue[0] > self.window_size:
            request_queue.popleft()
        
        limit = self.limits.get(client_id, self.default_rate)
        
        return {
            "client_id": client_id,
            "limit": limit,
            "current_requests": len(request_queue),
            "remaining": max(0, limit - len(request_queue)),
            "reset_in": self.get_reset_time(client_id)
        }
    
    def reset_client(self, client_id: str):
        """重置客户端"""
        if client_id in self.requests:
            self.requests[client_id].clear()
        logger.info(f"已重置客户端 {client_id} 的请求队列")
    
    def reset_all(self):
        """重置所有客户端"""
        self.requests.clear()
        logger.info("已重置所有客户端的请求队列")
