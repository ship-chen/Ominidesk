"""
安全与审计系统
功能：
1. 虚拟机内安全策略
2. 宿主机权限管理
3. 操作审计日志
4. 权限白名单
"""

import logging
from typing import Dict, Any, List, Optional, Set
from enum import Enum
from dataclasses import dataclass, field
import json
import time
import hashlib

logger = logging.getLogger(__name__)


class PermissionLevel(Enum):
    """权限级别"""
    DENY = "deny"
    ALLOW_ONCE = "allow_once"
    ALLOW_ALWAYS = "allow_always"


class AuditEventType(Enum):
    """审计事件类型"""
    VM_OPERATION = "vm_operation"
    HOST_OPERATION = "host_operation"
    AI_ACTION = "ai_action"
    PERMISSION_REQUEST = "permission_request"
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_DENIED = "permission_denied"
    ERROR = "error"


@dataclass
class AuditEvent:
    """审计事件"""
    event_type: AuditEventType
    description: str
    details: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    user_id: Optional[str] = None
    approved: Optional[bool] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "event_type": self.event_type.value,
            "description": self.description,
            "details": self.details,
            "timestamp": self.timestamp,
            "user_id": self.user_id,
            "approved": self.approved
        }


@dataclass
class PermissionRequest:
    """权限请求"""
    request_id: str
    action: str
    description: str
    resource: str
    created_at: float = field(default_factory=time.time)
    expires_at: float = field(default_factory=lambda: time.time() + 30)  # 30秒超时
    status: str = "pending"
    
    def is_expired(self) -> bool:
        """检查是否过期"""
        return time.time() > self.expires_at
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "request_id": self.request_id,
            "action": self.action,
            "description": self.description,
            "resource": self.resource,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "status": self.status,
            "is_expired": self.is_expired()
        }


class VMSecurityPolicy:
    """虚拟机安全策略"""
    
    def __init__(self):
        # 禁止执行的命令
        self.forbidden_commands = {
            "format",
            "del /f /s",
            "rd /s /q",
            "cipher /w",
            "cipher /x",
            "diskpart",
            "fdisk",
            "shutdown /s",
            "shutdown /h",
            "taskkill /f",
            "sc stop",
            "sc delete",
            "net stop",
            "reg delete",
            "reg add",
            "wmic delete",
            "powershell -NoProfile -Command",
        }
        
        # 允许的命令前缀
        self.allowed_commands = {
            "dir",
            "cd",
            "type",
            "echo",
            "copy",
            "xcopy",
            "move",
            "ren",
            "mkdir",
            "rmdir",
            "findstr",
            "tasklist",
            "systeminfo",
            "ipconfig",
            "ping",
            "tracert",
            "netstat",
        }
    
    def validate_command(self, command: str) -> Dict[str, Any]:
        """验证命令是否安全"""
        command_upper = command.upper().strip()
        
        # 检查禁止命令
        for forbidden in self.forbidden_commands:
            if forbidden.upper() in command_upper:
                return {
                    "status": "denied",
                    "reason": f"命令包含禁止操作: {forbidden}"
                }
        
        # 检查允许命令
        is_allowed = any(
            command_upper.startswith(allowed.upper())
            for allowed in self.allowed_commands
        )
        
        if not is_allowed:
            return {
                "status": "warning",
                "reason": "命令不在允许列表中，需要用户确认"
            }
        
        return {
            "status": "allowed",
            "reason": "命令通过验证"
        }


class HostPermissionManager:
    """宿主机权限管理器"""
    
    def __init__(self):
        # 允许的宿主机操作
        self.allowed_actions = {
            "open_application": "打开应用程序",
            "read_file": "读取文件",
            "write_file": "写入文件",
            "get_clipboard": "获取剪贴板",
            "set_clipboard": "设置剪贴板",
            "send_keys": "发送按键",
            "get_window_info": "获取窗口信息",
        }
        
        # 允许访问的文件夹
        self.allowed_folders = {
            "Downloads",
            "Documents",
            "Desktop",
            "Pictures",
            "Videos",
            "Music",
        }
        
        # 禁止访问的文件夹
        self.forbidden_folders = {
            "System32",
            "Windows",
            "Program Files",
            "ProgramData",
            "Users\\*\\AppData\\Roaming",
            "Users\\*\\AppData\\Local\\System",
        }
        
        # 权限缓存
        self.permission_cache: Dict[str, PermissionLevel] = {}
        
        # 待处理的权限请求
        self.pending_requests: Dict[str, PermissionRequest] = {}
    
    def request_permission(self, action: str, resource: str, description: str) -> Dict[str, Any]:
        """请求权限"""
        import uuid
        
        request_id = str(uuid.uuid4())
        
        # 检查缓存
        cache_key = f"{action}:{resource}"
        if cache_key in self.permission_cache:
            level = self.permission_cache[cache_key]
            if level == PermissionLevel.ALLOW_ALWAYS:
                return {
                    "status": "approved",
                    "reason": "已缓存的权限",
                    "request_id": request_id
                }
            elif level == PermissionLevel.DENY:
                return {
                    "status": "denied",
                    "reason": "已缓存的拒绝",
                    "request_id": request_id
                }
        
        # 创建权限请求
        request = PermissionRequest(
            request_id=request_id,
            action=action,
            resource=resource,
            description=description
        )
        
        self.pending_requests[request_id] = request
        
        logger.info(f"权限请求已创建: {request_id}")
        
        return {
            "status": "pending",
            "request_id": request_id,
            "request": request.to_dict()
        }
    
    def approve_permission(self, request_id: str, remember: bool = False) -> Dict[str, Any]:
        """批准权限"""
        if request_id not in self.pending_requests:
            return {
                "status": "error",
                "message": "权限请求不存在"
            }
        
        request = self.pending_requests[request_id]
        
        if request.is_expired():
            del self.pending_requests[request_id]
            return {
                "status": "error",
                "message": "权限请求已过期"
            }
        
        # 缓存权限
        cache_key = f"{request.action}:{request.resource}"
        level = PermissionLevel.ALLOW_ALWAYS if remember else PermissionLevel.ALLOW_ONCE
        self.permission_cache[cache_key] = level
        
        request.status = "approved"
        del self.pending_requests[request_id]
        
        logger.info(f"权限已批准: {request_id}")
        
        return {
            "status": "success",
            "message": "权限已批准"
        }
    
    def deny_permission(self, request_id: str, remember: bool = False) -> Dict[str, Any]:
        """拒绝权限"""
        if request_id not in self.pending_requests:
            return {
                "status": "error",
                "message": "权限请求不存在"
            }
        
        request = self.pending_requests[request_id]
        
        # 缓存拒绝
        cache_key = f"{request.action}:{request.resource}"
        if remember:
            self.permission_cache[cache_key] = PermissionLevel.DENY
        
        request.status = "denied"
        del self.pending_requests[request_id]
        
        logger.info(f"权限已拒绝: {request_id}")
        
        return {
            "status": "success",
            "message": "权限已拒绝"
        }
    
    def validate_file_access(self, file_path: str, operation: str) -> Dict[str, Any]:
        """验证文件访问权限"""
        # TODO: 实现文件访问验证
        return {
            "status": "allowed",
            "message": "文件访问已允许"
        }


class AuditLogger:
    """审计日志记录器"""
    
    def __init__(self, log_file: str = "audit.log"):
        self.log_file = log_file
        self.events: List[AuditEvent] = []
        self.max_events = 10000
    
    def log_event(self, event_type: AuditEventType, description: str, details: Dict[str, Any]) -> Dict[str, Any]:
        """记录审计事件"""
        event = AuditEvent(
            event_type=event_type,
            description=description,
            details=details
        )
        
        self.events.append(event)
        
        # 限制事件数量
        if len(self.events) > self.max_events:
            self.events = self.events[-self.max_events:]
        
        # 写入文件
        self._write_to_file(event)
        
        logger.info(f"审计事件已记录: {event_type.value}")
        
        return {
            "status": "success",
            "event": event.to_dict()
        }
    
    def _write_to_file(self, event: AuditEvent):
        """写入审计日志文件"""
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(event.to_dict(), ensure_ascii=False) + '\n')
        except Exception as e:
            logger.error(f"写入审计日志失败: {e}")
    
    def get_events(self, limit: int = 100, event_type: Optional[AuditEventType] = None) -> Dict[str, Any]:
        """获取审计事件"""
        events = self.events
        
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        # 返回最新的事件
        events = events[-limit:]
        
        return {
            "status": "success",
            "events": [e.to_dict() for e in events],
            "count": len(events)
        }
    
    def clear_events(self) -> Dict[str, Any]:
        """清除审计事件"""
        self.events = []
        logger.info("审计事件已清除")
        return {
            "status": "success",
            "message": "审计事件已清除"
        }


class SecurityAudit:
    """安全与审计系统（主类）"""

class SecurityAuditSystem(SecurityAudit):
    """安全与审计系统（向后兼容）"""
    """安全与审计系统"""
    
    def __init__(self):
        self.vm_policy = VMSecurityPolicy()
        self.permission_manager = HostPermissionManager()
        self.audit_logger = AuditLogger()
    
    async def validate_vm_command(self, command: str) -> Dict[str, Any]:
        """验证虚拟机命令"""
        result = self.vm_policy.validate_command(command)
        
        # 记录审计事件
        if result["status"] == "denied":
            self.audit_logger.log_event(
                AuditEventType.PERMISSION_DENIED,
                f"虚拟机命令被拒绝: {command}",
                {"command": command, "reason": result["reason"]}
            )
        
        return result
    
    async def request_host_permission(self, action: str, resource: str, description: str) -> Dict[str, Any]:
        """请求宿主机权限"""
        result = self.permission_manager.request_permission(action, resource, description)
        
        # 记录审计事件
        self.audit_logger.log_event(
            AuditEventType.PERMISSION_REQUEST,
            f"权限请求: {action} - {resource}",
            {"action": action, "resource": resource, "description": description}
        )
        
        return result
    
    async def approve_host_permission(self, request_id: str, remember: bool = False) -> Dict[str, Any]:
        """批准宿主机权限"""
        result = self.permission_manager.approve_permission(request_id, remember)
        
        # 记录审计事件
        self.audit_logger.log_event(
            AuditEventType.PERMISSION_GRANTED,
            f"权限已批准: {request_id}",
            {"request_id": request_id, "remember": remember}
        )
        
        return result
    
    async def deny_host_permission(self, request_id: str, remember: bool = False) -> Dict[str, Any]:
        """拒绝宿主机权限"""
        result = self.permission_manager.deny_permission(request_id, remember)
        
        # 记录审计事件
        self.audit_logger.log_event(
            AuditEventType.PERMISSION_DENIED,
            f"权限已拒绝: {request_id}",
            {"request_id": request_id, "remember": remember}
        )
        
        return result
    
    async def get_audit_log(self, limit: int = 100) -> Dict[str, Any]:
        """获取审计日志"""
        return self.audit_logger.get_events(limit)
