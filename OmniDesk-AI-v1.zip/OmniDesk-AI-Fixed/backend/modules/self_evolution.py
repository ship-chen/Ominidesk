"""
自我进化模块 - L2 中级功能
支持自动扩展能力、自动调参、自动修复常见错误
"""

import logging
import json
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import time

logger = logging.getLogger(__name__)


class SkillType(Enum):
    """技能类型"""
    AUTOMATION = "automation"  # 自动化脚本
    PERCEPTION = "perception"  # 感知能力
    REASONING = "reasoning"  # 推理能力
    TOOL = "tool"  # 工具集成


@dataclass
class Skill:
    """技能"""
    skill_id: str
    name: str
    skill_type: SkillType
    description: str
    code: str
    version: str = "1.0.0"
    success_rate: float = 0.0
    usage_count: int = 0
    last_used: Optional[float] = None
    enabled: bool = True


@dataclass
class Parameter:
    """参数"""
    name: str
    current_value: Any
    min_value: Optional[Any] = None
    max_value: Optional[Any] = None
    step: Optional[Any] = None
    success_history: List[Tuple[Any, float]] = field(default_factory=list)  # (value, success_rate)


@dataclass
class ErrorPattern:
    """错误模式"""
    error_type: str
    pattern: str
    frequency: int = 0
    solutions: List[str] = field(default_factory=list)
    last_occurrence: Optional[float] = None


class SelfEvolutionEngine:
    """自我进化引擎"""
    
    def __init__(self):
        self.skills: Dict[str, Skill] = {}
        self.parameters: Dict[str, Parameter] = {}
        self.error_patterns: Dict[str, ErrorPattern] = {}
        self.evolution_history: List[Dict[str, Any]] = []
        self.adaptation_threshold = 0.7  # 70% 成功率阈值
        
        logger.info("自我进化引擎已初始化")
    
    async def auto_extend_capability(self, capability_name: str, description: str = "") -> bool:
        """
        自动扩展能力 - 发现能力不足时自动下载技能
        
        Args:
            capability_name: 能力名称
            description: 能力描述
        
        Returns:
            是否成功扩展
        """
        try:
            logger.info(f"尝试自动扩展能力: {capability_name}")
            
            # 检查是否已有该技能
            if capability_name in self.skills:
                logger.info(f"技能已存在: {capability_name}")
                return True
            
            # 模拟从技能库下载技能
            skill = Skill(
                skill_id=f"skill_{int(time.time())}",
                name=capability_name,
                skill_type=SkillType.AUTOMATION,
                description=description or f"自动下载的技能: {capability_name}",
                code=f"# 技能代码: {capability_name}\nasync def execute():\n    pass"
            )
            
            self.skills[capability_name] = skill
            
            # 记录进化历史
            self.evolution_history.append({
                "timestamp": time.time(),
                "event": "skill_added",
                "skill_name": capability_name,
                "skill_id": skill.skill_id
            })
            
            logger.info(f"技能已添加: {capability_name}")
            return True
        
        except Exception as e:
            logger.error(f"扩展能力失败: {e}")
            return False
    
    async def auto_tune_parameters(self, operation_name: str, metric: str) -> bool:
        """
        自动调参 - 根据失败率自动调整策略参数
        
        Args:
            operation_name: 操作名称
            metric: 指标 (success_rate, response_time, etc.)
        
        Returns:
            是否成功调参
        """
        try:
            logger.info(f"执行自动调参: {operation_name} (指标: {metric})")
            
            if operation_name not in self.parameters:
                logger.warning(f"参数不存在: {operation_name}")
                return False
            
            param = self.parameters[operation_name]
            
            # 分析历史数据
            if not param.success_history:
                logger.warning(f"没有历史数据: {operation_name}")
                return False
            
            # 计算平均成功率
            avg_success = sum(rate for _, rate in param.success_history) / len(param.success_history)
            
            # 如果成功率低于阈值，尝试调整参数
            if avg_success < self.adaptation_threshold:
                logger.info(f"成功率低于阈值 ({avg_success:.2%} < {self.adaptation_threshold:.2%})，调整参数")
                
                # 尝试增加参数值
                if param.step and param.max_value:
                    new_value = min(param.current_value + param.step, param.max_value)
                    param.current_value = new_value
                    
                    logger.info(f"参数已调整: {operation_name} = {new_value}")
                    
                    # 记录进化历史
                    self.evolution_history.append({
                        "timestamp": time.time(),
                        "event": "parameter_tuned",
                        "operation": operation_name,
                        "old_value": param.current_value - param.step,
                        "new_value": new_value,
                        "metric": metric,
                        "avg_success": avg_success
                    })
                    
                    return True
            
            return False
        
        except Exception as e:
            logger.error(f"自动调参失败: {e}")
            return False
    
    async def auto_fix_error(self, error_type: str, error_message: str) -> Optional[str]:
        """
        自动修复常见错误 - 遇到已知错误自动切换备用方案
        
        Args:
            error_type: 错误类型
            error_message: 错误信息
        
        Returns:
            修复方案（如果有）
        """
        try:
            logger.info(f"尝试自动修复错误: {error_type}")
            
            # 记录错误模式
            if error_type not in self.error_patterns:
                self.error_patterns[error_type] = ErrorPattern(
                    error_type=error_type,
                    pattern=error_message
                )
            
            pattern = self.error_patterns[error_type]
            pattern.frequency += 1
            pattern.last_occurrence = time.time()
            
            # 如果错误频繁发生，尝试应用已知的解决方案
            if pattern.frequency > 2 and pattern.solutions:
                solution = pattern.solutions[0]
                logger.info(f"应用已知解决方案: {solution}")
                
                # 记录进化历史
                self.evolution_history.append({
                    "timestamp": time.time(),
                    "event": "error_fixed",
                    "error_type": error_type,
                    "solution": solution,
                    "frequency": pattern.frequency
                })
                
                return solution
            
            # 尝试添加新的解决方案
            if error_type == "timeout":
                solution = "增加超时时间"
                pattern.solutions.append(solution)
                return solution
            
            elif error_type == "not_found":
                solution = "重试操作"
                pattern.solutions.append(solution)
                return solution
            
            elif error_type == "permission_denied":
                solution = "请求用户权限"
                pattern.solutions.append(solution)
                return solution
            
            logger.warning(f"未知的错误类型: {error_type}")
            return None
        
        except Exception as e:
            logger.error(f"自动修复失败: {e}")
            return None
    
    async def record_operation_result(self, operation_name: str, success: bool, duration: float = 0):
        """
        记录操作结果 - 用于参数调优
        
        Args:
            operation_name: 操作名称
            success: 是否成功
            duration: 操作耗时
        """
        if operation_name not in self.parameters:
            self.parameters[operation_name] = Parameter(
                name=operation_name,
                current_value=1.0
            )
        
        param = self.parameters[operation_name]
        success_rate = 1.0 if success else 0.0
        param.success_history.append((param.current_value, success_rate))
        
        # 保持历史记录在一定大小
        if len(param.success_history) > 100:
            param.success_history = param.success_history[-100:]
    
    async def get_evolution_status(self) -> Dict[str, Any]:
        """获取进化状态"""
        return {
            "skills_count": len(self.skills),
            "parameters_count": len(self.parameters),
            "error_patterns": len(self.error_patterns),
            "evolution_events": len(self.evolution_history),
            "enabled_skills": sum(1 for s in self.skills.values() if s.enabled),
            "avg_skill_success_rate": sum(s.success_rate for s in self.skills.values()) / len(self.skills) if self.skills else 0
        }
    
    async def get_evolution_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取进化历史"""
        return self.evolution_history[-limit:]
    
    async def get_skills(self) -> List[Skill]:
        """获取所有技能"""
        return list(self.skills.values())
    
    async def enable_skill(self, skill_name: str) -> bool:
        """启用技能"""
        if skill_name in self.skills:
            self.skills[skill_name].enabled = True
            logger.info(f"技能已启用: {skill_name}")
            return True
        return False
    
    async def disable_skill(self, skill_name: str) -> bool:
        """禁用技能"""
        if skill_name in self.skills:
            self.skills[skill_name].enabled = False
            logger.info(f"技能已禁用: {skill_name}")
            return True
        return False
    
    async def get_error_patterns(self) -> List[ErrorPattern]:
        """获取错误模式"""
        return list(self.error_patterns.values())
