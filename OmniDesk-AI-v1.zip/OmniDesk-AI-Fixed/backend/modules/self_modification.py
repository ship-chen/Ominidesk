"""
自我代码修改模块 - L3 高级功能
支持受限的自我代码修改，核心代码和权限系统受保护
"""

import logging
import os
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class ModificationScope(Enum):
    """修改范围"""
    CONFIG = "config"
    SKILL = "skill"
    UI_LAYOUT = "ui_layout"
    PARAMETER = "parameter"


class ModificationStatus(Enum):
    """修改状态"""
    PENDING = "pending"
    APPROVED = "approved"
    APPLIED = "applied"
    ROLLED_BACK = "rolled_back"
    FAILED = "failed"


@dataclass
class CodeModification:
    """代码修改"""
    modification_id: str
    scope: ModificationScope
    target_file: str
    old_code: str
    new_code: str
    reason: str
    status: ModificationStatus = ModificationStatus.PENDING
    created_at: float = field(default_factory=time.time)
    applied_at: Optional[float] = None
    rolled_back_at: Optional[float] = None


@dataclass
class ForbiddenZone:
    """禁区 - 不允许修改的代码区域"""
    zone_id: str
    file_path: str
    pattern: str
    reason: str
    created_at: float = field(default_factory=time.time)


class SelfModificationEngine:
    """自我代码修改引擎"""
    
    def __init__(self):
        self.modifications: Dict[str, CodeModification] = {}
        self.modification_history: List[CodeModification] = []
        self.forbidden_zones: Dict[str, ForbiddenZone] = {}
        self._init_forbidden_zones()
        
        logger.info("自我代码修改引擎已初始化")
    
    def _init_forbidden_zones(self):
        """初始化禁区"""
        forbidden_patterns = [
            ("core_security", "backend/utils/exceptions.py", "class.*Exception", "核心异常类不允许修改"),
            ("core_auth", "backend/utils/logger.py", "def.*log", "日志系统不允许修改"),
            ("core_db", "backend/models/database.py", "class.*Database", "数据库核心不允许修改"),
        ]
        
        for zone_id, file_path, pattern, reason in forbidden_patterns:
            self.add_forbidden_zone(zone_id, file_path, pattern, reason)
    
    def add_forbidden_zone(self, zone_id: str, file_path: str, pattern: str, reason: str) -> bool:
        """添加禁区"""
        if zone_id not in self.forbidden_zones:
            self.forbidden_zones[zone_id] = ForbiddenZone(
                zone_id=zone_id,
                file_path=file_path,
                pattern=pattern,
                reason=reason
            )
            logger.info(f"禁区已添加: {zone_id}")
            return True
        return False
    
    def is_forbidden(self, file_path: str, code_snippet: str) -> bool:
        """检查代码是否在禁区"""
        import re
        
        for zone in self.forbidden_zones.values():
            if zone.file_path in file_path:
                if re.search(zone.pattern, code_snippet):
                    logger.warning(f"代码在禁区内: {zone.reason}")
                    return True
        return False
    
    async def propose_modification(self, scope: str, target_file: str, 
                                   old_code: str, new_code: str, reason: str) -> Optional[CodeModification]:
        """提议代码修改"""
        try:
            # 检查是否在禁区
            if self.is_forbidden(target_file, old_code):
                logger.error("修改被拒绝: 代码在禁区内")
                return None
            
            modification_id = f"mod_{int(time.time() * 1000)}"
            
            modification = CodeModification(
                modification_id=modification_id,
                scope=ModificationScope[scope.upper()],
                target_file=target_file,
                old_code=old_code,
                new_code=new_code,
                reason=reason
            )
            
            self.modifications[modification_id] = modification
            logger.info(f"修改已提议: {modification_id}")
            
            return modification
        
        except Exception as e:
            logger.error(f"提议修改失败: {e}")
            return None
    
    async def approve_modification(self, modification_id: str) -> bool:
        """批准代码修改"""
        if modification_id in self.modifications:
            self.modifications[modification_id].status = ModificationStatus.APPROVED
            logger.info(f"修改已批准: {modification_id}")
            return True
        return False
    
    async def apply_modification(self, modification_id: str) -> bool:
        """应用代码修改"""
        try:
            if modification_id not in self.modifications:
                logger.error(f"修改不存在: {modification_id}")
                return False
            
            modification = self.modifications[modification_id]
            
            if modification.status != ModificationStatus.APPROVED:
                logger.error(f"修改未被批准: {modification_id}")
                return False
            
            # 读取文件
            if not os.path.exists(modification.target_file):
                logger.error(f"目标文件不存在: {modification.target_file}")
                return False
            
            with open(modification.target_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 替换代码
            if modification.old_code not in content:
                logger.error(f"原始代码未找到: {modification_id}")
                return False
            
            new_content = content.replace(modification.old_code, modification.new_code)
            
            # 写入文件
            with open(modification.target_file, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            modification.status = ModificationStatus.APPLIED
            modification.applied_at = time.time()
            self.modification_history.append(modification)
            
            logger.info(f"修改已应用: {modification_id}")
            return True
        
        except Exception as e:
            logger.error(f"应用修改失败: {e}")
            return False
    
    async def rollback_modification(self, modification_id: str) -> bool:
        """回滚代码修改"""
        try:
            if modification_id not in self.modifications:
                logger.error(f"修改不存在: {modification_id}")
                return False
            
            modification = self.modifications[modification_id]
            
            if modification.status != ModificationStatus.APPLIED:
                logger.error(f"修改未被应用: {modification_id}")
                return False
            
            # 读取文件
            with open(modification.target_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 恢复代码
            if modification.new_code not in content:
                logger.error(f"当前代码未找到: {modification_id}")
                return False
            
            new_content = content.replace(modification.new_code, modification.old_code)
            
            # 写入文件
            with open(modification.target_file, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            modification.status = ModificationStatus.ROLLED_BACK
            modification.rolled_back_at = time.time()
            
            logger.info(f"修改已回滚: {modification_id}")
            return True
        
        except Exception as e:
            logger.error(f"回滚修改失败: {e}")
            return False
    
    async def get_pending_modifications(self) -> List[CodeModification]:
        """获取待审批的修改"""
        return [m for m in self.modifications.values() if m.status == ModificationStatus.PENDING]
    
    async def get_modification_history(self, limit: int = 50) -> List[CodeModification]:
        """获取修改历史"""
        return self.modification_history[-limit:]
    
    async def get_forbidden_zones(self) -> List[ForbiddenZone]:
        """获取所有禁区"""
        return list(self.forbidden_zones.values())
