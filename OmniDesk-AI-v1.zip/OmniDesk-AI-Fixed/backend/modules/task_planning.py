"""
任务规划模块 - L2 中级功能
支持 ReAct 模式：思考 → 行动 → 观察 → 纠错
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import time
import json

logger = logging.getLogger(__name__)


class ReasoningType(Enum):
    """推理类型"""
    THINK = "think"  # 思考
    ACT = "act"  # 行动
    OBSERVE = "observe"  # 观察
    CORRECT = "correct"  # 纠错


@dataclass
class ReasoningStep:
    """推理步骤"""
    step_id: str
    reasoning_type: ReasoningType
    content: str
    timestamp: float = field(default_factory=time.time)
    result: Optional[Any] = None
    confidence: float = 1.0


@dataclass
class TaskPlan:
    """任务计划"""
    task_id: str
    description: str
    goal: str
    steps: List[Dict[str, Any]] = field(default_factory=list)
    reasoning_chain: List[ReasoningStep] = field(default_factory=list)
    status: str = "planning"  # planning, executing, completed, failed
    result: Optional[Any] = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None


class TaskPlanningEngine:
    """任务规划引擎 - ReAct 模式"""
    
    def __init__(self):
        self.tasks: Dict[str, TaskPlan] = {}
        self.action_callbacks: Dict[str, Callable] = {}
        self.observation_callbacks: Dict[str, Callable] = {}
        self.task_counter = 0
        
        logger.info("任务规划引擎已初始化")
    
    async def create_task(self, title: str, description: str, priority: str = "medium") -> TaskPlan:
        """创建任务"""
        self.task_counter += 1
        task_id = f"task_{self.task_counter}"
        
        task = TaskPlan(
            task_id=task_id,
            description=description,
            goal=title
        )
        
        self.tasks[task_id] = task
        logger.info(f"任务已创建: {task_id} - {title}")
        
        return task
    
    async def plan_task(self, task_id: str, description: str, goal: str) -> TaskPlan:
        """
        规划任务 - THINK 阶段
        
        Args:
            task_id: 任务 ID
            description: 任务描述
            goal: 任务目标
        
        Returns:
            任务计划
        """
        try:
            logger.info(f"规划任务: {task_id} - {description}")
            
            task = TaskPlan(
                task_id=task_id,
                description=description,
                goal=goal
            )
            
            # THINK: 分析任务
            think_step = ReasoningStep(
                step_id=f"{task_id}_think",
                reasoning_type=ReasoningType.THINK,
                content=f"分析任务: {description}\n目标: {goal}"
            )
            task.reasoning_chain.append(think_step)
            
            # 生成任务步骤
            steps = await self._generate_task_steps(description, goal)
            task.steps = steps
            
            task.status = "planning"
            self.tasks[task_id] = task
            
            logger.info(f"任务规划完成: {len(steps)} 个步骤")
            return task
        
        except Exception as e:
            logger.error(f"任务规划失败: {e}")
            raise
    
    async def _generate_task_steps(self, description: str, goal: str) -> List[Dict[str, Any]]:
        """生成任务步骤"""
        # 这里应该使用 LLM 生成步骤
        # 现在是模拟实现
        steps = [
            {
                "step_id": "step_1",
                "action": "analyze",
                "description": f"分析任务: {description}",
                "expected_result": "理解任务需求"
            },
            {
                "step_id": "step_2",
                "action": "prepare",
                "description": "准备执行环境",
                "expected_result": "环境就绪"
            },
            {
                "step_id": "step_3",
                "action": "execute",
                "description": f"执行任务: {goal}",
                "expected_result": "任务完成"
            },
            {
                "step_id": "step_4",
                "action": "verify",
                "description": "验证结果",
                "expected_result": "结果正确"
            }
        ]
        return steps
    
    async def execute_task(self, task_id: str) -> TaskPlan:
        """
        执行任务 - ACT 阶段
        
        Args:
            task_id: 任务 ID
        
        Returns:
            执行结果
        """
        try:
            if task_id not in self.tasks:
                raise ValueError(f"任务不存在: {task_id}")
            
            task = self.tasks[task_id]
            task.status = "executing"
            
            logger.info(f"开始执行任务: {task_id}")
            
            # 执行每个步骤
            for i, step_config in enumerate(task.steps):
                try:
                    logger.info(f"执行步骤 {i+1}/{len(task.steps)}: {step_config.get('description')}")
                    
                    # ACT: 执行行动
                    act_step = ReasoningStep(
                        step_id=f"{task_id}_act_{i}",
                        reasoning_type=ReasoningType.ACT,
                        content=f"执行: {step_config.get('description')}"
                    )
                    task.reasoning_chain.append(act_step)
                    
                    # 调用行动回调
                    action = step_config.get('action')
                    if action in self.action_callbacks:
                        result = await self.action_callbacks[action](step_config)
                        act_step.result = result
                    
                    # OBSERVE: 观察结果
                    observe_step = ReasoningStep(
                        step_id=f"{task_id}_observe_{i}",
                        reasoning_type=ReasoningType.OBSERVE,
                        content=f"观察结果: {act_step.result}"
                    )
                    task.reasoning_chain.append(observe_step)
                    
                    # 验证结果
                    if not await self._verify_step_result(step_config, act_step.result):
                        # CORRECT: 纠错
                        logger.warning(f"步骤 {i+1} 结果不符合预期，尝试纠错")
                        
                        correct_step = ReasoningStep(
                            step_id=f"{task_id}_correct_{i}",
                            reasoning_type=ReasoningType.CORRECT,
                            content=f"纠错: 重新执行步骤"
                        )
                        task.reasoning_chain.append(correct_step)
                        
                        # 重试
                        result = await self.action_callbacks[action](step_config)
                        correct_step.result = result
                    
                    await asyncio.sleep(0.5)  # 步骤间延迟
                
                except Exception as e:
                    logger.error(f"步骤 {i+1} 执行失败: {e}")
                    task.status = "failed"
                    task.error = str(e)
                    task.completed_at = time.time()
                    return task
            
            task.status = "completed"
            task.result = {"steps_executed": len(task.steps)}
            task.completed_at = time.time()
            
            logger.info(f"任务执行完成: {task_id}")
            return task
        
        except Exception as e:
            logger.error(f"任务执行失败: {e}")
            task.status = "failed"
            task.error = str(e)
            task.completed_at = time.time()
            return task
    
    async def _verify_step_result(self, step_config: Dict[str, Any], result: Any) -> bool:
        """验证步骤结果"""
        expected_result = step_config.get('expected_result')
        
        if not expected_result:
            return True
        
        # 简单的验证逻辑
        if result is None:
            return False
        
        return True
    
    def register_action_callback(self, action_name: str, callback: Callable):
        """注册行动回调"""
        self.action_callbacks[action_name] = callback
        logger.info(f"已注册行动回调: {action_name}")
    
    def register_observation_callback(self, observation_name: str, callback: Callable):
        """注册观察回调"""
        self.observation_callbacks[observation_name] = callback
        logger.info(f"已注册观察回调: {observation_name}")
    
    async def get_task(self, task_id: str) -> Optional[TaskPlan]:
        """获取任务"""
        return self.tasks.get(task_id)
    
    async def get_task_status(self, task_id: str) -> Optional[TaskPlan]:
        """获取任务状态"""
        return self.tasks.get(task_id)
    
    async def get_reasoning_chain(self, task_id: str) -> List[ReasoningStep]:
        """获取推理链"""
        task = self.tasks.get(task_id)
        return task.reasoning_chain if task else []
    
    async def list_tasks(self) -> List[TaskPlan]:
        """列出所有任务"""
        return list(self.tasks.values())
    
    async def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        if task_id in self.tasks:
            task = self.tasks[task_id]
            if task.status == "executing":
                task.status = "cancelled"
                logger.info(f"任务已取消: {task_id}")
                return True
        return False
