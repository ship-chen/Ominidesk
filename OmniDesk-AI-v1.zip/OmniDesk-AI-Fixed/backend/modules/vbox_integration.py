#!/usr/bin/env python3
"""
VirtualBox 集成层 - 支持源码编译和直接调用
支持 VirtualBox 7.x，Python 3.6+
"""

import os
import sys
import subprocess
import json
import logging
import platform
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class VMState(Enum):
    """虚拟机状态"""
    POWEROFF = "poweroff"
    RUNNING = "running"
    PAUSED = "paused"
    SAVED = "saved"
    ABORTED = "aborted"
    UNKNOWN = "unknown"


@dataclass
class VMInfo:
    """虚拟机信息"""
    name: str
    uuid: str
    state: VMState
    memory: int = 0
    cpus: int = 0
    vram: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'uuid': self.uuid,
            'state': self.state.value,
            'memory': self.memory,
            'cpus': self.cpus,
            'vram': self.vram
        }


class VBoxIntegration:
    """VirtualBox 集成 - 无缝支持源码和二进制"""
    
    def __init__(self, vbox_path: Optional[str] = None):
        """
        初始化 VirtualBox 集成
        
        Args:
            vbox_path: VirtualBox 安装路径（可选）
        """
        self.vbox_path = vbox_path or self._find_vbox_path()
        self.vbox_manage_cmd = self._get_vboxmanage_cmd()
        self.is_available = self._check_availability()
        self.vms_cache: Dict[str, VMInfo] = {}
        
        logger.info(f"VirtualBox 集成初始化 - 可用: {self.is_available}")
    
    def _find_vbox_path(self) -> Optional[str]:
        """查找 VirtualBox 安装路径"""
        system = platform.system()
        
        if system == "Windows":
            # Windows 查找路径
            possible_paths = [
                r"C:\Program Files\Oracle\VirtualBox",
                r"C:\Program Files (x86)\Oracle\VirtualBox",
                r"C:\Program Files\VirtualBox",
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    return path
        
        elif system == "Linux":
            # Linux 查找路径
            result = shutil.which("VBoxManage")
            if result:
                return os.path.dirname(result)
        
        elif system == "Darwin":  # macOS
            # macOS 查找路径
            possible_paths = [
                "/Applications/VirtualBox.app/Contents/MacOS",
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    return path
        
        return None
    
    def _get_vboxmanage_cmd(self) -> str:
        """获取 VBoxManage 命令"""
        if self.vbox_path:
            if platform.system() == "Windows":
                cmd = os.path.join(self.vbox_path, "VBoxManage.exe")
            else:
                cmd = os.path.join(self.vbox_path, "VBoxManage")
            
            if os.path.exists(cmd):
                return cmd
        
        # 尝试系统 PATH
        cmd = shutil.which("VBoxManage")
        if cmd:
            return cmd
        
        return "VBoxManage"
    
    def _check_availability(self) -> bool:
        """检查 VirtualBox 是否可用"""
        try:
            result = subprocess.run(
                [self.vbox_manage_cmd, "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except Exception as e:
            logger.warning(f"VirtualBox 检查失败: {e}")
            return False
    
    def _run_command(self, args: List[str], timeout: int = 30) -> Tuple[int, str, str]:
        """
        运行 VBoxManage 命令
        
        Args:
            args: 命令参数列表
            timeout: 超时时间（秒）
        
        Returns:
            (返回码, 标准输出, 标准错误)
        """
        try:
            cmd = [self.vbox_manage_cmd] + args
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", "命令执行超时"
        except Exception as e:
            return -1, "", str(e)
    
    # ========================================================================
    # 虚拟机列表和信息
    # ========================================================================
    
    def list_vms(self, refresh: bool = False) -> List[VMInfo]:
        """
        列出所有虚拟机
        
        Args:
            refresh: 是否刷新缓存
        
        Returns:
            虚拟机信息列表
        """
        if not self.is_available:
            logger.error("VirtualBox 不可用")
            return []
        
        if not refresh and self.vms_cache:
            return list(self.vms_cache.values())
        
        try:
            returncode, stdout, stderr = self._run_command(["list", "vms"])
            
            if returncode != 0:
                logger.error(f"列出虚拟机失败: {stderr}")
                return []
            
            vms = []
            for line in stdout.strip().split('\n'):
                if not line:
                    continue
                
                # 解析格式: "name" {uuid}
                parts = line.rsplit(' {', 1)
                if len(parts) == 2:
                    name = parts[0].strip('"')
                    uuid = parts[1].rstrip('}')
                    
                    # 获取虚拟机状态
                    state = self._get_vm_state(name)
                    info = VMInfo(name=name, uuid=uuid, state=state)
                    vms.append(info)
                    self.vms_cache[name] = info
            
            return vms
        
        except Exception as e:
            logger.error(f"列出虚拟机异常: {e}")
            return []
    
    def get_vm_info(self, vm_name: str) -> Optional[VMInfo]:
        """
        获取虚拟机详细信息
        
        Args:
            vm_name: 虚拟机名称
        
        Returns:
            虚拟机信息
        """
        if not self.is_available:
            return None
        
        try:
            returncode, stdout, stderr = self._run_command(
                ["showvminfo", vm_name, "--machinereadable"]
            )
            
            if returncode != 0:
                logger.error(f"获取虚拟机信息失败: {stderr}")
                return None
            
            # 解析输出
            info_dict = {}
            for line in stdout.strip().split('\n'):
                if '=' in line:
                    key, value = line.split('=', 1)
                    info_dict[key.strip()] = value.strip().strip('"')
            
            state_str = info_dict.get('VMState', 'unknown').lower()
            state = VMState(state_str) if state_str in [s.value for s in VMState] else VMState.UNKNOWN
            
            vm_info = VMInfo(
                name=vm_name,
                uuid=info_dict.get('UUID', ''),
                state=state,
                memory=int(info_dict.get('memory', 0)),
                cpus=int(info_dict.get('cpus', 0)),
                vram=int(info_dict.get('vram', 0))
            )
            
            self.vms_cache[vm_name] = vm_info
            return vm_info
        
        except Exception as e:
            logger.error(f"获取虚拟机信息异常: {e}")
            return None
    
    def _get_vm_state(self, vm_name: str) -> VMState:
        """获取虚拟机状态"""
        try:
            returncode, stdout, stderr = self._run_command(
                ["showvminfo", vm_name, "--machinereadable"]
            )
            
            if returncode == 0:
                for line in stdout.split('\n'):
                    if line.startswith('VMState='):
                        state_str = line.split('=')[1].strip('"').lower()
                        try:
                            return VMState(state_str)
                        except ValueError:
                            return VMState.UNKNOWN
            
            return VMState.UNKNOWN
        except Exception:
            return VMState.UNKNOWN
    
    # ========================================================================
    # 虚拟机控制
    # ========================================================================
    
    def start_vm(self, vm_name: str, headless: bool = False) -> Tuple[bool, str]:
        """
        启动虚拟机
        
        Args:
            vm_name: 虚拟机名称
            headless: 是否无头模式启动
        
        Returns:
            (成功标志, 消息)
        """
        if not self.is_available:
            return False, "VirtualBox 不可用"
        
        try:
            mode = "headless" if headless else "gui"
            returncode, stdout, stderr = self._run_command(
                ["startvm", vm_name, "--type", mode],
                timeout=60
            )
            
            if returncode == 0:
                logger.info(f"虚拟机已启动: {vm_name}")
                # 清除缓存
                if vm_name in self.vms_cache:
                    self.vms_cache[vm_name].state = VMState.RUNNING
                return True, f"虚拟机 {vm_name} 已启动"
            else:
                logger.error(f"启动虚拟机失败: {stderr}")
                return False, f"启动失败: {stderr}"
        
        except Exception as e:
            logger.error(f"启动虚拟机异常: {e}")
            return False, str(e)
    
    def stop_vm(self, vm_name: str, force: bool = False) -> Tuple[bool, str]:
        """
        停止虚拟机
        
        Args:
            vm_name: 虚拟机名称
            force: 是否强制停止
        
        Returns:
            (成功标志, 消息)
        """
        if not self.is_available:
            return False, "VirtualBox 不可用"
        
        try:
            if force:
                cmd = ["controlvm", vm_name, "poweroff"]
            else:
                cmd = ["controlvm", vm_name, "acpipowerbutton"]
            
            returncode, stdout, stderr = self._run_command(cmd, timeout=30)
            
            if returncode == 0:
                logger.info(f"虚拟机已停止: {vm_name}")
                if vm_name in self.vms_cache:
                    self.vms_cache[vm_name].state = VMState.POWEROFF
                return True, f"虚拟机 {vm_name} 已停止"
            else:
                logger.error(f"停止虚拟机失败: {stderr}")
                return False, f"停止失败: {stderr}"
        
        except Exception as e:
            logger.error(f"停止虚拟机异常: {e}")
            return False, str(e)
    
    def pause_vm(self, vm_name: str) -> Tuple[bool, str]:
        """
        暂停虚拟机
        
        Args:
            vm_name: 虚拟机名称
        
        Returns:
            (成功标志, 消息)
        """
        if not self.is_available:
            return False, "VirtualBox 不可用"
        
        try:
            returncode, stdout, stderr = self._run_command(
                ["controlvm", vm_name, "pause"]
            )
            
            if returncode == 0:
                logger.info(f"虚拟机已暂停: {vm_name}")
                if vm_name in self.vms_cache:
                    self.vms_cache[vm_name].state = VMState.PAUSED
                return True, f"虚拟机 {vm_name} 已暂停"
            else:
                return False, f"暂停失败: {stderr}"
        
        except Exception as e:
            logger.error(f"暂停虚拟机异常: {e}")
            return False, str(e)
    
    def resume_vm(self, vm_name: str) -> Tuple[bool, str]:
        """
        恢复虚拟机
        
        Args:
            vm_name: 虚拟机名称
        
        Returns:
            (成功标志, 消息)
        """
        if not self.is_available:
            return False, "VirtualBox 不可用"
        
        try:
            returncode, stdout, stderr = self._run_command(
                ["controlvm", vm_name, "resume"]
            )
            
            if returncode == 0:
                logger.info(f"虚拟机已恢复: {vm_name}")
                if vm_name in self.vms_cache:
                    self.vms_cache[vm_name].state = VMState.RUNNING
                return True, f"虚拟机 {vm_name} 已恢复"
            else:
                return False, f"恢复失败: {stderr}"
        
        except Exception as e:
            logger.error(f"恢复虚拟机异常: {e}")
            return False, str(e)
    
    def restart_vm(self, vm_name: str) -> Tuple[bool, str]:
        """
        重启虚拟机
        
        Args:
            vm_name: 虚拟机名称
        
        Returns:
            (成功标志, 消息)
        """
        success, msg = self.stop_vm(vm_name, force=False)
        if not success:
            return False, f"停止虚拟机失败: {msg}"
        
        # 等待虚拟机完全停止
        import time
        time.sleep(2)
        
        return self.start_vm(vm_name)
    
    # ========================================================================
    # 快照管理
    # ========================================================================
    
    def create_snapshot(self, vm_name: str, snapshot_name: str, description: str = "") -> Tuple[bool, str]:
        """
        创建快照
        
        Args:
            vm_name: 虚拟机名称
            snapshot_name: 快照名称
            description: 快照描述
        
        Returns:
            (成功标志, 消息)
        """
        if not self.is_available:
            return False, "VirtualBox 不可用"
        
        try:
            cmd = ["snapshot", vm_name, "take", snapshot_name]
            if description:
                cmd.extend(["--description", description])
            
            returncode, stdout, stderr = self._run_command(cmd, timeout=60)
            
            if returncode == 0:
                logger.info(f"快照已创建: {vm_name} -> {snapshot_name}")
                return True, f"快照 {snapshot_name} 已创建"
            else:
                logger.error(f"创建快照失败: {stderr}")
                return False, f"创建失败: {stderr}"
        
        except Exception as e:
            logger.error(f"创建快照异常: {e}")
            return False, str(e)
    
    def restore_snapshot(self, vm_name: str, snapshot_name: str) -> Tuple[bool, str]:
        """
        恢复快照
        
        Args:
            vm_name: 虚拟机名称
            snapshot_name: 快照名称
        
        Returns:
            (成功标志, 消息)
        """
        if not self.is_available:
            return False, "VirtualBox 不可用"
        
        try:
            returncode, stdout, stderr = self._run_command(
                ["snapshot", vm_name, "restore", snapshot_name],
                timeout=60
            )
            
            if returncode == 0:
                logger.info(f"快照已恢复: {vm_name} -> {snapshot_name}")
                return True, f"快照 {snapshot_name} 已恢复"
            else:
                logger.error(f"恢复快照失败: {stderr}")
                return False, f"恢复失败: {stderr}"
        
        except Exception as e:
            logger.error(f"恢复快照异常: {e}")
            return False, str(e)
    
    def list_snapshots(self, vm_name: str) -> List[Dict[str, str]]:
        """
        列出快照
        
        Args:
            vm_name: 虚拟机名称
        
        Returns:
            快照列表
        """
        if not self.is_available:
            return []
        
        try:
            returncode, stdout, stderr = self._run_command(
                ["snapshot", vm_name, "list"]
            )
            
            if returncode == 0:
                snapshots = []
                for line in stdout.strip().split('\n'):
                    if line and not line.startswith('Name:'):
                        snapshots.append({'name': line.strip()})
                return snapshots
            else:
                logger.error(f"列出快照失败: {stderr}")
                return []
        
        except Exception as e:
            logger.error(f"列出快照异常: {e}")
            return []
    
    # ========================================================================
    # 系统信息
    # ========================================================================
    
    def get_vbox_version(self) -> str:
        """获取 VirtualBox 版本"""
        if not self.is_available:
            return "未安装"
        
        try:
            returncode, stdout, stderr = self._run_command(["--version"])
            if returncode == 0:
                return stdout.strip()
        except Exception:
            pass
        
        return "未知"
    
    def get_host_info(self) -> Dict[str, Any]:
        """获取主机信息"""
        if not self.is_available:
            return {"available": False}
        
        try:
            returncode, stdout, stderr = self._run_command(
                ["list", "hostinfo", "--machinereadable"]
            )
            
            if returncode == 0:
                info = {}
                for line in stdout.split('\n'):
                    if '=' in line:
                        key, value = line.split('=', 1)
                        info[key.strip()] = value.strip().strip('"')
                return info
        except Exception as e:
            logger.error(f"获取主机信息异常: {e}")
        
        return {"available": False}


# 导出
__all__ = ['VBoxIntegration', 'VMInfo', 'VMState']
