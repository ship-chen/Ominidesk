"""
虚拟机管理器 - 多虚拟机支持
功能：
1. 虚拟机生命周期管理
2. 虚拟机池管理
3. 快照管理
4. 虚拟机状态跟踪
"""

import logging
import asyncio
import time
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

logger = logging.getLogger(__name__)


class VMStatus(Enum):
    """虚拟机状态"""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    ERROR = "error"


@dataclass
class VMSnapshot:
    """虚拟机快照"""
    name: str
    description: str = ""
    created_at: float = field(default_factory=time.time)
    size_mb: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "name": self.name,
            "description": self.description,
            "created_at": self.created_at,
            "size_mb": self.size_mb
        }


@dataclass
class VMConfig:
    """虚拟机配置"""
    vm_id: str
    name: str
    os_type: str = "Windows10_64"
    memory_mb: int = 6144
    cpu_cores: int = 4
    disk_gb: int = 50
    network_mode: str = "nat"
    enable_3d: bool = False
    enable_clipboard: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "vm_id": self.vm_id,
            "name": self.name,
            "os_type": self.os_type,
            "memory_mb": self.memory_mb,
            "cpu_cores": self.cpu_cores,
            "disk_gb": self.disk_gb,
            "network_mode": self.network_mode,
            "enable_3d": self.enable_3d,
            "enable_clipboard": self.enable_clipboard
        }


@dataclass
class VirtualMachine:
    """虚拟机对象"""
    config: VMConfig
    status: VMStatus = VMStatus.STOPPED
    pid: Optional[int] = None
    snapshots: Dict[str, VMSnapshot] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    stopped_at: Optional[float] = None
    last_activity: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        uptime = None
        if self.started_at:
            uptime = time.time() - self.started_at
        
        return {
            "config": self.config.to_dict(),
            "status": self.status.value,
            "pid": self.pid,
            "snapshots": {name: snap.to_dict() for name, snap in self.snapshots.items()},
            "created_at": self.created_at,
            "started_at": self.started_at,
            "stopped_at": self.stopped_at,
            "uptime_seconds": uptime,
            "last_activity": self.last_activity
        }


class VMManager:
    """虚拟机管理器"""
    
    def __init__(self, vbox_controller):
        self.vbox = vbox_controller
        self.vms: Dict[str, VirtualMachine] = {}
        self.vm_counter = 0
        
        # 监控任务
        self.monitor_task: Optional[asyncio.Task] = None
    
    async def create_vm(self, name: str, config: Optional[VMConfig] = None) -> Dict[str, Any]:
        """创建虚拟机"""
        try:
            self.vm_counter += 1
            vm_id = f"vm_{self.vm_counter}_{int(time.time())}"
            
            # 使用提供的配置或创建默认配置
            if not config:
                config = VMConfig(
                    vm_id=vm_id,
                    name=name
                )
            else:
                config.vm_id = vm_id
            
            # 创建虚拟机对象
            vm = VirtualMachine(config=config)
            self.vms[vm_id] = vm
            
            logger.info(f"虚拟机已创建: {vm_id} ({name})")
            
            return {
                "status": "success",
                "vm_id": vm_id,
                "message": f"虚拟机 {name} 已创建",
                "vm": vm.to_dict()
            }
        
        except Exception as e:
            logger.error(f"创建虚拟机失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def start_vm(self, vm_id: str) -> Dict[str, Any]:
        """启动虚拟机"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            if vm.status != VMStatus.STOPPED:
                return {"status": "error", "message": f"虚拟机状态为 {vm.status.value}"}
            
            vm.status = VMStatus.STARTING
            
            # 调用 VirtualBox 启动虚拟机
            result = await self.vbox.start_vm(vm_id)
            
            if result.get("success"):
                vm.status = VMStatus.RUNNING
                vm.started_at = time.time()
                vm.last_activity = time.time()
                
                logger.info(f"虚拟机已启动: {vm_id}")
                
                return {
                    "status": "success",
                    "message": f"虚拟机 {vm.config.name} 已启动",
                    "vm": vm.to_dict()
                }
            else:
                vm.status = VMStatus.ERROR
                return {
                    "status": "error",
                    "message": result.get("error", "启动失败")
                }
        
        except Exception as e:
            logger.error(f"启动虚拟机失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def stop_vm(self, vm_id: str, force: bool = False) -> Dict[str, Any]:
        """停止虚拟机"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            if vm.status == VMStatus.STOPPED:
                return {"status": "error", "message": "虚拟机已停止"}
            
            vm.status = VMStatus.STOPPING
            
            # 调用 VirtualBox 停止虚拟机
            result = await self.vbox.stop_vm(vm_id, force)
            
            if result.get("success"):
                vm.status = VMStatus.STOPPED
                vm.stopped_at = time.time()
                
                logger.info(f"虚拟机已停止: {vm_id}")
                
                return {
                    "status": "success",
                    "message": f"虚拟机 {vm.config.name} 已停止",
                    "vm": vm.to_dict()
                }
            else:
                vm.status = VMStatus.ERROR
                return {
                    "status": "error",
                    "message": result.get("error", "停止失败")
                }
        
        except Exception as e:
            logger.error(f"停止虚拟机失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def pause_vm(self, vm_id: str) -> Dict[str, Any]:
        """暂停虚拟机"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            if vm.status != VMStatus.RUNNING:
                return {"status": "error", "message": "虚拟机未运行"}
            
            vm.status = VMStatus.PAUSED
            
            logger.info(f"虚拟机已暂停: {vm_id}")
            
            return {
                "status": "success",
                "message": f"虚拟机 {vm.config.name} 已暂停",
                "vm": vm.to_dict()
            }
        
        except Exception as e:
            logger.error(f"暂停虚拟机失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def resume_vm(self, vm_id: str) -> Dict[str, Any]:
        """恢复虚拟机"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            if vm.status != VMStatus.PAUSED:
                return {"status": "error", "message": "虚拟机未暂停"}
            
            vm.status = VMStatus.RUNNING
            
            logger.info(f"虚拟机已恢复: {vm_id}")
            
            return {
                "status": "success",
                "message": f"虚拟机 {vm.config.name} 已恢复",
                "vm": vm.to_dict()
            }
        
        except Exception as e:
            logger.error(f"恢复虚拟机失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def take_snapshot(self, vm_id: str, snapshot_name: str, description: str = "") -> Dict[str, Any]:
        """创建快照"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            # 创建快照对象
            snapshot = VMSnapshot(
                name=snapshot_name,
                description=description
            )
            
            vm.snapshots[snapshot_name] = snapshot
            
            logger.info(f"快照已创建: {vm_id}/{snapshot_name}")
            
            return {
                "status": "success",
                "message": f"快照 {snapshot_name} 已创建",
                "snapshot": snapshot.to_dict()
            }
        
        except Exception as e:
            logger.error(f"创建快照失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def restore_snapshot(self, vm_id: str, snapshot_name: str) -> Dict[str, Any]:
        """恢复快照"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            if snapshot_name not in vm.snapshots:
                return {"status": "error", "message": "快照不存在"}
            
            logger.info(f"快照已恢复: {vm_id}/{snapshot_name}")
            
            return {
                "status": "success",
                "message": f"快照 {snapshot_name} 已恢复"
            }
        
        except Exception as e:
            logger.error(f"恢复快照失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def delete_snapshot(self, vm_id: str, snapshot_name: str) -> Dict[str, Any]:
        """删除快照"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            if snapshot_name not in vm.snapshots:
                return {"status": "error", "message": "快照不存在"}
            
            del vm.snapshots[snapshot_name]
            
            logger.info(f"快照已删除: {vm_id}/{snapshot_name}")
            
            return {
                "status": "success",
                "message": f"快照 {snapshot_name} 已删除"
            }
        
        except Exception as e:
            logger.error(f"删除快照失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def delete_vm(self, vm_id: str) -> Dict[str, Any]:
        """删除虚拟机"""
        try:
            if vm_id not in self.vms:
                return {"status": "error", "message": "虚拟机不存在"}
            
            vm = self.vms[vm_id]
            
            # 如果虚拟机正在运行，先停止
            if vm.status == VMStatus.RUNNING:
                await self.stop_vm(vm_id, force=True)
            
            del self.vms[vm_id]
            
            logger.info(f"虚拟机已删除: {vm_id}")
            
            return {
                "status": "success",
                "message": f"虚拟机 {vm.config.name} 已删除"
            }
        
        except Exception as e:
            logger.error(f"删除虚拟机失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def get_vm(self, vm_id: str) -> Dict[str, Any]:
        """获取虚拟机信息"""
        if vm_id not in self.vms:
            return {"status": "error", "message": "虚拟机不存在"}
        
        vm = self.vms[vm_id]
        return {
            "status": "success",
            "vm": vm.to_dict()
        }
    
    async def list_vms(self) -> Dict[str, Any]:
        """列出所有虚拟机"""
        vms_list = [vm.to_dict() for vm in self.vms.values()]
        return {
            "status": "success",
            "vms": vms_list,
            "count": len(vms_list)
        }
    
    async def get_vm_stats(self) -> Dict[str, Any]:
        """获取虚拟机统计"""
        total = len(self.vms)
        running = sum(1 for vm in self.vms.values() if vm.status == VMStatus.RUNNING)
        stopped = sum(1 for vm in self.vms.values() if vm.status == VMStatus.STOPPED)
        paused = sum(1 for vm in self.vms.values() if vm.status == VMStatus.PAUSED)
        
        return {
            "status": "success",
            "stats": {
                "total": total,
                "running": running,
                "stopped": stopped,
                "paused": paused
            }
        }
    
    async def start_monitoring(self):
        """启动虚拟机监控"""
        if self.monitor_task:
            return
        
        self.monitor_task = asyncio.create_task(self._monitor_vms())
        logger.info("虚拟机监控已启动")
    
    async def stop_monitoring(self):
        """停止虚拟机监控"""
        if self.monitor_task:
            self.monitor_task.cancel()
            self.monitor_task = None
            logger.info("虚拟机监控已停止")
    
    async def _monitor_vms(self):
        """监控虚拟机"""
        while True:
            try:
                # 检查虚拟机状态
                for vm_id, vm in self.vms.items():
                    # 更新最后活动时间
                    vm.last_activity = time.time()
                    
                    # 可以在这里添加更多监控逻辑
                    # 如检查虚拟机进程、内存使用等
                
                await asyncio.sleep(5)  # 每 5 秒检查一次
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"监控虚拟机时出错: {e}")
                await asyncio.sleep(5)
