#!/usr/bin/env python3
"""
异常处理模块
定义自定义异常类
"""

from typing import Optional, Dict, Any


class OmniDeskException(Exception):
    """OmniDesk 基础异常"""
    
    def __init__(
        self,
        message: str,
        error_code: str = "UNKNOWN_ERROR",
        details: Optional[Dict[str, Any]] = None
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            error_code: 错误代码
            details: 详细信息
        """
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'error': self.error_code,
            'message': self.message,
            'details': self.details
        }


class VirtualBoxException(OmniDeskException):
    """VirtualBox 异常"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "VBOX_ERROR", details)


class VirtualBoxNotFoundError(VirtualBoxException):
    """VirtualBox 未找到异常"""
    
    def __init__(self, details: Optional[Dict[str, Any]] = None):
        super().__init__("VirtualBox 未安装或未找到", "VBOX_NOT_FOUND", details)


class VirtualMachineNotFoundError(VirtualBoxException):
    """虚拟机未找到异常"""
    
    def __init__(self, vm_name: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(f"虚拟机未找到: {vm_name}", "VM_NOT_FOUND", details)


class VirtualMachineOperationError(VirtualBoxException):
    """虚拟机操作异常"""
    
    def __init__(self, operation: str, vm_name: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(
            f"虚拟机操作失败: {operation} ({vm_name})",
            "VM_OPERATION_ERROR",
            details
        )


class AIException(OmniDeskException):
    """AI 异常"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "AI_ERROR", details)


class ModelNotFoundError(AIException):
    """模型未找到异常"""
    
    def __init__(self, model_name: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(f"模型未找到: {model_name}", "MODEL_NOT_FOUND", details)


class ModelLoadError(AIException):
    """模型加载异常"""
    
    def __init__(self, model_name: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(f"模型加载失败: {model_name}", "MODEL_LOAD_ERROR", details)


class TaskException(OmniDeskException):
    """任务异常"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "TASK_ERROR", details)


class TaskNotFoundError(TaskException):
    """任务未找到异常"""
    
    def __init__(self, task_id: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(f"任务未找到: {task_id}", "TASK_NOT_FOUND", details)


class TaskExecutionError(TaskException):
    """任务执行异常"""
    
    def __init__(self, task_id: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(f"任务执行失败: {task_id}", "TASK_EXECUTION_ERROR", details)


class DatabaseException(OmniDeskException):
    """数据库异常"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "DATABASE_ERROR", details)


class SecurityException(OmniDeskException):
    """安全异常"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "SECURITY_ERROR", details)


class AuthenticationError(SecurityException):
    """认证异常"""
    
    def __init__(self, message: str = "认证失败", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "AUTH_ERROR", details)


class AuthorizationError(SecurityException):
    """授权异常"""
    
    def __init__(self, message: str = "无权限访问", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "AUTHZ_ERROR", details)


class PermissionDeniedError(SecurityException):
    """权限拒绝异常"""
    
    def __init__(self, resource: str, action: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(
            f"权限拒绝: {action} {resource}",
            "PERMISSION_DENIED",
            details
        )


class ValidationException(OmniDeskException):
    """验证异常"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "VALIDATION_ERROR", details)


class TimeoutException(OmniDeskException):
    """超时异常"""
    
    def __init__(self, operation: str, timeout_seconds: int, details: Optional[Dict[str, Any]] = None):
        super().__init__(
            f"操作超时: {operation} ({timeout_seconds}s)",
            "TIMEOUT_ERROR",
            details
        )


class ConfigException(OmniDeskException):
    """配置异常"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "CONFIG_ERROR", details)


# 导出
__all__ = [
    'OmniDeskException',
    'VirtualBoxException',
    'VirtualBoxNotFoundError',
    'VirtualMachineNotFoundError',
    'VirtualMachineOperationError',
    'AIException',
    'ModelNotFoundError',
    'ModelLoadError',
    'TaskException',
    'TaskNotFoundError',
    'TaskExecutionError',
    'DatabaseException',
    'SecurityException',
    'AuthenticationError',
    'AuthorizationError',
    'PermissionDeniedError',
    'ValidationException',
    'TimeoutException',
    'ConfigException'
]
