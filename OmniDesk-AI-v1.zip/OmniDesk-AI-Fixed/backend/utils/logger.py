#!/usr/bin/env python3
"""
日志管理模块
提供统一的日志配置和管理
"""

import logging
import logging.handlers
import os
from pathlib import Path
from typing import Optional

# 日志级别
LOG_LEVELS = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL
}


class LoggerManager:
    """日志管理器"""
    
    def __init__(
        self,
        name: str = "omnidesk",
        level: str = "INFO",
        log_file: Optional[str] = None,
        max_file_size: int = 10485760,  # 10 MB
        backup_count: int = 5
    ):
        """
        初始化日志管理器
        
        Args:
            name: 日志记录器名称
            level: 日志级别
            log_file: 日志文件路径
            max_file_size: 最大文件大小（字节）
            backup_count: 备份文件数量
        """
        self.name = name
        self.level = LOG_LEVELS.get(level, logging.INFO)
        self.log_file = log_file
        self.max_file_size = max_file_size
        self.backup_count = backup_count
        
        self.logger = self._setup_logger()
    
    def _setup_logger(self) -> logging.Logger:
        """设置日志记录器"""
        logger = logging.getLogger(self.name)
        logger.setLevel(self.level)
        
        # 清除现有处理器
        logger.handlers.clear()
        
        # 日志格式
        formatter = logging.Formatter(
            '%(asctime)s - [%(levelname)s] - %(name)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(self.level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # 文件处理器
        if self.log_file:
            try:
                # 创建日志目录
                log_dir = os.path.dirname(self.log_file)
                if log_dir:
                    os.makedirs(log_dir, exist_ok=True)
                
                # 创建轮转文件处理器
                file_handler = logging.handlers.RotatingFileHandler(
                    self.log_file,
                    maxBytes=self.max_file_size,
                    backupCount=self.backup_count,
                    encoding='utf-8'
                )
                file_handler.setLevel(self.level)
                file_handler.setFormatter(formatter)
                logger.addHandler(file_handler)
            
            except Exception as e:
                logger.warning(f"创建日志文件处理器失败: {e}")
        
        return logger
    
    def get_logger(self) -> logging.Logger:
        """获取日志记录器"""
        return self.logger
    
    def debug(self, message: str) -> None:
        """记录调试信息"""
        self.logger.debug(message)
    
    def info(self, message: str) -> None:
        """记录信息"""
        self.logger.info(message)
    
    def warning(self, message: str) -> None:
        """记录警告"""
        self.logger.warning(message)
    
    def error(self, message: str) -> None:
        """记录错误"""
        self.logger.error(message)
    
    def critical(self, message: str) -> None:
        """记录严重错误"""
        self.logger.critical(message)


# 全局日志管理器实例
_logger_manager: Optional[LoggerManager] = None


def setup_logger(
    name: str = "omnidesk",
    level: str = "INFO",
    log_file: Optional[str] = None,
    max_file_size: int = 10485760,
    backup_count: int = 5
) -> logging.Logger:
    """
    设置全局日志记录器
    
    Args:
        name: 日志记录器名称
        level: 日志级别
        log_file: 日志文件路径
        max_file_size: 最大文件大小
        backup_count: 备份文件数量
    
    Returns:
        日志记录器
    """
    global _logger_manager
    
    _logger_manager = LoggerManager(
        name=name,
        level=level,
        log_file=log_file,
        max_file_size=max_file_size,
        backup_count=backup_count
    )
    
    return _logger_manager.get_logger()


def get_logger(name: str = "omnidesk") -> logging.Logger:
    """获取日志记录器"""
    if _logger_manager is None:
        return setup_logger(name)
    return logging.getLogger(_logger_manager.name)


# 导出
__all__ = [
    'LoggerManager',
    'setup_logger',
    'get_logger',
    'LOG_LEVELS'
]
