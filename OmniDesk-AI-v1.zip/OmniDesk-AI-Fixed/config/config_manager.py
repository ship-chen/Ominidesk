#!/usr/bin/env python3
"""
配置管理模块
支持 JSON 配置文件加载、环境变量覆盖、配置验证
"""

import json
import os
import logging
from typing import Any, Dict, Optional
from pathlib import Path

logger = logging.getLogger(__name__)


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化配置管理器
        
        Args:
            config_path: 配置文件路径，默认为 config/config.json
        """
        self.config_path = config_path or self._get_default_config_path()
        self.config: Dict[str, Any] = {}
        self.load_config()
    
    @staticmethod
    def _get_default_config_path() -> str:
        """获取默认配置文件路径"""
        base_dir = Path(__file__).parent
        return str(base_dir / "config.json")
    
    def load_config(self) -> None:
        """加载配置文件"""
        try:
            if not os.path.exists(self.config_path):
                logger.warning(f"配置文件不存在: {self.config_path}")
                self.config = self._get_default_config()
                return
            
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            
            # 应用环境变量覆盖
            self._apply_env_overrides()
            
            logger.info(f"配置已加载: {self.config_path}")
        
        except json.JSONDecodeError as e:
            logger.error(f"配置文件格式错误: {e}")
            self.config = self._get_default_config()
        
        except Exception as e:
            logger.error(f"加载配置失败: {e}")
            self.config = self._get_default_config()
    
    def _apply_env_overrides(self) -> None:
        """应用环境变量覆盖"""
        # 服务器配置
        if os.getenv('OMNIDESK_HOST'):
            self.config['server']['host'] = os.getenv('OMNIDESK_HOST')
        
        if os.getenv('OMNIDESK_PORT'):
            self.config['server']['port'] = int(os.getenv('OMNIDESK_PORT'))
        
        if os.getenv('OMNIDESK_DEBUG'):
            self.config['server']['debug'] = os.getenv('OMNIDESK_DEBUG').lower() == 'true'
        
        # 安全配置
        if os.getenv('JWT_SECRET'):
            self.config['security']['jwt_secret'] = os.getenv('JWT_SECRET')
        
        # AI 配置
        if os.getenv('DEFAULT_AI_MODEL'):
            self.config['ai']['default_model'] = os.getenv('DEFAULT_AI_MODEL')
        
        logger.debug("环境变量覆盖已应用")
    
    def save_config(self) -> bool:
        """保存配置文件"""
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            logger.info(f"配置已保存: {self.config_path}")
            return True
        
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
            return False
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值（支持点号分隔的嵌套键）
        
        Args:
            key: 配置键，例如 'server.port'
            default: 默认值
        
        Returns:
            配置值
        """
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value if value is not None else default
    
    def set(self, key: str, value: Any) -> bool:
        """
        设置配置值（支持点号分隔的嵌套键）
        
        Args:
            key: 配置键，例如 'server.port'
            value: 配置值
        
        Returns:
            是否成功
        """
        try:
            keys = key.split('.')
            config = self.config
            
            # 导航到父键
            for k in keys[:-1]:
                if k not in config:
                    config[k] = {}
                config = config[k]
            
            # 设置值
            config[keys[-1]] = value
            
            logger.debug(f"配置已更新: {key} = {value}")
            return True
        
        except Exception as e:
            logger.error(f"设置配置失败: {e}")
            return False
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """获取配置段"""
        return self.config.get(section, {})
    
    def validate(self) -> bool:
        """验证配置"""
        try:
            # 验证必需的字段
            required_sections = ['app', 'server', 'ai', 'security']
            for section in required_sections:
                if section not in self.config:
                    logger.error(f"缺少必需的配置段: {section}")
                    return False
            
            # 验证服务器配置
            server = self.config.get('server', {})
            if not isinstance(server.get('port'), int):
                logger.error("服务器端口必须是整数")
                return False
            
            if server.get('port') < 1 or server.get('port') > 65535:
                logger.error("服务器端口必须在 1-65535 之间")
                return False
            
            logger.info("配置验证通过")
            return True
        
        except Exception as e:
            logger.error(f"配置验证失败: {e}")
            return False
    
    @staticmethod
    def _get_default_config() -> Dict[str, Any]:
        """获取默认配置"""
        return {
            "app": {
                "name": "OmniDesk AI",
                "version": "1.1.0"
            },
            "server": {
                "host": "127.0.0.1",
                "port": 8000,
                "debug": False
            },
            "ai": {
                "default_model": "gpt-4"
            },
            "security": {
                "jwt_secret": "omnidesk-secret-key-change-in-production"
            }
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return self.config.copy()
    
    def __repr__(self) -> str:
        """字符串表示"""
        return f"ConfigManager(path={self.config_path})"


# 全局配置管理器实例
_config_manager: Optional[ConfigManager] = None


def get_config_manager() -> ConfigManager:
    """获取全局配置管理器"""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager


def get_config(key: str, default: Any = None) -> Any:
    """获取配置值"""
    return get_config_manager().get(key, default)


def set_config(key: str, value: Any) -> bool:
    """设置配置值"""
    return get_config_manager().set(key, value)


# 导出
__all__ = [
    'ConfigManager',
    'get_config_manager',
    'get_config',
    'set_config'
]
