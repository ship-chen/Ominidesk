#!/usr/bin/env python3
"""
OmniDesk AI v1.1.0 - 集成版 PyQt6 主应用
完整的 Windows AI 代理系统 - 与后端完全对接
左侧导航栏 + 右侧内容区域布局
"""

import sys
import os
import json
import asyncio
import subprocess
import time
import requests
import threading
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTabWidget, QMessageBox, QStatusBar, QListWidget, QListWidgetItem,
    QLineEdit, QPushButton, QLabel, QScrollArea, QFrame, QProgressBar, QComboBox
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread, QSize, QObject
from PyQt6.QtGui import QIcon, QFont, QColor, QPixmap
from PyQt6.QtCore import QRect, QEvent

# 后端 API 配置
BACKEND_URL = "http://127.0.0.1:8000"
BACKEND_TIMEOUT = 10


class APIClient:
    """后端 API 客户端"""
    
    def __init__(self, base_url: str = BACKEND_URL):
        self.base_url = base_url
        self.timeout = BACKEND_TIMEOUT
    
    def health_check(self) -> bool:
        """检查后端健康状态"""
        try:
            response = requests.get(
                f"{self.base_url}/health",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            print(f"后端健康检查失败: {e}")
            return False
    
    def get_vms(self) -> List[Dict[str, Any]]:
        """获取虚拟机列表"""
        try:
            response = requests.get(
                f"{self.base_url}/vbox/vms",
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json()
            return []
        except Exception as e:
            print(f"获取虚拟机列表失败: {e}")
            return []
    
    def get_vm_info(self, vm_name: str) -> Optional[Dict[str, Any]]:
        """获取虚拟机信息"""
        try:
            response = requests.get(
                f"{self.base_url}/vbox/vms/{vm_name}",
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            print(f"获取虚拟机信息失败: {e}")
            return None
    
    def start_vm(self, vm_name: str) -> bool:
        """启动虚拟机"""
        try:
            response = requests.post(
                f"{self.base_url}/vbox/vms/{vm_name}/start",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            print(f"启动虚拟机失败: {e}")
            return False
    
    def stop_vm(self, vm_name: str) -> bool:
        """停止虚拟机"""
        try:
            response = requests.post(
                f"{self.base_url}/vbox/vms/{vm_name}/stop",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            print(f"停止虚拟机失败: {e}")
            return False
    
    def pause_vm(self, vm_name: str) -> bool:
        """暂停虚拟机"""
        try:
            response = requests.post(
                f"{self.base_url}/vbox/vms/{vm_name}/pause",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            print(f"暂停虚拟机失败: {e}")
            return False
    
    def resume_vm(self, vm_name: str) -> bool:
        """恢复虚拟机"""
        try:
            response = requests.post(
                f"{self.base_url}/vbox/vms/{vm_name}/resume",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            print(f"恢复虚拟机失败: {e}")
            return False
    
    def restart_vm(self, vm_name: str) -> bool:
        """重启虚拟机"""
        try:
            response = requests.post(
                f"{self.base_url}/vbox/vms/{vm_name}/restart",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            print(f"重启虚拟机失败: {e}")
            return False
    
    def create_snapshot(self, vm_name: str, snapshot_name: str) -> bool:
        """创建快照"""
        try:
            response = requests.post(
                f"{self.base_url}/vbox/vms/{vm_name}/snapshot",
                json={"snapshot_name": snapshot_name},
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            print(f"创建快照失败: {e}")
            return False
    
    def get_snapshots(self, vm_name: str) -> List[Dict[str, Any]]:
        """获取快照列表"""
        try:
            response = requests.get(
                f"{self.base_url}/vbox/vms/{vm_name}/snapshots",
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json()
            return []
        except Exception as e:
            print(f"获取快照列表失败: {e}")
            return []
    
    def get_models(self) -> List[Dict[str, Any]]:
        """获取 AI 模型列表"""
        try:
            response = requests.get(
                f"{self.base_url}/engine/models",
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json()
            return []
        except Exception as e:
            print(f"获取模型列表失败: {e}")
            return []
    
    def create_task(self, task_data: Dict[str, Any]) -> Optional[str]:
        """创建任务"""
        try:
            response = requests.post(
                f"{self.base_url}/engine/tasks",
                json=task_data,
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json().get("task_id")
            return None
        except Exception as e:
            print(f"创建任务失败: {e}")
            return None
    
    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取任务信息"""
        try:
            response = requests.get(
                f"{self.base_url}/engine/tasks/{task_id}",
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            print(f"获取任务信息失败: {e}")
            return None
    
    def get_statistics(self) -> Optional[Dict[str, Any]]:
        """获取统计信息"""
        try:
            response = requests.get(
                f"{self.base_url}/engine/statistics",
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            print(f"获取统计信息失败: {e}")
            return None


class BackendWorker(QThread):
    """后端工作线程"""
    finished = pyqtSignal()
    error = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.backend_process = None
    
    def run(self):
        """运行后端服务"""
        try:
            backend_dir = Path(__file__).parent.parent / 'backend'
            
            # 启动后端服务
            self.backend_process = subprocess.Popen(
                [sys.executable, str(backend_dir / 'main_optimized.py')],
                cwd=str(backend_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            # 等待后端启动
            time.sleep(3)
            
            # 检查后端是否启动成功
            api_client = APIClient()
            for i in range(10):
                if api_client.health_check():
                    self.finished.emit()
                    return
                time.sleep(1)
            
            self.error.emit("后端启动超时")
        except Exception as e:
            self.error.emit(f"后端启动失败: {str(e)}")


class SidebarButton(QPushButton):
    """侧边栏按钮"""
    def __init__(self, text, icon_char=""):
        super().__init__()
        self.setText(f"  {text}")
        self.setFixedHeight(44)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("""
            QPushButton {
                background-color: #f8f9fa;
                border: none;
                border-left: 3px solid transparent;
                text-align: left;
                padding-left: 16px;
                color: #333;
                font-size: 13px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #e8f0f8;
                color: #0078d4;
            }
            QPushButton:pressed {
                background-color: #e8f0f8;
                color: #0078d4;
                border-left: 3px solid #0078d4;
            }
        """)


class OmniDeskAppIntegrated(QMainWindow):
    """OmniDesk AI 集成版主应用"""
    
    def __init__(self):
        super().__init__()
        self.api_client = APIClient()
        self.backend_worker = None
        self.current_panel = None
        self.nav_buttons = {}
        self.init_ui()
        self.start_backend()
    
    def init_ui(self):
        """初始化 UI"""
        self.setWindowTitle("OmniDesk AI v1.1.0 - 集成版")
        self.setGeometry(100, 100, 1600, 1000)
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 标题栏
        title_bar = self.create_title_bar()
        main_layout.addWidget(title_bar)
        
        # 内容区域
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        # 左侧导航栏
        sidebar = self.create_sidebar()
        content_layout.addWidget(sidebar)
        
        # 右侧内容区域
        right_area = self.create_right_area()
        content_layout.addWidget(right_area, 1)
        
        content_widget = QWidget()
        content_widget.setLayout(content_layout)
        main_layout.addWidget(content_widget, 1)
        
        central_widget.setLayout(main_layout)
        
        # 状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("启动中...")
        self.status_bar.setStyleSheet("""
            QStatusBar {
                background-color: #f0f0f0;
                border-top: 1px solid #e0e0e0;
                color: #666;
                font-size: 12px;
            }
        """)
        
        # 应用样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #ffffff;
            }
            QWidget {
                background-color: #ffffff;
            }
        """)
    
    def create_title_bar(self):
        """创建标题栏"""
        title_bar = QFrame()
        title_bar.setFixedHeight(50)
        title_bar.setStyleSheet("""
            QFrame {
                background: linear-gradient(90deg, #0078d4, #106ebe);
                border-bottom: 1px solid #0066b3;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(12)
        
        # Logo
        logo_label = QLabel("O")
        logo_label.setStyleSheet("""
            QLabel {
                background-color: rgba(255, 255, 255, 0.3);
                color: white;
                font-weight: bold;
                font-size: 16px;
                width: 32px;
                height: 32px;
                border-radius: 4px;
                text-align: center;
                line-height: 32px;
            }
        """)
        layout.addWidget(logo_label)
        
        # 标题
        title_label = QLabel("OmniDesk AI v1.1.0 - 集成版")
        title_label.setStyleSheet("""
            QLabel {
                color: white;
                font-weight: bold;
                font-size: 14px;
            }
        """)
        layout.addWidget(title_label)
        
        layout.addStretch()
        
        # 窗口按钮
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(32, 32)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: white;
                border: none;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.2);
            }
        """)
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn)
        
        title_bar.setLayout(layout)
        return title_bar
    
    def create_sidebar(self):
        """创建左侧导航栏"""
        sidebar = QFrame()
        sidebar.setFixedWidth(280)
        sidebar.setStyleSheet("""
            QFrame {
                background-color: #f8f9fa;
                border-right: 1px solid #e0e0e0;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # 主要功能部分
        main_title = QLabel("主要功能")
        main_title.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 11px;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 1px;
                padding: 16px 16px 8px 16px;
            }
        """)
        layout.addWidget(main_title)
        
        # 导航按钮
        nav_items = [
            ("chat", "💬 AI 聊天"),
            ("vm", "🖥️ 虚拟机"),
            ("tasks", "📊 任务管理"),
            ("monitor", "📈 性能监控"),
        ]
        
        for key, text in nav_items:
            btn = SidebarButton(text)
            btn.clicked.connect(lambda checked, k=key: self.switch_panel(k))
            layout.addWidget(btn)
            self.nav_buttons[key] = btn
        
        # 系统部分
        system_title = QLabel("系统")
        system_title.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 11px;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 1px;
                padding: 16px 16px 8px 16px;
                margin-top: 8px;
            }
        """)
        layout.addWidget(system_title)
        
        system_items = [
            ("audit", "🔐 安全审计"),
            ("settings", "⚙️ 设置"),
        ]
        
        for key, text in system_items:
            btn = SidebarButton(text)
            btn.clicked.connect(lambda checked, k=key: self.switch_panel(k))
            layout.addWidget(btn)
            self.nav_buttons[key] = btn
        
        layout.addStretch()
        sidebar.setLayout(layout)
        
        # 设置默认选中
        self.nav_buttons["chat"].setStyleSheet("""
            QPushButton {
                background-color: #e8f0f8;
                border: none;
                border-left: 3px solid #0078d4;
                text-align: left;
                padding-left: 16px;
                color: #0078d4;
                font-size: 13px;
                font-weight: bold;
            }
        """)
        
        return sidebar
    
    def create_right_area(self):
        """创建右侧内容区域"""
        right_area = QFrame()
        right_area.setStyleSheet("""
            QFrame {
                background-color: #ffffff;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # 工具栏
        toolbar = self.create_toolbar()
        layout.addWidget(toolbar)
        
        # 内容面板容器
        self.panel_container = QFrame()
        self.panel_container.setStyleSheet("""
            QFrame {
                background-color: #fafafa;
            }
        """)
        self.panel_layout = QVBoxLayout()
        self.panel_layout.setContentsMargins(0, 0, 0, 0)
        self.panel_container.setLayout(self.panel_layout)
        
        layout.addWidget(self.panel_container, 1)
        
        right_area.setLayout(layout)
        return right_area
    
    def create_toolbar(self):
        """创建工具栏"""
        toolbar = QFrame()
        toolbar.setFixedHeight(50)
        toolbar.setStyleSheet("""
            QFrame {
                background-color: #ffffff;
                border-bottom: 1px solid #e0e0e0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(8)
        
        # 刷新按钮
        refresh_btn = QPushButton("🔄 刷新")
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #0078d4;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
        """)
        refresh_btn.clicked.connect(self.refresh_current_panel)
        layout.addWidget(refresh_btn)
        
        layout.addStretch()
        
        toolbar.setLayout(layout)
        return toolbar
    
    def switch_panel(self, panel_name):
        """切换面板"""
        # 清空当前面板
        while self.panel_layout.count():
            child = self.panel_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        
        # 更新按钮状态
        for key, btn in self.nav_buttons.items():
            if key == panel_name:
                btn.setStyleSheet("""
                    QPushButton {
                        background-color: #e8f0f8;
                        border: none;
                        border-left: 3px solid #0078d4;
                        text-align: left;
                        padding-left: 16px;
                        color: #0078d4;
                        font-size: 13px;
                        font-weight: bold;
                    }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton {
                        background-color: #f8f9fa;
                        border: none;
                        border-left: 3px solid transparent;
                        text-align: left;
                        padding-left: 16px;
                        color: #333;
                        font-size: 13px;
                        font-weight: 500;
                    }
                    QPushButton:hover {
                        background-color: #e8f0f8;
                        color: #0078d4;
                    }
                """)
        
        # 创建新面板
        if panel_name == "chat":
            panel = self.create_chat_panel()
        elif panel_name == "vm":
            panel = self.create_vm_panel()
        elif panel_name == "tasks":
            panel = self.create_tasks_panel()
        elif panel_name == "monitor":
            panel = self.create_monitor_panel()
        elif panel_name == "audit":
            panel = self.create_audit_panel()
        elif panel_name == "settings":
            panel = self.create_settings_panel()
        else:
            panel = QLabel("面板未实现")
        
        self.current_panel = panel_name
        self.panel_layout.addWidget(panel)
    
    def refresh_current_panel(self):
        """刷新当前面板"""
        if self.current_panel:
            self.switch_panel(self.current_panel)
            self.status_bar.showMessage("已刷新")
    
    def create_chat_panel(self):
        """创建聊天面板"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 聊天消息列表
        self.chat_list = QListWidget()
        self.chat_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #ddd;
                border-radius: 6px;
                background-color: #fafafa;
            }
        """)
        layout.addWidget(self.chat_list)
        
        # 输入框
        input_layout = QHBoxLayout()
        self.chat_input = QLineEdit()
        self.chat_input.setPlaceholderText("输入您的需求...")
        self.chat_input.setFixedHeight(40)
        self.chat_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 1px solid #0078d4;
                background-color: #f8f8f8;
            }
        """)
        self.chat_input.returnPressed.connect(self.send_message)
        
        send_btn = QPushButton("发送")
        send_btn.setFixedSize(80, 40)
        send_btn.setStyleSheet("""
            QPushButton {
                background-color: #0078d4;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
        """)
        send_btn.clicked.connect(self.send_message)
        
        input_layout.addWidget(self.chat_input)
        input_layout.addWidget(send_btn)
        layout.addLayout(input_layout)
        
        widget.setLayout(layout)
        return widget
    
    def create_vm_panel(self):
        """创建虚拟机面板 - 从后端获取数据"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("虚拟机管理")
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # 虚拟机列表
        self.vm_list = QListWidget()
        self.vm_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #ddd;
                border-radius: 6px;
            }
            QListWidget::item {
                padding: 12px;
                border-bottom: 1px solid #eee;
            }
        """)
        
        # 从后端获取虚拟机列表
        vms = self.api_client.get_vms()
        if vms:
            for vm in vms:
                vm_name = vm.get('name', 'Unknown')
                vm_state = vm.get('state', 'unknown')
                status_icon = {
                    'running': '✓',
                    'stopped': '✗',
                    'paused': '⏸',
                    'unknown': '?'
                }.get(vm_state, '?')
                
                item_text = f"{status_icon} {vm_name} ({vm_state})"
                item = QListWidgetItem(item_text)
                self.vm_list.addItem(item)
        else:
            item = QListWidgetItem("未找到虚拟机或后端未连接")
            self.vm_list.addItem(item)
        
        layout.addWidget(self.vm_list)
        
        # 操作按钮
        btn_layout = QHBoxLayout()
        
        start_btn = QPushButton("▶ 启动")
        start_btn.setStyleSheet("""
            QPushButton {
                background-color: #0078d4;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
        """)
        start_btn.clicked.connect(lambda: self.vm_action("start"))
        
        stop_btn = QPushButton("⏹ 停止")
        stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #ffc107;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #ffb300;
            }
        """)
        stop_btn.clicked.connect(lambda: self.vm_action("stop"))
        
        pause_btn = QPushButton("⏸ 暂停")
        pause_btn.setStyleSheet("""
            QPushButton {
                background-color: #17a2b8;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #138496;
            }
        """)
        pause_btn.clicked.connect(lambda: self.vm_action("pause"))
        
        btn_layout.addWidget(start_btn)
        btn_layout.addWidget(stop_btn)
        btn_layout.addWidget(pause_btn)
        
        layout.addLayout(btn_layout)
        
        widget.setLayout(layout)
        return widget
    
    def vm_action(self, action: str):
        """执行虚拟机操作"""
        current_item = self.vm_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "警告", "请先选择一个虚拟机")
            return
        
        # 从列表项提取虚拟机名称
        item_text = current_item.text()
        vm_name = item_text.split(" ", 1)[1].split(" (")[0]
        
        # 执行操作
        success = False
        if action == "start":
            success = self.api_client.start_vm(vm_name)
            msg = "启动"
        elif action == "stop":
            success = self.api_client.stop_vm(vm_name)
            msg = "停止"
        elif action == "pause":
            success = self.api_client.pause_vm(vm_name)
            msg = "暂停"
        
        if success:
            self.status_bar.showMessage(f"虚拟机 {msg} 成功")
            self.refresh_current_panel()
        else:
            QMessageBox.critical(self, "错误", f"虚拟机 {msg} 失败")
    
    def create_tasks_panel(self):
        """创建任务面板"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("任务管理")
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # 任务列表
        task_list = QListWidget()
        task_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #ddd;
                border-radius: 6px;
            }
            QListWidget::item {
                padding: 12px;
                border-bottom: 1px solid #eee;
            }
        """)
        
        # 从后端获取统计信息
        stats = self.api_client.get_statistics()
        if stats:
            tasks = stats.get('tasks', [])
            for task in tasks:
                task_id = task.get('id', 'unknown')
                task_status = task.get('status', 'unknown')
                task_title = task.get('title', 'Unknown Task')
                item = QListWidgetItem(f"[{task_status}] {task_title}")
                task_list.addItem(item)
        else:
            item = QListWidgetItem("无任务或后端未连接")
            task_list.addItem(item)
        
        layout.addWidget(task_list)
        
        widget.setLayout(layout)
        return widget
    
    def create_monitor_panel(self):
        """创建性能监控面板"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("性能监控")
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # 从后端获取统计信息
        stats = self.api_client.get_statistics()
        if stats:
            monitor_text = f"""
系统统计信息
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
总任务数: {stats.get('total_tasks', 0)}
已完成: {stats.get('completed_tasks', 0)}
进行中: {stats.get('running_tasks', 0)}
失败: {stats.get('failed_tasks', 0)}

缓存统计
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
缓存命中: {stats.get('cache_hits', 0)}
缓存未命中: {stats.get('cache_misses', 0)}
缓存命中率: {stats.get('cache_hit_rate', 0):.1%}

虚拟机统计
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
运行中: {stats.get('running_vms', 0)}
已停止: {stats.get('stopped_vms', 0)}
已暂停: {stats.get('paused_vms', 0)}
            """
        else:
            monitor_text = "后端未连接，无法获取监控数据"
        
        monitor_label = QLabel(monitor_text)
        monitor_label.setStyleSheet("""
            QLabel {
                background-color: #f8f9fa;
                padding: 20px;
                border-radius: 6px;
                border: 1px solid #ddd;
                font-family: monospace;
                color: #333;
            }
        """)
        layout.addWidget(monitor_label)
        
        layout.addStretch()
        
        widget.setLayout(layout)
        return widget
    
    def create_audit_panel(self):
        """创建审计面板"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("安全审计")
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # 审计日志
        audit_list = QListWidget()
        audit_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #ddd;
                border-radius: 6px;
            }
            QListWidget::item {
                padding: 12px;
                border-bottom: 1px solid #eee;
            }
        """)
        
        audits = [
            "✅ 后端已启动 - " + datetime.now().strftime("%H:%M:%S"),
            "✅ API 已连接 - " + datetime.now().strftime("%H:%M:%S"),
            "🔐 权限检查通过 - " + datetime.now().strftime("%H:%M:%S"),
        ]
        
        for audit in audits:
            item = QListWidgetItem(audit)
            audit_list.addItem(item)
        
        layout.addWidget(audit_list)
        
        widget.setLayout(layout)
        return widget
    
    def create_settings_panel(self):
        """创建设置面板"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("系统设置")
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # 设置信息
        settings_text = QLabel("""
应用信息
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
名称: OmniDesk AI
版本: 1.1.0 (集成版)
后端 URL: http://127.0.0.1:8000

系统要求
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
操作系统: Windows 7+
内存: 8 GB 推荐
VirtualBox: 6.0+
Python: 3.6+

功能开关
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ AI 聊天
✓ 虚拟机管理
✓ 任务调度
✓ 性能监控
✓ 安全审计
        """)
        settings_text.setStyleSheet("""
            QLabel {
                background-color: #f8f9fa;
                padding: 20px;
                border-radius: 6px;
                border: 1px solid #ddd;
                font-family: monospace;
                color: #333;
                line-height: 1.8;
            }
        """)
        layout.addWidget(settings_text)
        
        layout.addStretch()
        
        widget.setLayout(layout)
        return widget
    
    def send_message(self):
        """发送聊天消息"""
        message = self.chat_input.text().strip()
        
        if not message:
            return
        
        # 添加用户消息
        item = QListWidgetItem()
        self.chat_list.addItem(item)
        
        user_msg = QLabel(f"👤 您: {message}")
        user_msg.setStyleSheet("""
            QLabel {
                padding: 10px;
                background-color: #e8f0f8;
                border-radius: 6px;
                color: #0078d4;
                font-weight: bold;
            }
        """)
        self.chat_list.setItemWidget(item, user_msg)
        
        # 清空输入框
        self.chat_input.clear()
        
        # 模拟 AI 响应
        QTimer.singleShot(500, lambda: self.add_ai_response(message))
        
        # 更新状态栏
        self.status_bar.showMessage(f"处理中: {message[:30]}...")
    
    def add_ai_response(self, user_message):
        """添加 AI 响应"""
        response = f"我已收到您的需求: {user_message}\n正在处理中..."
        
        item = QListWidgetItem()
        self.chat_list.addItem(item)
        
        ai_msg = QLabel(f"🤖 AI: {response}")
        ai_msg.setStyleSheet("""
            QLabel {
                padding: 10px;
                background-color: #e8f8f3;
                border-radius: 6px;
                color: #50e3c2;
                font-weight: bold;
            }
        """)
        self.chat_list.setItemWidget(item, ai_msg)
        
        self.status_bar.showMessage("就绪")
    
    def start_backend(self):
        """启动后端服务"""
        self.backend_worker = BackendWorker()
        self.backend_worker.finished.connect(self.on_backend_started)
        self.backend_worker.error.connect(self.on_backend_error)
        self.backend_worker.start()
    
    def on_backend_started(self):
        """后端启动完成"""
        self.status_bar.showMessage("后端已启动 | VirtualBox: 可用 | 就绪")
        self.switch_panel("chat")
    
    def on_backend_error(self, error):
        """后端启动错误"""
        QMessageBox.warning(self, "错误", error)
        self.status_bar.showMessage(f"错误: {error}")
    
    def closeEvent(self, event):
        """关闭事件"""
        if self.backend_worker and self.backend_worker.backend_process:
            self.backend_worker.backend_process.terminate()
        
        event.accept()


def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用样式
    app.setStyle('Fusion')
    
    # 创建主窗口
    window = OmniDeskAppIntegrated()
    window.show()
    
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
